/**
 * Minimal Express server for the 3D Android Launcher backend
 * This provides simple API endpoints for development purposes
 */
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

// Create Express app
const app = express();
const PORT = process.env.PORT || 5000;

// In-memory storage for user preferences
const inMemoryDB = {
  themes: {},
  widgets: [],
  customIcons: {},
  wallpapers: {},
  appCategories: {},
  customGroups: {},
  sustainability: {
    enabled: true,
    energyMode: 'balanced',  // 'eco', 'balanced', 'performance'
    darkModeSchedule: {
      enabled: false,
      startTime: '22:00',
      endTime: '06:00'
    },
    screenTimeout: {
      smart: true,
      duration: 30
    },
    batteryOptimizations: true,
    stats: {
      dailyEnergyUsage: [],
      weeklyEnergyUsage: [],
      environmentalImpact: {
        co2Saved: 0,
        energySaved: 0,
        treesEquivalent: 0
      }
    },
    ecoThemes: [
      {
        id: 'eco_dark',
        name: 'Eco Dark',
        description: 'Pure black theme that saves maximum battery on OLED screens',
        primaryColor: '#000000',
        accentColor: '#336633',
        type: 'dark',
        energyImpact: 'very_low'
      },
      {
        id: 'eco_forest',
        name: 'Eco Forest',
        description: 'Dark green theme with forest-inspired accents',
        primaryColor: '#0A2A0A',
        accentColor: '#33A033',
        type: 'dark',
        energyImpact: 'low'
      }
    ],
    ecoWallpapers: [
      {
        id: 'eco_black',
        name: 'Pure Black',
        description: 'Minimal pure black wallpaper that saves maximum battery',
        type: 'static',
        config: { color: '#000000' },
        energyImpact: 'very_low'
      }
    ]
  }
};

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Log all requests
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// Serve static files from root directory
app.use(express.static('.'));

// Root endpoint
app.get('/api', (req, res) => {
  res.json({
    message: '3D Android Launcher API',
    status: 'running',
    endpoints: [
      '/api/themes',
      '/api/widgets',
      '/api/icons',
      '/api/wallpapers',
      '/api/sustainability'
    ]
  });
});

// ===== Theme APIs =====

// Get all themes
app.get('/api/themes', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.themes
  });
});

// Get a specific theme
app.get('/api/themes/:id', (req, res) => {
  const { id } = req.params;
  
  if (inMemoryDB.themes[id]) {
    res.json({
      status: 'success',
      data: inMemoryDB.themes[id]
    });
  } else {
    res.status(404).json({
      status: 'error',
      message: `Theme with id ${id} not found`
    });
  }
});

// Create or update a theme
app.post('/api/themes', (req, res) => {
  const theme = req.body;
  
  if (!theme || !theme.id) {
    return res.status(400).json({
      status: 'error',
      message: 'Invalid theme data. Theme ID is required.'
    });
  }
  
  inMemoryDB.themes[theme.id] = theme;
  
  res.json({
    status: 'success',
    message: 'Theme saved successfully',
    data: theme
  });
});

// ===== Widget APIs =====

// Get all widgets
app.get('/api/widgets', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.widgets
  });
});

// Create a widget
app.post('/api/widgets', (req, res) => {
  const widget = req.body;
  
  if (!widget) {
    return res.status(400).json({
      status: 'error',
      message: 'Invalid widget data'
    });
  }
  
  // Generate ID if not provided
  if (!widget.id) {
    widget.id = `widget_${Date.now()}`;
  }
  
  inMemoryDB.widgets.push(widget);
  
  res.json({
    status: 'success',
    message: 'Widget created successfully',
    data: widget
  });
});

// ===== Custom Icon APIs =====

// Get all custom icons
app.get('/api/icons', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.customIcons
  });
});

// Create or update a custom icon
app.post('/api/icons', (req, res) => {
  const { packageName, iconData } = req.body;
  
  if (!packageName || !iconData) {
    return res.status(400).json({
      status: 'error',
      message: 'Invalid data. Package name and icon data are required.'
    });
  }
  
  inMemoryDB.customIcons[packageName] = iconData;
  
  res.json({
    status: 'success',
    message: 'Custom icon saved successfully',
    data: { packageName, iconData }
  });
});

// ===== Wallpaper APIs =====

// Get all wallpapers
app.get('/api/wallpapers', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.wallpapers
  });
});

// Get current wallpaper
app.get('/api/wallpapers/current', (req, res) => {
  if (inMemoryDB.wallpapers.current) {
    res.json({
      status: 'success',
      data: inMemoryDB.wallpapers.current
    });
  } else {
    res.json({
      status: 'success',
      data: { type: 'static', settings: { color: '#000000' } }
    });
  }
});

// Set current wallpaper
app.post('/api/wallpapers/current', (req, res) => {
  const wallpaperData = req.body;
  
  if (!wallpaperData || !wallpaperData.type) {
    return res.status(400).json({
      status: 'error',
      message: 'Invalid wallpaper data. Type is required.'
    });
  }
  
  inMemoryDB.wallpapers.current = wallpaperData;
  
  res.json({
    status: 'success',
    message: 'Wallpaper set successfully',
    data: wallpaperData
  });
});

// ===== Sustainability APIs =====

// Get sustainability status
app.get('/api/sustainability', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.sustainability
  });
});

// Update sustainability settings
app.post('/api/sustainability/settings', (req, res) => {
  const settings = req.body;
  
  if (!settings) {
    return res.status(400).json({
      status: 'error',
      message: 'Invalid settings data'
    });
  }
  
  // Update settings - deep merge
  inMemoryDB.sustainability = {
    ...inMemoryDB.sustainability,
    ...settings,
    // Preserve nested objects that weren't provided in request
    darkModeSchedule: {
      ...inMemoryDB.sustainability.darkModeSchedule,
      ...(settings.darkModeSchedule || {})
    },
    screenTimeout: {
      ...inMemoryDB.sustainability.screenTimeout,
      ...(settings.screenTimeout || {})
    },
    stats: inMemoryDB.sustainability.stats // Stats should be updated separately
  };
  
  res.json({
    status: 'success',
    message: 'Sustainability settings updated',
    data: inMemoryDB.sustainability
  });
});

// Get eco-friendly themes
app.get('/api/sustainability/eco-themes', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.sustainability.ecoThemes
  });
});

// Get eco-friendly wallpapers
app.get('/api/sustainability/eco-wallpapers', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.sustainability.ecoWallpapers
  });
});

// Get battery recommendations
app.get('/api/sustainability/battery-recommendations', (req, res) => {
  // Generate recommendations based on current settings
  const currentMode = inMemoryDB.sustainability.energyMode;
  const recommendations = [];
  
  if (currentMode !== 'eco') {
    recommendations.push({
      id: 'eco_mode',
      title: 'Switch to Eco Mode',
      description: 'Change to eco mode to maximize battery life',
      impact: 'high',
      current: currentMode,
      suggested: 'eco'
    });
  }
  
  if (!inMemoryDB.sustainability.darkModeSchedule.enabled) {
    recommendations.push({
      id: 'dark_mode',
      title: 'Enable Dark Mode Schedule',
      description: 'Dark mode reduces screen power consumption on OLED displays',
      impact: 'medium',
      current: false,
      suggested: true
    });
  }
  
  if (inMemoryDB.sustainability.screenTimeout.duration > 30) {
    recommendations.push({
      id: 'reduce_timeout',
      title: 'Reduce Screen Timeout',
      description: 'A shorter timeout period saves battery life',
      impact: 'medium',
      current: inMemoryDB.sustainability.screenTimeout.duration,
      suggested: 30
    });
  }
  
  // Static recommendations that are always applicable
  recommendations.push(
    {
      id: 'static_wallpaper',
      title: 'Use Static Wallpaper',
      description: 'Animated wallpapers consume more power',
      impact: 'medium',
      suggested: 'static'
    },
    {
      id: 'reduce_animations',
      title: 'Reduce UI Animations',
      description: 'Minimal animations require less processing power',
      impact: 'low',
      suggested: true
    }
  );
  
  res.json({
    status: 'success',
    data: recommendations
  });
});

// Get energy usage stats
app.get('/api/sustainability/energy-stats', (req, res) => {
  // Generate some simulated data for the demo
  if (inMemoryDB.sustainability.stats.dailyEnergyUsage.length === 0) {
    // Create 24 hours of data
    const now = new Date();
    for (let i = 0; i < 24; i++) {
      const time = new Date(now.getTime() - (i * 60 * 60 * 1000));
      inMemoryDB.sustainability.stats.dailyEnergyUsage.unshift({
        timestamp: time.toISOString(),
        powerConsumption: Math.floor(150 + Math.random() * 100), // 150-250 mW
        batteryLevel: Math.max(20, 100 - i * 3), // Decrease from 100% by ~3% per hour
        temperature: Math.floor(25 + Math.random() * 10) // 25-35°C
      });
    }
    
    // Update environmental impact
    inMemoryDB.sustainability.stats.environmentalImpact = {
      co2Saved: Math.floor(50 + Math.random() * 100), // 50-150g
      energySaved: Math.floor(100 + Math.random() * 200), // 100-300 mWh
      treesEquivalent: (Math.random() * 0.01).toFixed(3) // Small fraction of a tree
    };
  }
  
  res.json({
    status: 'success',
    data: inMemoryDB.sustainability.stats
  });
});

// Apply battery optimizations
app.post('/api/sustainability/apply-optimizations', (req, res) => {
  // Apply recommended settings
  inMemoryDB.sustainability.energyMode = 'eco';
  inMemoryDB.sustainability.batteryOptimizations = true;
  inMemoryDB.sustainability.darkModeSchedule.enabled = true;
  inMemoryDB.sustainability.screenTimeout.duration = 30;
  
  // Update environmental impact (simulate improvement)
  inMemoryDB.sustainability.stats.environmentalImpact.energySaved += 50;
  inMemoryDB.sustainability.stats.environmentalImpact.co2Saved += 25;
  inMemoryDB.sustainability.stats.environmentalImpact.treesEquivalent = 
    (parseFloat(inMemoryDB.sustainability.stats.environmentalImpact.treesEquivalent) + 0.005).toFixed(3);
  
  res.json({
    status: 'success',
    message: 'Battery optimizations applied',
    data: {
      settings: {
        energyMode: inMemoryDB.sustainability.energyMode,
        batteryOptimizations: inMemoryDB.sustainability.batteryOptimizations,
        darkModeSchedule: inMemoryDB.sustainability.darkModeSchedule,
        screenTimeout: inMemoryDB.sustainability.screenTimeout
      },
      estimatedImpact: {
        batteryExtension: '2-3 hours',
        energySaved: '25%'
      }
    }
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Server Error:', err);
  res.status(500).json({
    status: 'error',
    message: 'Internal server error',
    error: err.message
  });
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`3D Android Launcher API server running on http://0.0.0.0:${PORT}`);
});