import React, { useState, useEffect } from 'react';
import { SafeAreaView, StatusBar, StyleSheet, LogBox } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { PreferenceService } from './src/services/PreferenceService';
import { ThemeService } from './src/services/ThemeService';
import AppNavigator from './src/navigation/AppNavigator';

// Disable specific warnings related to Three.js integration with React Native
LogBox.ignoreLogs([
  'ViewPropTypes will be removed',
  'ColorPropType will be removed',
  'Require cycle',
]);

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [theme, setTheme] = useState({});

  useEffect(() => {
    const loadInitialData = async () => {
      // Initialize user preferences
      await PreferenceService.initialize();
      
      // Get the saved theme or default theme
      const savedTheme = await ThemeService.getCurrentTheme();
      setTheme(savedTheme);
      
      // Subscribe to theme changes
      ThemeService.subscribeToThemeChanges((newTheme) => {
        setTheme(newTheme);
      });
      
      setIsLoading(false);
    };

    loadInitialData();
    
    return () => {
      // Cleanup subscriptions
      ThemeService.unsubscribeFromThemeChanges();
    };
  }, []);

  if (isLoading) {
    // You could return a splash screen here
    return null;
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaView style={[styles.container, { backgroundColor: theme.backgroundColor || '#000' }]}>
        <StatusBar 
          translucent 
          backgroundColor="transparent" 
          barStyle={theme.isDark ? 'light-content' : 'dark-content'} 
        />
        <AppNavigator theme={theme} />
      </SafeAreaView>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
