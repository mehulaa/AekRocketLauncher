#!/bin/bash
npm install --legacy-peer-deps express cors body-parser
node simple-server.js