/**
 * Minimal Express server for the 3D Android Launcher backend
 * This provides simple API endpoints for development purposes
 */
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

// Create Express app
const app = express();
const PORT = process.env.PORT || 5000;

// In-memory storage for user preferences
const inMemoryDB = {
  themes: {},
  widgets: [],
  customIcons: {},
  wallpapers: {},
  appCategories: {},
  customGroups: {}
};

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Log all requests
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    message: '3D Android Launcher API',
    status: 'running',
    endpoints: [
      '/api/themes',
      '/api/widgets',
      '/api/icons',
      '/api/wallpapers'
    ]
  });
});

// ===== Theme APIs =====

// Get all themes
app.get('/api/themes', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.themes
  });
});

// Get a specific theme
app.get('/api/themes/:id', (req, res) => {
  const { id } = req.params;
  
  if (inMemoryDB.themes[id]) {
    res.json({
      status: 'success',
      data: inMemoryDB.themes[id]
    });
  } else {
    res.status(404).json({
      status: 'error',
      message: `Theme with id ${id} not found`
    });
  }
});

// Create or update a theme
app.post('/api/themes', (req, res) => {
  const theme = req.body;
  
  if (!theme || !theme.id) {
    return res.status(400).json({
      status: 'error',
      message: 'Invalid theme data. Theme ID is required.'
    });
  }
  
  inMemoryDB.themes[theme.id] = theme;
  
  res.json({
    status: 'success',
    message: 'Theme saved successfully',
    data: theme
  });
});

// Delete a theme
app.delete('/api/themes/:id', (req, res) => {
  const { id } = req.params;
  
  if (inMemoryDB.themes[id]) {
    delete inMemoryDB.themes[id];
    res.json({
      status: 'success',
      message: `Theme ${id} deleted successfully`
    });
  } else {
    res.status(404).json({
      status: 'error',
      message: `Theme with id ${id} not found`
    });
  }
});

// ===== Widget APIs =====

// Get all widgets
app.get('/api/widgets', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.widgets
  });
});

// Get a specific widget
app.get('/api/widgets/:id', (req, res) => {
  const { id } = req.params;
  const widget = inMemoryDB.widgets.find(w => w.id === id);
  
  if (widget) {
    res.json({
      status: 'success',
      data: widget
    });
  } else {
    res.status(404).json({
      status: 'error',
      message: `Widget with id ${id} not found`
    });
  }
});

// Create a widget
app.post('/api/widgets', (req, res) => {
  const widget = req.body;
  
  if (!widget) {
    return res.status(400).json({
      status: 'error',
      message: 'Invalid widget data'
    });
  }
  
  // Generate ID if not provided
  if (!widget.id) {
    widget.id = `widget_${Date.now()}`;
  }
  
  inMemoryDB.widgets.push(widget);
  
  res.json({
    status: 'success',
    message: 'Widget created successfully',
    data: widget
  });
});

// Update a widget
app.put('/api/widgets/:id', (req, res) => {
  const { id } = req.params;
  const updatedWidget = req.body;
  
  const index = inMemoryDB.widgets.findIndex(w => w.id === id);
  
  if (index !== -1) {
    inMemoryDB.widgets[index] = { ...updatedWidget, id };
    res.json({
      status: 'success',
      message: 'Widget updated successfully',
      data: inMemoryDB.widgets[index]
    });
  } else {
    res.status(404).json({
      status: 'error',
      message: `Widget with id ${id} not found`
    });
  }
});

// Delete a widget
app.delete('/api/widgets/:id', (req, res) => {
  const { id } = req.params;
  const initialLength = inMemoryDB.widgets.length;
  
  inMemoryDB.widgets = inMemoryDB.widgets.filter(w => w.id !== id);
  
  if (inMemoryDB.widgets.length < initialLength) {
    res.json({
      status: 'success',
      message: `Widget ${id} deleted successfully`
    });
  } else {
    res.status(404).json({
      status: 'error',
      message: `Widget with id ${id} not found`
    });
  }
});

// ===== Custom Icon APIs =====

// Get all custom icons
app.get('/api/icons', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.customIcons
  });
});

// Get a specific custom icon
app.get('/api/icons/:packageName', (req, res) => {
  const { packageName } = req.params;
  
  if (inMemoryDB.customIcons[packageName]) {
    res.json({
      status: 'success',
      data: inMemoryDB.customIcons[packageName]
    });
  } else {
    res.status(404).json({
      status: 'error',
      message: `Custom icon for package ${packageName} not found`
    });
  }
});

// Create or update a custom icon
app.post('/api/icons', (req, res) => {
  const { packageName, iconData } = req.body;
  
  if (!packageName || !iconData) {
    return res.status(400).json({
      status: 'error',
      message: 'Invalid data. Package name and icon data are required.'
    });
  }
  
  inMemoryDB.customIcons[packageName] = iconData;
  
  res.json({
    status: 'success',
    message: 'Custom icon saved successfully',
    data: { packageName, iconData }
  });
});

// Delete a custom icon
app.delete('/api/icons/:packageName', (req, res) => {
  const { packageName } = req.params;
  
  if (inMemoryDB.customIcons[packageName]) {
    delete inMemoryDB.customIcons[packageName];
    res.json({
      status: 'success',
      message: `Custom icon for ${packageName} deleted successfully`
    });
  } else {
    res.status(404).json({
      status: 'error',
      message: `Custom icon for package ${packageName} not found`
    });
  }
});

// ===== Wallpaper APIs =====

// Get all wallpapers
app.get('/api/wallpapers', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.wallpapers
  });
});

// Get current wallpaper
app.get('/api/wallpapers/current', (req, res) => {
  if (inMemoryDB.wallpapers.current) {
    res.json({
      status: 'success',
      data: inMemoryDB.wallpapers.current
    });
  } else {
    res.json({
      status: 'success',
      data: { type: 'static', settings: { color: '#000000' } }
    });
  }
});

// Set current wallpaper
app.post('/api/wallpapers/current', (req, res) => {
  const wallpaperData = req.body;
  
  if (!wallpaperData || !wallpaperData.type) {
    return res.status(400).json({
      status: 'error',
      message: 'Invalid wallpaper data. Type is required.'
    });
  }
  
  inMemoryDB.wallpapers.current = wallpaperData;
  
  res.json({
    status: 'success',
    message: 'Wallpaper set successfully',
    data: wallpaperData
  });
});

// ===== App Category APIs =====

// Get all app categories
app.get('/api/categories', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.appCategories
  });
});

// Update app categories
app.post('/api/categories', (req, res) => {
  const categories = req.body;
  
  if (!categories) {
    return res.status(400).json({
      status: 'error',
      message: 'Invalid categories data'
    });
  }
  
  inMemoryDB.appCategories = categories;
  
  res.json({
    status: 'success',
    message: 'Categories updated successfully',
    data: categories
  });
});

// ===== Custom App Groups APIs =====

// Get all custom app groups
app.get('/api/groups', (req, res) => {
  res.json({
    status: 'success',
    data: inMemoryDB.customGroups
  });
});

// Update custom app groups
app.post('/api/groups', (req, res) => {
  const groups = req.body;
  
  if (!groups) {
    return res.status(400).json({
      status: 'error',
      message: 'Invalid groups data'
    });
  }
  
  inMemoryDB.customGroups = groups;
  
  res.json({
    status: 'success',
    message: 'Custom groups updated successfully',
    data: groups
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Server Error:', err);
  res.status(500).json({
    status: 'error',
    message: 'Internal server error',
    error: err.message
  });
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`3D Android Launcher API server running on http://0.0.0.0:${PORT}`);
});
