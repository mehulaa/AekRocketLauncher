/**
 * Feature Manager Service
 * Provides automatic feature detection, installation, and management
 * Allows the launcher to automatically detect and install new features
 */

import { PreferenceService } from './PreferenceService';
import { LocalizationService } from './LocalizationService';

// Feature registry object - stores all available and installed features
class FeatureManagerServiceClass {
  constructor() {
    this.availableFeatures = {};
    this.installedFeatures = {};
    this.featureSources = [];
    this.listeners = [];
    this.initialized = false;
    this.updateChecking = false;
    this.latestFeatureId = 0;
    
    // Repository endpoint for fetching new features
    this.featuresEndpoint = 'https://api.launcher3d.example.com/features';
    
    // Default feature sources - can be extended by users
    this.defaultFeatureSources = [
      { 
        id: 'official',
        name: 'Official Features',
        url: this.featuresEndpoint,
        trusted: true 
      },
      { 
        id: 'community',
        name: 'Community Features',
        url: 'https://community.launcher3d.example.com/features',
        trusted: false 
      }
    ];
  }

  /**
   * Initialize the feature manager service
   */
  async initialize() {
    if (this.initialized) return true;
    
    try {
      // Load saved feature sources
      const savedSourcesJson = await PreferenceService.getItem('featureSources', null);
      if (savedSourcesJson) {
        this.featureSources = JSON.parse(savedSourcesJson);
      } else {
        this.featureSources = [...this.defaultFeatureSources];
        await PreferenceService.setItem('featureSources', JSON.stringify(this.featureSources));
      }
      
      // Load installed features
      const installedFeaturesJson = await PreferenceService.getItem('installedFeatures', '{}');
      this.installedFeatures = JSON.parse(installedFeaturesJson);
      
      // Load latest feature ID
      this.latestFeatureId = await PreferenceService.getItem('latestFeatureId', 0);
      
      this.initialized = true;
      
      // Start checking for updates (but don't await it)
      this.checkForUpdates();
      
      return true;
    } catch (error) {
      console.error('Failed to initialize FeatureManagerService:', error);
      return false;
    }
  }
  
  /**
   * Check for new features and updates
   */
  async checkForUpdates() {
    if (this.updateChecking) return;
    
    this.updateChecking = true;
    
    try {
      // Notify listeners that update checking began
      this._notifyListeners('update_check_began');
      
      // For each feature source, fetch available features
      for (const source of this.featureSources) {
        if (!source.enabled && source.id !== 'official') continue;
        
        try {
          // In a real app, this would be an actual API call
          // For this prototype, we'll simulate it
          const newFeatures = await this._simulateFetchFeatures(source);
          
          // Add newly discovered features to available features
          for (const feature of newFeatures) {
            const featureId = `${source.id}:${feature.id}`;
            this.availableFeatures[featureId] = {
              ...feature,
              sourceId: source.id,
              featureId: featureId,
              trusted: source.trusted,
              discoveredAt: new Date().toISOString()
            };
          }
        } catch (error) {
          console.error(`Failed to fetch features from source ${source.id}:`, error);
        }
      }
      
      // Check for features that should be auto-installed
      const autoInstallFeatures = Object.values(this.availableFeatures).filter(
        feature => feature.autoInstall && feature.trusted && !this.installedFeatures[feature.featureId]
      );
      
      if (autoInstallFeatures.length > 0) {
        // Notify about features that can be auto-installed
        this._notifyListeners('auto_install_available', autoInstallFeatures);
        
        // Auto-install trusted features if enabled
        const autoInstallEnabled = await PreferenceService.getItem('autoInstallFeatures', false);
        
        if (autoInstallEnabled) {
          for (const feature of autoInstallFeatures) {
            await this.installFeature(feature.featureId);
          }
        }
      }
      
      // Notify listeners that update checking is complete
      this._notifyListeners('update_check_completed', {
        newFeaturesCount: Object.keys(this.availableFeatures).length - Object.keys(this.installedFeatures).length,
        updatesAvailable: autoInstallFeatures.length > 0
      });
      
      // Save the latest state
      await this._saveState();
    } catch (error) {
      console.error('Error checking for updates:', error);
      this._notifyListeners('update_check_failed', { error: error.message });
    } finally {
      this.updateChecking = false;
    }
  }
  
  /**
   * Simulate fetching features from a source (for prototype)
   */
  async _simulateFetchFeatures(source) {
    // In a real app, this would be an API call
    // For prototype, we'll return simulated data
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay
    
    // Generate a new feature based on the latest ID
    const newId = this.latestFeatureId + 1;
    this.latestFeatureId = newId;
    
    // Save the latest feature ID
    await PreferenceService.setItem('latestFeatureId', this.latestFeatureId);
    
    // Different feature types based on the source
    if (source.id === 'official') {
      return [
        {
          id: `feature_${newId}`,
          name: `New AI Recommendation ${newId}`,
          description: 'Uses AI to learn your usage patterns and recommend apps based on context, time, and location.',
          version: '1.0.0',
          type: 'service',
          autoInstall: true,
          dependencies: [],
          files: [
            {
              path: 'src/services/AIRecommendationService.js',
              content: `/**
 * AI Recommendation Service - v${newId}.0.0
 * Uses AI to recommend apps based on context
 */
class AIRecommendationServiceClass {
  constructor() {
    this.initialized = false;
    this.recommendations = [];
  }
  
  async initialize() {
    this.initialized = true;
    console.log('AI Recommendation Service initialized');
    return true;
  }
  
  async getRecommendations(context = {}) {
    // In a real implementation, this would use ML to provide recommendations
    return [
      { appId: 'com.example.app1', score: 0.95, reason: 'Frequently used at this time' },
      { appId: 'com.example.app2', score: 0.85, reason: 'Used in similar locations' },
      { appId: 'com.example.app3', score: 0.75, reason: 'Recently opened' }
    ];
  }
}

export const AIRecommendationService = new AIRecommendationServiceClass();`
            },
            {
              path: 'src/components/AIRecommendations.js',
              content: `/**
 * AI Recommendations Component - v${newId}.0.0
 * Displays AI-powered app recommendations
 */
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { AIRecommendationService } from '../services/AIRecommendationService';

const AIRecommendations = ({ onAppSelect }) => {
  const [recommendations, setRecommendations] = useState([]);
  
  useEffect(() => {
    const loadRecommendations = async () => {
      const recs = await AIRecommendationService.getRecommendations();
      setRecommendations(recs);
    };
    
    loadRecommendations();
  }, []);
  
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Recommended for you</Text>
      <ScrollView horizontal>
        {recommendations.map((rec, index) => (
          <TouchableOpacity 
            key={index} 
            style={styles.recommendation}
            onPress={() => onAppSelect && onAppSelect(rec.appId)}
          >
            <Text style={styles.appName}>{rec.appId}</Text>
            <Text style={styles.reason}>{rec.reason}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  recommendation: {
    padding: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    marginRight: 8,
    width: 120,
  },
  appName: {
    fontWeight: 'bold',
    marginBottom: 4,
  },
  reason: {
    fontSize: 12,
    opacity: 0.7,
  }
});

export default AIRecommendations;`
            }
          ],
          installSteps: [
            {
              type: 'create_file',
              path: 'src/services/AIRecommendationService.js'
            },
            {
              type: 'create_file',
              path: 'src/components/AIRecommendations.js'
            }
          ]
        }
      ];
    } else if (source.id === 'community') {
      return [
        {
          id: `community_feature_${newId}`,
          name: `Weather Widget ${newId}`,
          description: 'Interactive weather widget with animations for your home screen.',
          version: '1.0.0',
          type: 'widget',
          autoInstall: false,
          dependencies: [],
          files: [
            {
              path: 'src/components/widgets/WeatherWidget.js',
              content: `/**
 * Weather Widget - v${newId}.0.0
 * Interactive weather widget with animations
 */
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const WeatherWidget = ({ location = 'New Delhi', theme }) => {
  const [weather, setWeather] = useState({
    temp: 28,
    condition: 'sunny',
    humidity: 45,
    wind: 10
  });
  
  const fadeAnim = useState(new Animated.Value(0))[0];
  
  useEffect(() => {
    // Fade in animation
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true
    }).start();
    
    // In a real widget, we would fetch actual weather data here
  }, []);
  
  // Get weather icon based on condition
  const getWeatherIcon = () => {
    switch (weather.condition) {
      case 'sunny': return 'weather-sunny';
      case 'cloudy': return 'weather-cloudy';
      case 'rainy': return 'weather-rainy';
      case 'storm': return 'weather-lightning';
      default: return 'weather-partly-cloudy';
    }
  };
  
  return (
    <Animated.View style={[
      styles.container,
      { opacity: fadeAnim },
      theme && { 
        backgroundColor: theme.cardColor,
        borderRadius: theme.borderRadius
      }
    ]}>
      <View style={styles.header}>
        <Text style={[styles.location, theme && { color: theme.textColor }]}>
          {location}
        </Text>
      </View>
      
      <View style={styles.content}>
        <Icon name={getWeatherIcon()} size={48} color={theme ? theme.primaryColor : '#2196F3'} />
        <Text style={[styles.temperature, theme && { color: theme.textColor }]}>
          {weather.temp}°C
        </Text>
      </View>
      
      <View style={styles.details}>
        <View style={styles.detailItem}>
          <Icon name="water-percent" size={16} color={theme ? theme.secondaryColor : '#FFC107'} />
          <Text style={[styles.detailText, theme && { color: theme.textColor }]}>
            {weather.humidity}%
          </Text>
        </View>
        
        <View style={styles.detailItem}>
          <Icon name="weather-windy" size={16} color={theme ? theme.secondaryColor : '#FFC107'} />
          <Text style={[styles.detailText, theme && { color: theme.textColor }]}>
            {weather.wind} km/h
          </Text>
        </View>
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: 160,
    height: 160,
    padding: 10,
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    elevation: 2,
  },
  header: {
    alignItems: 'center',
  },
  location: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  temperature: {
    fontSize: 32,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  details: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  detailText: {
    marginLeft: 4,
    fontSize: 12,
  }
});

export default WeatherWidget;`
            }
          ],
          installSteps: [
            {
              type: 'create_file',
              path: 'src/components/widgets/WeatherWidget.js'
            }
          ]
        }
      ];
    } else {
      return [];
    }
  }
  
  /**
   * Install a feature by its ID
   */
  async installFeature(featureId) {
    try {
      // Check if feature exists
      const feature = this.availableFeatures[featureId];
      if (!feature) {
        throw new Error(`Feature ${featureId} not found`);
      }
      
      // Check if feature is already installed
      if (this.installedFeatures[featureId]) {
        return { success: true, message: 'Feature already installed' };
      }
      
      // Notify listeners that installation has begun
      this._notifyListeners('install_began', { feature });
      
      // Execute install steps
      for (const step of feature.installSteps) {
        await this._executeInstallStep(step, feature);
      }
      
      // Mark feature as installed
      this.installedFeatures[featureId] = {
        ...feature,
        installedAt: new Date().toISOString()
      };
      
      // Save installed features to storage
      await PreferenceService.setItem('installedFeatures', JSON.stringify(this.installedFeatures));
      
      // Notify listeners that installation is complete
      this._notifyListeners('install_completed', { feature });
      
      return { success: true, message: 'Feature installed successfully' };
    } catch (error) {
      console.error(`Failed to install feature ${featureId}:`, error);
      this._notifyListeners('install_failed', { featureId, error: error.message });
      return { success: false, message: error.message };
    }
  }
  
  /**
   * Uninstall a feature by its ID
   */
  async uninstallFeature(featureId) {
    try {
      // Check if feature is installed
      const feature = this.installedFeatures[featureId];
      if (!feature) {
        throw new Error(`Feature ${featureId} not installed`);
      }
      
      // Notify listeners that uninstallation has begun
      this._notifyListeners('uninstall_began', { feature });
      
      // Execute uninstall steps (reverse of install)
      for (const step of [...feature.installSteps].reverse()) {
        await this._executeUninstallStep(step, feature);
      }
      
      // Remove feature from installed features
      delete this.installedFeatures[featureId];
      
      // Save installed features to storage
      await PreferenceService.setItem('installedFeatures', JSON.stringify(this.installedFeatures));
      
      // Notify listeners that uninstallation is complete
      this._notifyListeners('uninstall_completed', { feature });
      
      return { success: true, message: 'Feature uninstalled successfully' };
    } catch (error) {
      console.error(`Failed to uninstall feature ${featureId}:`, error);
      this._notifyListeners('uninstall_failed', { featureId, error: error.message });
      return { success: false, message: error.message };
    }
  }
  
  /**
   * Execute an installation step
   */
  async _executeInstallStep(step, feature) {
    // In a real app, this would perform file I/O operations
    // For the prototype, we'll just log the operations
    
    const fileContent = feature.files.find(f => f.path === step.path)?.content;
    
    switch (step.type) {
      case 'create_file':
        console.log(`Creating file: ${step.path}`);
        // In a real app: await FileSystem.writeFile(step.path, fileContent);
        break;
        
      case 'update_file':
        console.log(`Updating file: ${step.path}`);
        // In a real app: await FileSystem.appendFile(step.path, fileContent);
        break;
        
      case 'delete_file':
        console.log(`Deleting file: ${step.path}`);
        // In a real app: await FileSystem.unlink(step.path);
        break;
        
      case 'install_dependency':
        console.log(`Installing dependency: ${step.dependency}`);
        // In a real app: await this._installDependency(step.dependency);
        break;
        
      default:
        console.warn(`Unknown install step type: ${step.type}`);
    }
  }
  
  /**
   * Execute an uninstallation step
   */
  async _executeUninstallStep(step, feature) {
    // Reverse the installation steps
    switch (step.type) {
      case 'create_file':
        console.log(`Deleting file: ${step.path}`);
        // In a real app: await FileSystem.unlink(step.path);
        break;
        
      case 'update_file':
        console.log(`Reverting file: ${step.path}`);
        // In a real app: await FileSystem.readFile(step.path) and then restore original content
        break;
        
      case 'install_dependency':
        console.log(`Uninstalling dependency: ${step.dependency}`);
        // In a real app: await this._uninstallDependency(step.dependency);
        break;
        
      default:
        console.warn(`Unknown uninstall step type: ${step.type}`);
    }
  }
  
  /**
   * Add a feature source
   */
  async addFeatureSource(source) {
    if (!source.id || !source.name || !source.url) {
      throw new Error('Invalid feature source. Must include id, name, and url.');
    }
    
    // Check for duplicate ID
    if (this.featureSources.some(s => s.id === source.id)) {
      throw new Error(`Feature source with ID ${source.id} already exists`);
    }
    
    // Add source with default values
    this.featureSources.push({
      ...source,
      trusted: source.trusted || false,
      enabled: source.enabled !== undefined ? source.enabled : true,
      addedAt: new Date().toISOString()
    });
    
    // Save sources to storage
    await this._saveState();
    
    // Notify listeners
    this._notifyListeners('source_added', { source });
    
    return true;
  }
  
  /**
   * Remove a feature source
   */
  async removeFeatureSource(sourceId) {
    // Can't remove official source
    if (sourceId === 'official') {
      throw new Error('Cannot remove the official feature source');
    }
    
    // Find source index
    const index = this.featureSources.findIndex(s => s.id === sourceId);
    if (index === -1) {
      throw new Error(`Feature source with ID ${sourceId} not found`);
    }
    
    // Remove source
    const removedSource = this.featureSources.splice(index, 1)[0];
    
    // Remove features from this source
    Object.keys(this.availableFeatures).forEach(featureId => {
      if (featureId.startsWith(`${sourceId}:`)) {
        delete this.availableFeatures[featureId];
      }
    });
    
    // Save state
    await this._saveState();
    
    // Notify listeners
    this._notifyListeners('source_removed', { source: removedSource });
    
    return true;
  }
  
  /**
   * Update the settings for a feature source
   */
  async updateFeatureSource(sourceId, updates) {
    // Find source index
    const index = this.featureSources.findIndex(s => s.id === sourceId);
    if (index === -1) {
      throw new Error(`Feature source with ID ${sourceId} not found`);
    }
    
    // Get current source
    const source = this.featureSources[index];
    
    // Update source
    this.featureSources[index] = {
      ...source,
      ...updates,
      id: source.id, // Cannot change ID
      updatedAt: new Date().toISOString()
    };
    
    // Save state
    await this._saveState();
    
    // Notify listeners
    this._notifyListeners('source_updated', { source: this.featureSources[index] });
    
    return true;
  }
  
  /**
   * Save state to storage
   */
  async _saveState() {
    await PreferenceService.setItem('featureSources', JSON.stringify(this.featureSources));
    await PreferenceService.setItem('installedFeatures', JSON.stringify(this.installedFeatures));
    await PreferenceService.setItem('latestFeatureId', this.latestFeatureId);
  }
  
  /**
   * Get all available features
   */
  getAvailableFeatures() {
    return Object.values(this.availableFeatures);
  }
  
  /**
   * Get all installed features
   */
  getInstalledFeatures() {
    return Object.values(this.installedFeatures);
  }
  
  /**
   * Get all feature sources
   */
  getFeatureSources() {
    return [...this.featureSources];
  }
  
  /**
   * Get feature by ID
   */
  getFeature(featureId) {
    return this.availableFeatures[featureId] || null;
  }
  
  /**
   * Check if a feature is installed
   */
  isFeatureInstalled(featureId) {
    return !!this.installedFeatures[featureId];
  }
  
  /**
   * Get settings
   */
  async getSettings() {
    return {
      autoInstallFeatures: await PreferenceService.getItem('autoInstallFeatures', false),
      checkFrequency: await PreferenceService.getItem('featureCheckFrequency', 'daily'),
      notifyOnNewFeatures: await PreferenceService.getItem('notifyOnNewFeatures', true)
    };
  }
  
  /**
   * Update settings
   */
  async updateSettings(settings) {
    if (settings.autoInstallFeatures !== undefined) {
      await PreferenceService.setItem('autoInstallFeatures', settings.autoInstallFeatures);
    }
    
    if (settings.checkFrequency) {
      await PreferenceService.setItem('featureCheckFrequency', settings.checkFrequency);
    }
    
    if (settings.notifyOnNewFeatures !== undefined) {
      await PreferenceService.setItem('notifyOnNewFeatures', settings.notifyOnNewFeatures);
    }
    
    // Notify listeners
    this._notifyListeners('settings_updated', { settings: await this.getSettings() });
    
    return true;
  }
  
  /**
   * Subscribe to events
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from events
   */
  unsubscribe(listener) {
    const index = this.listeners.indexOf(listener);
    if (index !== -1) {
      this.listeners.splice(index, 1);
    }
  }
  
  /**
   * Notify all listeners
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in feature manager listener:', error);
      }
    });
  }
}

// Export singleton instance
export const FeatureManagerService = new FeatureManagerServiceClass();