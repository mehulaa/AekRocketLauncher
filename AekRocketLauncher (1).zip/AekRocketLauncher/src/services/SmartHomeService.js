/**
 * Service for Smart Home Integration
 * Control and monitor smart home devices directly from the launcher
 */

class SmartHomeServiceClass {
  constructor() {
    // State
    this.state = {
      enabled: true,
      connectedHubs: [],
      devices: {}, // Map of device IDs to device objects
      rooms: {}, // Map of room IDs to room objects
      routines: [], // Automated routines
      deviceCategories: [
        'lighting', 'thermostat', 'security', 'entertainment', 
        'appliance', 'sensor', 'switch', 'camera'
      ],
      favorites: [], // Favorite devices for quick access
      lastCommands: [], // Recent commands history
      userPreferences: {
        showOnHomeScreen: true,
        groupByRoom: true,
        quickActions: ['lights_off', 'night_mode', 'morning_mode'],
        voiceControl: true,
        notifyStateChanges: true,
        showDeviceDetails: true
      },
      connectionStatus: {
        connected: false,
        lastSync: null
      },
      initialized: false
    };
    
    // Listeners
    this.listeners = [];
    
    // Sync interval
    this.syncInterval = null;
  }
  
  /**
   * Initialize the smart home service
   */
  async initialize() {
    if (this.state.initialized) {
      return true;
    }
    
    try {
      // Load saved settings
      await this._loadSettings();
      
      // Discover and connect to smart home hubs
      await this._discoverHubs();
      
      // Load devices, rooms, and routines
      await this._loadDevices();
      await this._loadRooms();
      await this._loadRoutines();
      
      // Load user preferences and favorites
      await this._loadUserPreferences();
      
      this.state.initialized = true;
      console.log('SmartHomeService initialized');
      
      // Start periodic sync if connected
      if (this.state.connectionStatus.connected) {
        this._startSync();
      }
      
      // Notify listeners
      this._notifyListeners('serviceInitialized', {
        success: true,
        connected: this.state.connectionStatus.connected
      });
      
      return true;
    } catch (error) {
      console.error('Failed to initialize SmartHomeService:', error);
      return false;
    }
  }
  
  /**
   * Load saved settings from storage
   */
  async _loadSettings() {
    // In a real app, this would load from device storage
    console.log('SmartHomeService: Loading settings...');
  }
  
  /**
   * Discover smart home hubs
   */
  async _discoverHubs() {
    // In a real app, this would discover actual smart home hubs on the network
    // For the prototype, we'll simulate a successful discovery
    
    console.log('SmartHomeService: Discovering hubs...');
    
    // Simulate a 50% chance of finding a hub
    const hubFound = Math.random() > 0.5;
    
    if (hubFound) {
      // Simulate having found a hub
      this.state.connectedHubs.push({
        id: 'hub_001',
        name: 'Home Hub',
        manufacturer: 'SmartLife',
        protocol: 'zigbee',
        ipAddress: '192.168.1.100',
        connectedDevices: 8,
        firmwareVersion: '2.1.5',
        lastSeen: new Date().toISOString()
      });
      
      this.state.connectionStatus.connected = true;
      this.state.connectionStatus.lastSync = new Date().toISOString();
    }
    
    return this.state.connectedHubs;
  }
  
  /**
   * Load devices from connected hubs
   */
  async _loadDevices() {
    if (!this.state.connectionStatus.connected) {
      return;
    }
    
    console.log('SmartHomeService: Loading devices...');
    
    // In a real app, this would load actual devices from connected hubs
    // For the prototype, we'll use some example devices
    
    const devices = {
      'device_light_livingroom': {
        id: 'device_light_livingroom',
        name: 'Living Room Light',
        type: 'lighting',
        room: 'living_room',
        manufacturer: 'PhilipsHue',
        model: 'Color Bulb',
        firmware: '1.5.2',
        capabilities: ['on_off', 'brightness', 'color'],
        state: {
          on: false,
          brightness: 80,
          color: { h: 240, s: 100, v: 100 }, // Blue
          online: true
        },
        lastUpdated: new Date().toISOString()
      },
      'device_light_kitchen': {
        id: 'device_light_kitchen',
        name: 'Kitchen Light',
        type: 'lighting',
        room: 'kitchen',
        manufacturer: 'PhilipsHue',
        model: 'White Bulb',
        firmware: '1.4.8',
        capabilities: ['on_off', 'brightness'],
        state: {
          on: false,
          brightness: 100,
          online: true
        },
        lastUpdated: new Date().toISOString()
      },
      'device_thermostat': {
        id: 'device_thermostat',
        name: 'Home Thermostat',
        type: 'thermostat',
        room: 'living_room',
        manufacturer: 'Nest',
        model: 'Learning Thermostat',
        firmware: '5.6.1',
        capabilities: ['temperature', 'mode', 'fan'],
        state: {
          on: true,
          temperature: 22.5,
          targetTemperature: 23,
          mode: 'heat',
          fan: 'auto',
          online: true
        },
        lastUpdated: new Date().toISOString()
      },
      'device_tv': {
        id: 'device_tv',
        name: 'Living Room TV',
        type: 'entertainment',
        room: 'living_room',
        manufacturer: 'Samsung',
        model: 'Smart TV',
        firmware: '3.2.1',
        capabilities: ['on_off', 'input', 'volume'],
        state: {
          on: false,
          input: 'hdmi1',
          volume: 45,
          muted: false,
          online: true
        },
        lastUpdated: new Date().toISOString()
      },
      'device_door_lock': {
        id: 'device_door_lock',
        name: 'Front Door',
        type: 'security',
        room: 'entrance',
        manufacturer: 'Yale',
        model: 'Smart Lock',
        firmware: '2.0.3',
        capabilities: ['lock', 'battery'],
        state: {
          locked: true,
          batteryLevel: 87,
          online: true
        },
        lastUpdated: new Date().toISOString()
      },
      'device_camera': {
        id: 'device_camera',
        name: 'Front Door Camera',
        type: 'camera',
        room: 'entrance',
        manufacturer: 'Ring',
        model: 'Doorbell Pro',
        firmware: '4.1.0',
        capabilities: ['video', 'motion', 'battery'],
        state: {
          on: true,
          motionDetected: false,
          batteryLevel: 92,
          online: true
        },
        lastUpdated: new Date().toISOString()
      },
      'device_washer': {
        id: 'device_washer',
        name: 'Washing Machine',
        type: 'appliance',
        room: 'laundry',
        manufacturer: 'LG',
        model: 'Smart Washer',
        firmware: '2.3.4',
        capabilities: ['on_off', 'mode', 'timer'],
        state: {
          on: false,
          mode: 'normal',
          timeRemaining: 0,
          online: true
        },
        lastUpdated: new Date().toISOString()
      },
      'device_air_purifier': {
        id: 'device_air_purifier',
        name: 'Bedroom Air Purifier',
        type: 'appliance',
        room: 'bedroom',
        manufacturer: 'Dyson',
        model: 'Pure Cool',
        firmware: '1.9.2',
        capabilities: ['on_off', 'mode', 'fan_speed', 'air_quality'],
        state: {
          on: true,
          mode: 'auto',
          fanSpeed: 5,
          airQuality: 'good',
          online: true
        },
        lastUpdated: new Date().toISOString()
      }
    };
    
    this.state.devices = devices;
    
    // Set some devices as favorites
    this.state.favorites = [
      'device_light_livingroom',
      'device_thermostat',
      'device_door_lock'
    ];
  }
  
  /**
   * Load rooms configuration
   */
  async _loadRooms() {
    if (!this.state.connectionStatus.connected) {
      return;
    }
    
    console.log('SmartHomeService: Loading rooms...');
    
    // In a real app, this would load room configuration from connected hubs
    // For the prototype, we'll use some example rooms
    
    const rooms = {
      'living_room': {
        id: 'living_room',
        name: 'Living Room',
        icon: 'living-room',
        devices: ['device_light_livingroom', 'device_thermostat', 'device_tv'],
        order: 1
      },
      'kitchen': {
        id: 'kitchen',
        name: 'Kitchen',
        icon: 'kitchen',
        devices: ['device_light_kitchen'],
        order: 2
      },
      'bedroom': {
        id: 'bedroom',
        name: 'Bedroom',
        icon: 'bedroom',
        devices: ['device_air_purifier'],
        order: 3
      },
      'entrance': {
        id: 'entrance',
        name: 'Entrance',
        icon: 'door',
        devices: ['device_door_lock', 'device_camera'],
        order: 4
      },
      'laundry': {
        id: 'laundry',
        name: 'Laundry Room',
        icon: 'washing-machine',
        devices: ['device_washer'],
        order: 5
      }
    };
    
    this.state.rooms = rooms;
  }
  
  /**
   * Load automated routines
   */
  async _loadRoutines() {
    if (!this.state.connectionStatus.connected) {
      return;
    }
    
    console.log('SmartHomeService: Loading routines...');
    
    // In a real app, this would load routines from connected hubs
    // For the prototype, we'll use some example routines
    
    this.state.routines = [
      {
        id: 'routine_morning',
        name: 'Good Morning',
        icon: 'wb-sunny',
        trigger: {
          type: 'time',
          time: '07:00',
          days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
        },
        actions: [
          {
            deviceId: 'device_light_livingroom',
            command: 'setState',
            parameters: { on: true, brightness: 100 }
          },
          {
            deviceId: 'device_thermostat',
            command: 'setState',
            parameters: { targetTemperature: 22 }
          }
        ],
        lastRun: '2025-03-09T07:00:00Z',
        enabled: true
      },
      {
        id: 'routine_night',
        name: 'Good Night',
        icon: 'nights-stay',
        trigger: {
          type: 'time',
          time: '23:00',
          days: ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
        },
        actions: [
          {
            deviceId: 'device_light_livingroom',
            command: 'setState',
            parameters: { on: false }
          },
          {
            deviceId: 'device_light_kitchen',
            command: 'setState',
            parameters: { on: false }
          },
          {
            deviceId: 'device_thermostat',
            command: 'setState',
            parameters: { targetTemperature: 19 }
          },
          {
            deviceId: 'device_door_lock',
            command: 'setState',
            parameters: { locked: true }
          }
        ],
        lastRun: '2025-03-08T23:00:00Z',
        enabled: true
      },
      {
        id: 'routine_away',
        name: 'Away Mode',
        icon: 'flight',
        trigger: {
          type: 'manual'
        },
        actions: [
          {
            deviceId: 'device_light_livingroom',
            command: 'setState',
            parameters: { on: false }
          },
          {
            deviceId: 'device_light_kitchen',
            command: 'setState',
            parameters: { on: false }
          },
          {
            deviceId: 'device_thermostat',
            command: 'setState',
            parameters: { mode: 'eco' }
          },
          {
            deviceId: 'device_door_lock',
            command: 'setState',
            parameters: { locked: true }
          },
          {
            deviceId: 'device_air_purifier',
            command: 'setState',
            parameters: { on: false }
          }
        ],
        lastRun: null,
        enabled: true
      }
    ];
  }
  
  /**
   * Load user preferences
   */
  async _loadUserPreferences() {
    // In a real app, this would load from device storage
    // For the prototype, we use default values set in constructor
    console.log('SmartHomeService: Loading user preferences...');
  }
  
  /**
   * Start periodic sync with smart home hubs
   */
  _startSync() {
    // Clear any existing interval
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
    }
    
    // Sync every minute
    this.syncInterval = setInterval(() => {
      this._syncDeviceStates();
    }, 60000);
    
    // Do an immediate sync
    this._syncDeviceStates();
  }
  
  /**
   * Sync device states with connected hubs
   */
  async _syncDeviceStates() {
    if (!this.state.connectionStatus.connected) {
      return;
    }
    
    console.log('SmartHomeService: Syncing device states...');
    
    // In a real app, this would query actual devices for their current states
    // For the prototype, we'll simulate random state changes
    
    const changedDevices = [];
    
    for (const [deviceId, device] of Object.entries(this.state.devices)) {
      // 20% chance of a state change
      if (Math.random() < 0.2) {
        // Create a copy of the device
        const updatedDevice = { ...device };
        
        // Simulate a state change based on device type
        switch (device.type) {
          case 'lighting':
            if (device.capabilities.includes('on_off')) {
              updatedDevice.state.on = Math.random() > 0.5;
            }
            if (device.capabilities.includes('brightness')) {
              updatedDevice.state.brightness = Math.floor(Math.random() * 100) + 1;
            }
            break;
            
          case 'thermostat':
            if (device.capabilities.includes('temperature')) {
              // Slight temperature fluctuation
              updatedDevice.state.temperature = 
                parseFloat((device.state.temperature + (Math.random() * 0.6 - 0.3)).toFixed(1));
            }
            break;
            
          case 'security':
            if (deviceId === 'device_door_lock' && Math.random() > 0.8) {
              updatedDevice.state.locked = !device.state.locked;
            }
            break;
            
          case 'camera':
            if (device.capabilities.includes('motion')) {
              updatedDevice.state.motionDetected = Math.random() > 0.8;
            }
            break;
            
          case 'appliance':
            if (deviceId === 'device_washer') {
              // Randomly start the washer
              if (!device.state.on && Math.random() > 0.9) {
                updatedDevice.state.on = true;
                updatedDevice.state.timeRemaining = 45;
              }
              // Decrease time remaining if washer is on
              else if (device.state.on && device.state.timeRemaining > 0) {
                updatedDevice.state.timeRemaining = Math.max(0, device.state.timeRemaining - 1);
                if (updatedDevice.state.timeRemaining === 0) {
                  updatedDevice.state.on = false;
                }
              }
            }
            break;
        }
        
        // Update timestamp
        updatedDevice.state.lastUpdated = new Date().toISOString();
        
        // Save the updated device
        this.state.devices[deviceId] = updatedDevice;
        
        // Add to changed devices list
        changedDevices.push(updatedDevice);
      }
    }
    
    // Update last sync time
    this.state.connectionStatus.lastSync = new Date().toISOString();
    
    // Notify listeners if any devices changed
    if (changedDevices.length > 0) {
      this._notifyListeners('devicesUpdated', {
        devices: changedDevices,
        timestamp: new Date().toISOString()
      });
    }
  }
  
  /**
   * Control a device
   */
  async controlDevice(deviceId, command, parameters = {}) {
    if (!this.state.connectionStatus.connected) {
      return {
        success: false,
        error: 'Not connected to any smart home hub'
      };
    }
    
    const device = this.state.devices[deviceId];
    
    if (!device) {
      return {
        success: false,
        error: 'Device not found'
      };
    }
    
    if (!device.state.online) {
      return {
        success: false,
        error: 'Device is offline'
      };
    }
    
    console.log(`Controlling device ${device.name}: ${command}`, parameters);
    
    try {
      // In a real app, this would send the command to the actual device
      // For the prototype, we'll update the local state
      
      switch (command) {
        case 'turnOn':
          if (!device.capabilities.includes('on_off')) {
            throw new Error('Device does not support on/off capability');
          }
          device.state.on = true;
          break;
          
        case 'turnOff':
          if (!device.capabilities.includes('on_off')) {
            throw new Error('Device does not support on/off capability');
          }
          device.state.on = false;
          break;
          
        case 'setBrightness':
          if (!device.capabilities.includes('brightness')) {
            throw new Error('Device does not support brightness capability');
          }
          if (typeof parameters.brightness !== 'number' || parameters.brightness < 0 || parameters.brightness > 100) {
            throw new Error('Invalid brightness value');
          }
          device.state.brightness = parameters.brightness;
          break;
          
        case 'setColor':
          if (!device.capabilities.includes('color')) {
            throw new Error('Device does not support color capability');
          }
          if (!parameters.color || typeof parameters.color !== 'object') {
            throw new Error('Invalid color value');
          }
          device.state.color = parameters.color;
          break;
          
        case 'setTemperature':
          if (!device.capabilities.includes('temperature')) {
            throw new Error('Device does not support temperature capability');
          }
          if (typeof parameters.temperature !== 'number') {
            throw new Error('Invalid temperature value');
          }
          device.state.targetTemperature = parameters.temperature;
          break;
          
        case 'setMode':
          if (!device.capabilities.includes('mode')) {
            throw new Error('Device does not support mode capability');
          }
          if (!parameters.mode) {
            throw new Error('Missing mode parameter');
          }
          device.state.mode = parameters.mode;
          break;
          
        case 'lock':
          if (!device.capabilities.includes('lock')) {
            throw new Error('Device does not support lock capability');
          }
          device.state.locked = true;
          break;
          
        case 'unlock':
          if (!device.capabilities.includes('lock')) {
            throw new Error('Device does not support lock capability');
          }
          device.state.locked = false;
          break;
          
        case 'setState':
          // Generic state setting
          if (parameters && typeof parameters === 'object') {
            // Validate that capabilities exist for parameters
            for (const [key, value] of Object.entries(parameters)) {
              if (key === 'on' && !device.capabilities.includes('on_off')) {
                throw new Error('Device does not support on/off capability');
              }
              if (key === 'brightness' && !device.capabilities.includes('brightness')) {
                throw new Error('Device does not support brightness capability');
              }
              if (key === 'color' && !device.capabilities.includes('color')) {
                throw new Error('Device does not support color capability');
              }
              if (key === 'targetTemperature' && !device.capabilities.includes('temperature')) {
                throw new Error('Device does not support temperature capability');
              }
              if (key === 'mode' && !device.capabilities.includes('mode')) {
                throw new Error('Device does not support mode capability');
              }
              if (key === 'locked' && !device.capabilities.includes('lock')) {
                throw new Error('Device does not support lock capability');
              }
            }
            
            // Update state with parameters
            device.state = {
              ...device.state,
              ...parameters
            };
          }
          break;
          
        default:
          return {
            success: false,
            error: `Unknown command: ${command}`
          };
      }
      
      // Update last updated timestamp
      device.state.lastUpdated = new Date().toISOString();
      
      // Add to last commands history
      this.state.lastCommands.unshift({
        deviceId,
        deviceName: device.name,
        command,
        parameters,
        timestamp: new Date().toISOString()
      });
      
      // Keep history at 20 items max
      if (this.state.lastCommands.length > 20) {
        this.state.lastCommands.pop();
      }
      
      // Notify listeners
      this._notifyListeners('deviceControlled', {
        deviceId,
        deviceName: device.name,
        command,
        parameters,
        newState: device.state,
        timestamp: new Date().toISOString()
      });
      
      return {
        success: true,
        device
      };
    } catch (error) {
      console.error(`Error controlling device ${deviceId}:`, error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  /**
   * Run a routine
   */
  async runRoutine(routineId) {
    if (!this.state.connectionStatus.connected) {
      return {
        success: false,
        error: 'Not connected to any smart home hub'
      };
    }
    
    const routine = this.state.routines.find(r => r.id === routineId);
    
    if (!routine) {
      return {
        success: false,
        error: 'Routine not found'
      };
    }
    
    if (!routine.enabled) {
      return {
        success: false,
        error: 'Routine is disabled'
      };
    }
    
    console.log(`Running routine: ${routine.name}`);
    
    try {
      // Execute all actions in the routine
      const results = [];
      
      for (const action of routine.actions) {
        // Control device according to action
        const result = await this.controlDevice(
          action.deviceId,
          action.command,
          action.parameters
        );
        
        results.push({
          deviceId: action.deviceId,
          success: result.success,
          error: result.error
        });
      }
      
      // Update last run time
      routine.lastRun = new Date().toISOString();
      
      // Check for any failures
      const failures = results.filter(r => !r.success);
      
      // Notify listeners
      this._notifyListeners('routineRun', {
        routineId,
        routineName: routine.name,
        results,
        success: failures.length === 0,
        timestamp: new Date().toISOString()
      });
      
      if (failures.length > 0) {
        return {
          success: false,
          message: `Routine partially completed with ${failures.length} failed actions`,
          results
        };
      }
      
      return {
        success: true,
        message: 'Routine completed successfully',
        results
      };
    } catch (error) {
      console.error(`Error running routine ${routineId}:`, error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  /**
   * Add a device to favorites
   */
  addToFavorites(deviceId) {
    if (!this.state.devices[deviceId]) {
      return {
        success: false,
        error: 'Device not found'
      };
    }
    
    if (this.state.favorites.includes(deviceId)) {
      return {
        success: false,
        error: 'Device is already in favorites'
      };
    }
    
    this.state.favorites.push(deviceId);
    
    // Notify listeners
    this._notifyListeners('favoriteAdded', {
      deviceId,
      deviceName: this.state.devices[deviceId].name,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true
    };
  }
  
  /**
   * Remove a device from favorites
   */
  removeFromFavorites(deviceId) {
    const index = this.state.favorites.indexOf(deviceId);
    
    if (index === -1) {
      return {
        success: false,
        error: 'Device not in favorites'
      };
    }
    
    this.state.favorites.splice(index, 1);
    
    // Notify listeners
    this._notifyListeners('favoriteRemoved', {
      deviceId,
      deviceName: this.state.devices[deviceId]?.name || deviceId,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true
    };
  }
  
  /**
   * Update user preferences
   */
  updatePreferences(preferences) {
    this.state.userPreferences = {
      ...this.state.userPreferences,
      ...preferences
    };
    
    // Notify listeners
    this._notifyListeners('preferencesUpdated', {
      preferences: this.state.userPreferences,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Enable or disable a routine
   */
  setRoutineEnabled(routineId, enabled) {
    const routine = this.state.routines.find(r => r.id === routineId);
    
    if (!routine) {
      return {
        success: false,
        error: 'Routine not found'
      };
    }
    
    routine.enabled = enabled;
    
    // Notify listeners
    this._notifyListeners('routineUpdated', {
      routineId,
      routineName: routine.name,
      enabled,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true
    };
  }
  
  /**
   * Attempt to connect to smart home hubs
   */
  async connect() {
    if (this.state.connectionStatus.connected) {
      return {
        success: true,
        message: 'Already connected'
      };
    }
    
    try {
      // Discover hubs
      const hubs = await this._discoverHubs();
      
      if (hubs.length === 0) {
        return {
          success: false,
          error: 'No smart home hubs found'
        };
      }
      
      // Load devices, rooms, and routines
      await this._loadDevices();
      await this._loadRooms();
      await this._loadRoutines();
      
      // Start sync
      this._startSync();
      
      // Notify listeners
      this._notifyListeners('connected', {
        hubs,
        timestamp: new Date().toISOString()
      });
      
      return {
        success: true,
        hubs
      };
    } catch (error) {
      console.error('Connection failed:', error);
      return {
        success: false,
        error: 'Failed to connect to smart home hubs'
      };
    }
  }
  
  /**
   * Disconnect from smart home hubs
   */
  disconnect() {
    if (!this.state.connectionStatus.connected) {
      return {
        success: true,
        message: 'Already disconnected'
      };
    }
    
    // Stop sync
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
    
    // Update connection status
    this.state.connectionStatus.connected = false;
    this.state.connectedHubs = [];
    
    // Notify listeners
    this._notifyListeners('disconnected', {
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true
    };
  }
  
  /**
   * Enable or disable the smart home service
   */
  setEnabled(enabled) {
    this.state.enabled = enabled;
    
    // If disabling, disconnect from hubs
    if (!enabled && this.state.connectionStatus.connected) {
      this.disconnect();
    }
    
    // If enabling, try to connect to hubs
    if (enabled && !this.state.connectionStatus.connected) {
      this.connect();
    }
    
    // Notify listeners
    this._notifyListeners('enabledStateChanged', {
      enabled,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Get all devices
   */
  getDevices() {
    return Object.values(this.state.devices);
  }
  
  /**
   * Get all rooms
   */
  getRooms() {
    return Object.values(this.state.rooms);
  }
  
  /**
   * Get all routines
   */
  getRoutines() {
    return this.state.routines;
  }
  
  /**
   * Get favorite devices
   */
  getFavorites() {
    return this.state.favorites.map(deviceId => this.state.devices[deviceId]).filter(Boolean);
  }
  
  /**
   * Get recent commands
   */
  getRecentCommands() {
    return this.state.lastCommands;
  }
  
  /**
   * Get user preferences
   */
  getPreferences() {
    return this.state.userPreferences;
  }
  
  /**
   * Get devices in a specific room
   */
  getDevicesInRoom(roomId) {
    const room = this.state.rooms[roomId];
    
    if (!room) {
      return [];
    }
    
    return room.devices
      .map(deviceId => this.state.devices[deviceId])
      .filter(Boolean);
  }
  
  /**
   * Get connection status
   */
  getConnectionStatus() {
    return this.state.connectionStatus;
  }
  
  /**
   * Subscribe to smart home events
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from smart home events
   */
  unsubscribe(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  /**
   * Notify all listeners of an event
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in smart home service listener:', error);
      }
    });
  }
  
  /**
   * Clean up the service
   */
  cleanup() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
    
    this.listeners = [];
  }
}

// Export as singleton
export const SmartHomeService = new SmartHomeServiceClass();