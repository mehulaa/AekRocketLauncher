/**
 * Service for gamification features
 * Handles achievements, rewards, challenges and productivity gamification
 */

class GamificationServiceClass {
  constructor() {
    // State
    this.state = {
      enabled: true,
      userData: {
        level: 1,
        experience: 0,
        experienceToNextLevel: 100,
        achievements: [],
        rewards: [],
        challenges: [],
        stats: {},
        streaks: {}
      },
      dailyGoals: {},
      weeklyGoals: {},
      achievements: {},
      rewards: {},
      activities: [],
      gamificationSettings: {
        notifyOnAchievements: true,
        showLevelProgress: true,
        enableChallenges: true,
        enableRewards: true,
        enableLeaderboards: true,
        enableStreaks: true,
        streakNotifications: true,
        privacyMode: false
      },
      initialized: false
    };
    
    // Listeners
    this.listeners = [];
    
    // Achievement check interval
    this.achievementCheckInterval = null;
  }
  
  /**
   * Initialize the gamification service
   */
  async initialize() {
    if (this.state.initialized) {
      return true;
    }
    
    try {
      // Load saved settings
      await this._loadSettings();
      
      // Load user data
      await this._loadUserData();
      
      // Load achievements and rewards definitions
      await this._loadAchievements();
      await this._loadRewards();
      
      // Load goals
      await this._loadGoals();
      
      this.state.initialized = true;
      console.log('GamificationService initialized');
      
      // Start achievement checking if enabled
      if (this.state.enabled) {
        this._startAchievementChecking();
      }
      
      // Notify listeners
      this._notifyListeners('serviceInitialized', { success: true });
      
      return true;
    } catch (error) {
      console.error('Failed to initialize GamificationService:', error);
      return false;
    }
  }
  
  /**
   * Load saved settings from storage
   */
  async _loadSettings() {
    // In a real app, this would load from device storage
    // For the prototype, we use default values
    console.log('GamificationService: Loading settings...');
  }
  
  /**
   * Load user data from storage
   */
  async _loadUserData() {
    // In a real app, this would load from device storage
    // For the prototype, we'll use some example data
    
    // Example user achievements
    this.state.userData.achievements = [
      {
        id: 'first_launch',
        name: 'First Launch',
        description: 'Launch the app for the first time',
        dateUnlocked: '2025-01-15T10:30:00Z',
        progress: 1,
        maxProgress: 1
      },
      {
        id: 'theme_customizer',
        name: 'Theme Customizer',
        description: 'Create your first custom theme',
        dateUnlocked: '2025-01-16T14:25:00Z',
        progress: 1,
        maxProgress: 1
      },
      {
        id: 'app_explorer',
        name: 'App Explorer',
        description: 'Launch 10 different apps',
        dateUnlocked: '2025-01-20T19:45:00Z',
        progress: 10,
        maxProgress: 10
      }
    ];
    
    // Example user rewards
    this.state.userData.rewards = [
      {
        id: 'exclusive_theme',
        name: 'Exclusive Theme',
        description: 'A special theme only for achievers',
        dateUnlocked: '2025-01-20T19:45:00Z',
        claimed: true
      },
      {
        id: 'animated_wallpaper',
        name: 'Premium Animated Wallpaper',
        description: 'A high-quality animated wallpaper',
        dateUnlocked: '2025-02-05T12:10:00Z',
        claimed: false
      }
    ];
    
    // Example stats for achievement checks
    this.state.userData.stats = {
      appsLaunched: 45,
      uniqueAppsLaunched: 12,
      themesCreated: 2,
      widgetsCreated: 1,
      layoutsCreated: 1,
      screenshotsTaken: 3,
      voiceCommandsUsed: 8,
      gesturesCreated: 0,
      appDrawerOpened: 28,
      settingsOpened: 5,
      daysActive: 14,
      totalLaunchCount: 32
    };
    
    // Example streaks
    this.state.userData.streaks = {
      dailyUse: {
        current: 5,
        longest: 12,
        lastUpdated: '2025-03-09T10:15:00Z'
      },
      morningProductivity: {
        current: 3,
        longest: 7,
        lastUpdated: '2025-03-09T08:45:00Z'
      }
    };
    
    // Example challenges
    this.state.userData.challenges = [
      {
        id: 'weekly_productivity',
        name: 'Weekly Productivity Challenge',
        description: 'Use productivity apps for at least 2 hours this week',
        progress: 95,
        maxProgress: 120,
        startDate: '2025-03-06T00:00:00Z',
        endDate: '2025-03-12T23:59:59Z',
        reward: {
          experiencePoints: 50,
          rewardId: 'productivity_badge'
        }
      },
      {
        id: 'gesture_master',
        name: 'Gesture Master Challenge',
        description: 'Create 3 custom gestures and use each one 5 times',
        progress: 0,
        maxProgress: 15,
        startDate: '2025-03-08T00:00:00Z',
        endDate: '2025-03-15T23:59:59Z',
        reward: {
          experiencePoints: 75,
          rewardId: 'gesture_badge'
        }
      }
    ];
  }
  
  /**
   * Load achievements definitions
   */
  async _loadAchievements() {
    // In a real app, this might be loaded from a server for updates
    // For the prototype, we'll define them here
    
    this.state.achievements = {
      // Onboarding Achievements
      'first_launch': {
        name: 'First Launch',
        description: 'Launch the app for the first time',
        category: 'onboarding',
        experiencePoints: 10,
        icon: 'rocket',
        checkFn: (stats) => stats.totalLaunchCount >= 1,
        maxProgress: 1
      },
      'welcome_back': {
        name: 'Welcome Back',
        description: 'Use the launcher for 7 days',
        category: 'onboarding',
        experiencePoints: 25,
        icon: 'calendar-check',
        checkFn: (stats) => stats.daysActive >= 7,
        maxProgress: 7
      },
      
      // Customization Achievements
      'theme_customizer': {
        name: 'Theme Customizer',
        description: 'Create your first custom theme',
        category: 'customization',
        experiencePoints: 15,
        icon: 'palette',
        checkFn: (stats) => stats.themesCreated >= 1,
        maxProgress: 1
      },
      'widget_wizard': {
        name: 'Widget Wizard',
        description: 'Create 3 custom widgets',
        category: 'customization',
        experiencePoints: 30,
        icon: 'widgets',
        checkFn: (stats) => stats.widgetsCreated >= 3,
        maxProgress: 3
      },
      'layout_master': {
        name: 'Layout Master',
        description: 'Create 5 different home screen layouts',
        category: 'customization',
        experiencePoints: 50,
        icon: 'dashboard',
        checkFn: (stats) => stats.layoutsCreated >= 5,
        maxProgress: 5
      },
      
      // Usage Achievements
      'app_explorer': {
        name: 'App Explorer',
        description: 'Launch 10 different apps',
        category: 'usage',
        experiencePoints: 20,
        icon: 'apps',
        checkFn: (stats) => stats.uniqueAppsLaunched >= 10,
        maxProgress: 10
      },
      'power_user': {
        name: 'Power User',
        description: 'Launch 100 apps in total',
        category: 'usage',
        experiencePoints: 40,
        icon: 'bolt',
        checkFn: (stats) => stats.appsLaunched >= 100,
        maxProgress: 100
      },
      
      // Feature Achievements
      'voice_commander': {
        name: 'Voice Commander',
        description: 'Use 10 different voice commands',
        category: 'features',
        experiencePoints: 35,
        icon: 'mic',
        checkFn: (stats) => stats.voiceCommandsUsed >= 10,
        maxProgress: 10
      },
      'gesture_pro': {
        name: 'Gesture Pro',
        description: 'Create and use 5 custom gestures',
        category: 'features',
        experiencePoints: 45,
        icon: 'gesture',
        checkFn: (stats) => stats.gesturesCreated >= 5,
        maxProgress: 5
      },
      
      // Social Achievements
      'community_contributor': {
        name: 'Community Contributor',
        description: 'Share a custom theme or layout with the community',
        category: 'social',
        experiencePoints: 50,
        icon: 'share',
        checkFn: (stats) => stats.contentShared >= 1,
        maxProgress: 1
      },
      
      // Streaks Achievements
      'daily_streak': {
        name: 'Daily Streak',
        description: 'Use the launcher every day for 14 days',
        category: 'streaks',
        experiencePoints: 75,
        icon: 'local-fire-department',
        checkFn: (stats, userData) => userData.streaks?.dailyUse?.current >= 14,
        maxProgress: 14
      }
    };
  }
  
  /**
   * Load rewards definitions
   */
  async _loadRewards() {
    // In a real app, this might be loaded from a server for updates
    // For the prototype, we'll define them here
    
    this.state.rewards = {
      'exclusive_theme': {
        name: 'Exclusive Theme',
        description: 'A special theme only for achievers',
        type: 'theme',
        levelRequired: 2,
        icon: 'star',
        content: {
          id: 'reward_theme_01',
          name: 'Achievement Gold',
          primaryColor: '#FFD700',
          accentColor: '#FFA500',
          isDark: false
        }
      },
      'animated_wallpaper': {
        name: 'Premium Animated Wallpaper',
        description: 'A high-quality animated wallpaper',
        type: 'wallpaper',
        levelRequired: 3,
        icon: 'wallpaper',
        content: {
          id: 'reward_wallpaper_01',
          name: 'Galaxy Particles',
          type: 'animated'
        }
      },
      'advanced_widgets': {
        name: 'Advanced Widget Pack',
        description: 'Unlock premium widgets with additional functionality',
        type: 'widgets',
        levelRequired: 4,
        icon: 'view-module',
        content: {
          widgets: ['widget_pro_1', 'widget_pro_2', 'widget_pro_3']
        }
      },
      'custom_animation': {
        name: 'Custom Animation Set',
        description: 'Special transition animations for your launcher',
        type: 'animations',
        levelRequired: 5,
        icon: 'animation',
        content: {
          animations: ['animation_set_1']
        }
      },
      'productivity_badge': {
        name: 'Productivity Master Badge',
        description: 'A badge to show your productivity accomplishments',
        type: 'badge',
        levelRequired: 0, // Challenge reward
        icon: 'workspace-premium',
        content: {
          id: 'badge_productivity'
        }
      },
      'gesture_badge': {
        name: 'Gesture Guru Badge',
        description: 'A badge to show your gesture mastery',
        type: 'badge',
        levelRequired: 0, // Challenge reward
        icon: 'swipe',
        content: {
          id: 'badge_gesture'
        }
      }
    };
  }
  
  /**
   * Load goals definitions
   */
  async _loadGoals() {
    // Daily goals
    this.state.dailyGoals = {
      'daily_app_launches': {
        name: 'App Launches',
        description: 'Launch 10 apps today',
        target: 10,
        progress: 0,
        experiencePoints: 15,
        icon: 'launch',
        resetDaily: true
      },
      'daily_widgets_interaction': {
        name: 'Widget Interactions',
        description: 'Interact with widgets 5 times',
        target: 5,
        progress: 0,
        experiencePoints: 10,
        icon: 'touch-app',
        resetDaily: true
      },
      'daily_voice_commands': {
        name: 'Voice Commands',
        description: 'Use 3 voice commands',
        target: 3,
        progress: 0,
        experiencePoints: 20,
        icon: 'mic',
        resetDaily: true
      }
    };
    
    // Weekly goals
    this.state.weeklyGoals = {
      'weekly_productivity_time': {
        name: 'Productivity Time',
        description: 'Spend 2 hours using productivity apps',
        target: 120, // minutes
        progress: 0,
        experiencePoints: 50,
        icon: 'work',
        resetWeekly: true
      },
      'weekly_customizations': {
        name: 'Customizations',
        description: 'Make 5 customizations to your launcher',
        target: 5,
        progress: 0,
        experiencePoints: 40,
        icon: 'tune',
        resetWeekly: true
      }
    };
  }
  
  /**
   * Start periodic achievement checking
   */
  _startAchievementChecking() {
    // Check achievements immediately
    this._checkForNewAchievements();
    
    // Set up interval to check achievements (every 5 minutes)
    this.achievementCheckInterval = setInterval(() => {
      this._checkForNewAchievements();
    }, 5 * 60 * 1000);
  }
  
  /**
   * Stop achievement checking
   */
  _stopAchievementChecking() {
    if (this.achievementCheckInterval) {
      clearInterval(this.achievementCheckInterval);
      this.achievementCheckInterval = null;
    }
  }
  
  /**
   * Check for new achievements that can be unlocked
   */
  _checkForNewAchievements() {
    if (!this.state.enabled) {
      return;
    }
    
    console.log('Checking for new achievements...');
    
    // Get current stats and achievements
    const { stats, achievements: unlockedAchievements } = this.state.userData;
    
    // Get IDs of already unlocked achievements
    const unlockedIds = unlockedAchievements.map(a => a.id);
    
    // Check each achievement
    for (const [achievementId, achievement] of Object.entries(this.state.achievements)) {
      // Skip if already unlocked
      if (unlockedIds.includes(achievementId)) {
        continue;
      }
      
      // Check if achievement is unlocked
      const currentProgress = this._calculateAchievementProgress(achievement, stats);
      const isUnlocked = currentProgress >= achievement.maxProgress;
      
      if (isUnlocked) {
        // Add to unlocked achievements
        const newAchievement = {
          id: achievementId,
          name: achievement.name,
          description: achievement.description,
          dateUnlocked: new Date().toISOString(),
          progress: currentProgress,
          maxProgress: achievement.maxProgress
        };
        
        this.state.userData.achievements.push(newAchievement);
        
        // Award experience points
        this._awardExperiencePoints(achievement.experiencePoints, `Achievement: ${achievement.name}`);
        
        // Notify about new achievement
        if (this.state.gamificationSettings.notifyOnAchievements) {
          this._notifyAchievementUnlocked(achievementId, achievement);
        }
      }
    }
  }
  
  /**
   * Calculate progress for an achievement
   */
  _calculateAchievementProgress(achievement, stats) {
    try {
      if (achievement.checkFn) {
        // If the achievement has a check function, use it
        const progress = achievement.checkFn(stats, this.state.userData);
        
        // If the function returns a boolean, convert to 0 or maxProgress
        if (typeof progress === 'boolean') {
          return progress ? achievement.maxProgress : 0;
        }
        
        // If it returns a number, that's the progress
        if (typeof progress === 'number') {
          return Math.min(progress, achievement.maxProgress);
        }
      }
      
      // Default implementation for specific achievement types
      switch (achievement.id) {
        case 'app_explorer':
          return Math.min(stats.uniqueAppsLaunched, achievement.maxProgress);
          
        case 'power_user':
          return Math.min(stats.appsLaunched, achievement.maxProgress);
          
        case 'welcome_back':
          return Math.min(stats.daysActive, achievement.maxProgress);
          
        case 'theme_customizer':
          return Math.min(stats.themesCreated, achievement.maxProgress);
          
        case 'widget_wizard':
          return Math.min(stats.widgetsCreated, achievement.maxProgress);
          
        case 'layout_master':
          return Math.min(stats.layoutsCreated, achievement.maxProgress);
          
        case 'voice_commander':
          return Math.min(stats.voiceCommandsUsed, achievement.maxProgress);
          
        case 'gesture_pro':
          return Math.min(stats.gesturesCreated, achievement.maxProgress);
          
        case 'daily_streak':
          return Math.min(this.state.userData.streaks?.dailyUse?.current || 0, achievement.maxProgress);
          
        default:
          return 0;
      }
    } catch (error) {
      console.error(`Error calculating progress for achievement ${achievement.id}:`, error);
      return 0;
    }
  }
  
  /**
   * Award experience points to the user
   */
  _awardExperiencePoints(points, reason) {
    if (points <= 0) {
      return;
    }
    
    // Add experience points
    this.state.userData.experience += points;
    
    // Add to activity log
    this.state.activities.push({
      type: 'experience_gained',
      points,
      reason,
      timestamp: new Date().toISOString()
    });
    
    // Keep activities from growing too large
    if (this.state.activities.length > 50) {
      this.state.activities.shift();
    }
    
    // Check for level up
    this._checkForLevelUp();
    
    // Notify listeners
    this._notifyListeners('experienceGained', {
      points,
      reason,
      newTotal: this.state.userData.experience,
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * Check if user has leveled up
   */
  _checkForLevelUp() {
    const { level, experience, experienceToNextLevel } = this.state.userData;
    
    if (experience >= experienceToNextLevel) {
      // Level up
      const newLevel = level + 1;
      const remainingExp = experience - experienceToNextLevel;
      const nextLevelExp = Math.floor(experienceToNextLevel * 1.5); // Increase exp needed for next level
      
      // Update user data
      this.state.userData.level = newLevel;
      this.state.userData.experience = remainingExp;
      this.state.userData.experienceToNextLevel = nextLevelExp;
      
      // Add to activity log
      this.state.activities.push({
        type: 'level_up',
        newLevel,
        timestamp: new Date().toISOString()
      });
      
      // Check for rewards at this level
      this._checkForLevelRewards(newLevel);
      
      // Notify listeners
      this._notifyListeners('levelUp', {
        newLevel,
        timestamp: new Date().toISOString()
      });
      
      // Check for further level ups (if user gained a lot of exp)
      this._checkForLevelUp();
    }
  }
  
  /**
   * Check if there are rewards for reaching a specific level
   */
  _checkForLevelRewards(level) {
    // Find rewards available at this level
    const availableRewards = Object.entries(this.state.rewards)
      .filter(([_, reward]) => reward.levelRequired === level)
      .map(([rewardId, reward]) => ({
        id: rewardId,
        name: reward.name,
        description: reward.description,
        type: reward.type,
        dateUnlocked: new Date().toISOString(),
        claimed: false
      }));
    
    if (availableRewards.length > 0) {
      // Add to user rewards
      this.state.userData.rewards.push(...availableRewards);
      
      // Notify about new rewards
      for (const reward of availableRewards) {
        this._notifyRewardUnlocked(reward.id, reward);
      }
    }
  }
  
  /**
   * Notify about a new achievement
   */
  _notifyAchievementUnlocked(achievementId, achievement) {
    console.log(`Achievement unlocked: ${achievement.name}`);
    
    // Notify listeners
    this._notifyListeners('achievementUnlocked', {
      achievementId,
      achievement: {
        id: achievementId,
        name: achievement.name,
        description: achievement.description,
        experiencePoints: achievement.experiencePoints,
        icon: achievement.icon
      },
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * Notify about a new reward
   */
  _notifyRewardUnlocked(rewardId, reward) {
    console.log(`Reward unlocked: ${reward.name}`);
    
    // Notify listeners
    this._notifyListeners('rewardUnlocked', {
      rewardId,
      reward: {
        id: rewardId,
        name: reward.name,
        description: reward.description,
        type: reward.type
      },
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * Track an activity that could contribute to achievements or goals
   */
  trackActivity(activityType, data = {}) {
    if (!this.state.enabled) {
      return;
    }
    
    console.log(`Tracking activity: ${activityType}`, data);
    
    // Update stats based on activity type
    switch (activityType) {
      case 'app_launched':
        this.state.userData.stats.appsLaunched = (this.state.userData.stats.appsLaunched || 0) + 1;
        
        // Track unique app
        if (data.packageName) {
          const uniqueApps = this.state.userData.stats.uniqueAppsTracked || [];
          if (!uniqueApps.includes(data.packageName)) {
            uniqueApps.push(data.packageName);
            this.state.userData.stats.uniqueAppsTracked = uniqueApps;
            this.state.userData.stats.uniqueAppsLaunched = uniqueApps.length;
          }
        }
        
        // Update daily goal
        this._updateGoalProgress('daily_app_launches', 1);
        break;
        
      case 'theme_created':
        this.state.userData.stats.themesCreated = (this.state.userData.stats.themesCreated || 0) + 1;
        this._updateGoalProgress('weekly_customizations', 1);
        break;
        
      case 'widget_created':
        this.state.userData.stats.widgetsCreated = (this.state.userData.stats.widgetsCreated || 0) + 1;
        this._updateGoalProgress('weekly_customizations', 1);
        break;
        
      case 'layout_created':
        this.state.userData.stats.layoutsCreated = (this.state.userData.stats.layoutsCreated || 0) + 1;
        this._updateGoalProgress('weekly_customizations', 1);
        break;
        
      case 'widget_interaction':
        this._updateGoalProgress('daily_widgets_interaction', 1);
        break;
        
      case 'voice_command_used':
        this.state.userData.stats.voiceCommandsUsed = (this.state.userData.stats.voiceCommandsUsed || 0) + 1;
        this._updateGoalProgress('daily_voice_commands', 1);
        break;
        
      case 'gesture_created':
        this.state.userData.stats.gesturesCreated = (this.state.userData.stats.gesturesCreated || 0) + 1;
        this._updateGoalProgress('weekly_customizations', 1);
        break;
        
      case 'productivity_app_used':
        const minutes = data.minutes || 1;
        this._updateGoalProgress('weekly_productivity_time', minutes);
        break;
        
      case 'content_shared':
        this.state.userData.stats.contentShared = (this.state.userData.stats.contentShared || 0) + 1;
        break;
        
      case 'app_drawer_opened':
        this.state.userData.stats.appDrawerOpened = (this.state.userData.stats.appDrawerOpened || 0) + 1;
        break;
        
      case 'settings_opened':
        this.state.userData.stats.settingsOpened = (this.state.userData.stats.settingsOpened || 0) + 1;
        break;
        
      case 'daily_login':
        this._updateStreak('dailyUse');
        break;
        
      case 'morning_productivity':
        this._updateStreak('morningProductivity');
        break;
    }
    
    // Add to activity log
    this.state.activities.push({
      type: activityType,
      data,
      timestamp: new Date().toISOString()
    });
    
    // Keep activities from growing too large
    if (this.state.activities.length > 50) {
      this.state.activities.shift();
    }
    
    // Check for new achievements
    this._checkForNewAchievements();
    
    // Check for completed goals
    this._checkCompletedGoals();
    
    // Notify listeners
    this._notifyListeners('activityTracked', {
      type: activityType,
      data,
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * Update goal progress
   */
  _updateGoalProgress(goalId, increment) {
    // Check if it's a daily goal
    if (this.state.dailyGoals[goalId]) {
      const goal = this.state.dailyGoals[goalId];
      goal.progress = Math.min(goal.target, goal.progress + increment);
      
      // Check if goal is completed now
      if (goal.progress === goal.target && !goal.completed) {
        goal.completed = true;
        this._onGoalCompleted(goalId, goal);
      }
    }
    // Check if it's a weekly goal
    else if (this.state.weeklyGoals[goalId]) {
      const goal = this.state.weeklyGoals[goalId];
      goal.progress = Math.min(goal.target, goal.progress + increment);
      
      // Check if goal is completed now
      if (goal.progress === goal.target && !goal.completed) {
        goal.completed = true;
        this._onGoalCompleted(goalId, goal);
      }
    }
  }
  
  /**
   * Handle goal completion
   */
  _onGoalCompleted(goalId, goal) {
    console.log(`Goal completed: ${goal.name}`);
    
    // Award experience points
    this._awardExperiencePoints(goal.experiencePoints, `Goal: ${goal.name}`);
    
    // Notify listeners
    this._notifyListeners('goalCompleted', {
      goalId,
      goal: {
        name: goal.name,
        description: goal.description,
        experiencePoints: goal.experiencePoints,
        icon: goal.icon
      },
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * Check for completed goals
   */
  _checkCompletedGoals() {
    // Check daily goals
    for (const [goalId, goal] of Object.entries(this.state.dailyGoals)) {
      if (goal.progress >= goal.target && !goal.completed) {
        goal.completed = true;
        this._onGoalCompleted(goalId, goal);
      }
    }
    
    // Check weekly goals
    for (const [goalId, goal] of Object.entries(this.state.weeklyGoals)) {
      if (goal.progress >= goal.target && !goal.completed) {
        goal.completed = true;
        this._onGoalCompleted(goalId, goal);
      }
    }
  }
  
  /**
   * Update streak counter
   */
  _updateStreak(streakType) {
    if (!this.state.userData.streaks[streakType]) {
      this.state.userData.streaks[streakType] = {
        current: 1,
        longest: 1,
        lastUpdated: new Date().toISOString()
      };
    } else {
      const streak = this.state.userData.streaks[streakType];
      const lastUpdated = new Date(streak.lastUpdated);
      const now = new Date();
      
      // Check if this is a new day (more than 20 hours since last update)
      const hoursSinceLastUpdate = (now - lastUpdated) / (1000 * 60 * 60);
      
      if (hoursSinceLastUpdate > 20 && hoursSinceLastUpdate < 48) {
        // Continuing the streak
        streak.current += 1;
        streak.longest = Math.max(streak.longest, streak.current);
        streak.lastUpdated = now.toISOString();
        
        // Notify if milestone reached (5, 10, 15, etc.)
        if (streak.current % 5 === 0 && this.state.gamificationSettings.streakNotifications) {
          this._notifyStreakMilestone(streakType, streak.current);
        }
      } else if (hoursSinceLastUpdate >= 48) {
        // Streak broken
        streak.current = 1;
        streak.lastUpdated = now.toISOString();
      }
      // If less than 20 hours, do nothing (already updated today)
    }
  }
  
  /**
   * Notify about a streak milestone
   */
  _notifyStreakMilestone(streakType, count) {
    const streakNames = {
      'dailyUse': 'Daily Use',
      'morningProductivity': 'Morning Productivity'
    };
    
    const streakName = streakNames[streakType] || streakType;
    
    console.log(`Streak milestone: ${streakName} x${count}`);
    
    // Award bonus experience
    const bonusExp = Math.min(count * 5, 50); // Cap at 50 XP
    this._awardExperiencePoints(bonusExp, `${streakName} Streak x${count}`);
    
    // Notify listeners
    this._notifyListeners('streakMilestone', {
      streakType,
      streakName,
      count,
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * Reset daily and weekly goals when appropriate
   */
  resetGoalsIfNeeded() {
    const now = new Date();
    
    // Check if we need to reset daily goals
    const lastDailyReset = new Date(this.state.lastDailyReset || 0);
    const daysSinceLastReset = Math.floor((now - lastDailyReset) / (1000 * 60 * 60 * 24));
    
    if (daysSinceLastReset >= 1) {
      // Reset daily goals
      for (const goal of Object.values(this.state.dailyGoals)) {
        goal.progress = 0;
        goal.completed = false;
      }
      
      this.state.lastDailyReset = now.toISOString();
    }
    
    // Check if we need to reset weekly goals
    const lastWeeklyReset = new Date(this.state.lastWeeklyReset || 0);
    const dayOfWeek = now.getDay(); // 0 = Sunday, 1 = Monday, etc.
    
    // Reset on Sunday (or if it's been more than 7 days)
    if (dayOfWeek === 0 && lastWeeklyReset.getDay() !== 0) {
      // Reset weekly goals
      for (const goal of Object.values(this.state.weeklyGoals)) {
        goal.progress = 0;
        goal.completed = false;
      }
      
      this.state.lastWeeklyReset = now.toISOString();
    }
  }
  
  /**
   * Get unlocked achievements
   */
  getAchievements() {
    return this.state.userData.achievements;
  }
  
  /**
   * Get all achievements (including locked ones)
   */
  getAllAchievements() {
    const allAchievements = [];
    const unlockedIds = new Set(this.state.userData.achievements.map(a => a.id));
    
    // Process all achievements
    for (const [achievementId, achievement] of Object.entries(this.state.achievements)) {
      const isUnlocked = unlockedIds.has(achievementId);
      const progress = isUnlocked
        ? this.state.userData.achievements.find(a => a.id === achievementId).progress
        : this._calculateAchievementProgress(achievement, this.state.userData.stats);
      
      allAchievements.push({
        id: achievementId,
        name: achievement.name,
        description: achievement.description,
        category: achievement.category,
        experiencePoints: achievement.experiencePoints,
        icon: achievement.icon,
        unlocked: isUnlocked,
        progress,
        maxProgress: achievement.maxProgress,
        dateUnlocked: isUnlocked
          ? this.state.userData.achievements.find(a => a.id === achievementId).dateUnlocked
          : null
      });
    }
    
    return allAchievements;
  }
  
  /**
   * Get unlocked rewards
   */
  getRewards() {
    return this.state.userData.rewards;
  }
  
  /**
   * Get all rewards (including locked ones)
   */
  getAllRewards() {
    const allRewards = [];
    const unlockedIds = new Set(this.state.userData.rewards.map(r => r.id));
    
    // Process all rewards
    for (const [rewardId, reward] of Object.entries(this.state.rewards)) {
      const isUnlocked = unlockedIds.has(rewardId);
      const isClaimed = isUnlocked
        ? this.state.userData.rewards.find(r => r.id === rewardId).claimed
        : false;
      
      allRewards.push({
        id: rewardId,
        name: reward.name,
        description: reward.description,
        type: reward.type,
        levelRequired: reward.levelRequired,
        icon: reward.icon,
        unlocked: isUnlocked,
        claimed: isClaimed,
        dateUnlocked: isUnlocked
          ? this.state.userData.rewards.find(r => r.id === rewardId).dateUnlocked
          : null
      });
    }
    
    return allRewards;
  }
  
  /**
   * Claim a reward
   */
  claimReward(rewardId) {
    // Find the reward
    const rewardIndex = this.state.userData.rewards.findIndex(r => r.id === rewardId);
    
    if (rewardIndex === -1) {
      return {
        success: false,
        error: 'Reward not found or not unlocked yet'
      };
    }
    
    // Check if already claimed
    if (this.state.userData.rewards[rewardIndex].claimed) {
      return {
        success: false,
        error: 'Reward already claimed'
      };
    }
    
    // Get reward details
    const rewardData = this.state.rewards[rewardId];
    if (!rewardData) {
      return {
        success: false,
        error: 'Reward data not found'
      };
    }
    
    // Mark as claimed
    this.state.userData.rewards[rewardIndex].claimed = true;
    
    // Notify listeners
    this._notifyListeners('rewardClaimed', {
      rewardId,
      reward: rewardData,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true,
      reward: {
        id: rewardId,
        content: rewardData.content
      }
    };
  }
  
  /**
   * Get user's current challenges
   */
  getChallenges() {
    return this.state.userData.challenges;
  }
  
  /**
   * Update challenge progress
   */
  updateChallengeProgress(challengeId, increment) {
    // Find the challenge
    const challengeIndex = this.state.userData.challenges.findIndex(c => c.id === challengeId);
    
    if (challengeIndex === -1) {
      return false;
    }
    
    const challenge = this.state.userData.challenges[challengeIndex];
    
    // Update progress
    challenge.progress = Math.min(challenge.maxProgress, challenge.progress + increment);
    
    // Check if challenge completed
    if (challenge.progress >= challenge.maxProgress && !challenge.completed) {
      challenge.completed = true;
      this._onChallengeCompleted(challengeId, challenge);
    }
    
    return true;
  }
  
  /**
   * Handle challenge completion
   */
  _onChallengeCompleted(challengeId, challenge) {
    console.log(`Challenge completed: ${challenge.name}`);
    
    // Award experience points
    if (challenge.reward && challenge.reward.experiencePoints) {
      this._awardExperiencePoints(
        challenge.reward.experiencePoints,
        `Challenge: ${challenge.name}`
      );
    }
    
    // Add reward if specified
    if (challenge.reward && challenge.reward.rewardId) {
      const rewardData = this.state.rewards[challenge.reward.rewardId];
      
      if (rewardData) {
        // Add to user rewards if not already there
        const hasReward = this.state.userData.rewards.some(r => r.id === challenge.reward.rewardId);
        
        if (!hasReward) {
          this.state.userData.rewards.push({
            id: challenge.reward.rewardId,
            name: rewardData.name,
            description: rewardData.description,
            type: rewardData.type,
            dateUnlocked: new Date().toISOString(),
            claimed: false
          });
          
          // Notify about new reward
          this._notifyRewardUnlocked(challenge.reward.rewardId, rewardData);
        }
      }
    }
    
    // Notify listeners
    this._notifyListeners('challengeCompleted', {
      challengeId,
      challenge: {
        name: challenge.name,
        description: challenge.description,
        reward: challenge.reward
      },
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * Get user's current level and experience
   */
  getUserLevel() {
    return {
      level: this.state.userData.level,
      experience: this.state.userData.experience,
      experienceToNextLevel: this.state.userData.experienceToNextLevel,
      percentage: Math.floor((this.state.userData.experience / this.state.userData.experienceToNextLevel) * 100)
    };
  }
  
  /**
   * Get daily and weekly goals
   */
  getGoals() {
    return {
      daily: this.state.dailyGoals,
      weekly: this.state.weeklyGoals
    };
  }
  
  /**
   * Get user activity feed
   */
  getActivityFeed() {
    return this.state.activities;
  }
  
  /**
   * Get user streaks
   */
  getStreaks() {
    return this.state.userData.streaks;
  }
  
  /**
   * Update gamification settings
   */
  updateSettings(settings) {
    this.state.gamificationSettings = {
      ...this.state.gamificationSettings,
      ...settings
    };
    
    // Notify listeners
    this._notifyListeners('settingsUpdated', { 
      settings: this.state.gamificationSettings 
    });
    
    return true;
  }
  
  /**
   * Enable or disable gamification features
   */
  setEnabled(enabled) {
    // If toggling from disabled to enabled, start achievement checking
    if (!this.state.enabled && enabled) {
      this.state.enabled = true;
      this._startAchievementChecking();
    }
    // If toggling from enabled to disabled, stop achievement checking
    else if (this.state.enabled && !enabled) {
      this.state.enabled = false;
      this._stopAchievementChecking();
    }
    
    // Notify listeners
    this._notifyListeners('enabledStateChanged', { enabled });
    
    return true;
  }
  
  /**
   * Get the current gamification settings
   */
  getSettings() {
    return this.state.gamificationSettings;
  }
  
  /**
   * Subscribe to gamification events
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from gamification events
   */
  unsubscribe(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  /**
   * Notify all listeners of an event
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in gamification service listener:', error);
      }
    });
  }
  
  /**
   * Clean up resources
   */
  cleanup() {
    this._stopAchievementChecking();
    this.listeners = [];
  }
}

// Export as singleton
export const GamificationService = new GamificationServiceClass();