/**
 * Service for Cross-Device Synchronization
 * Enables seamless syncing of launcher settings, layouts and themes across multiple devices
 */

class CrossDeviceSyncServiceClass {
  constructor() {
    // State
    this.state = {
      enabled: true,
      syncSettings: {
        autoSync: true,
        syncInterval: 30 * 60 * 1000, // 30 minutes
        syncOnWifiOnly: true,
        syncPreferences: true,
        syncThemes: true,
        syncLayouts: true,
        syncWidgets: true,
        syncApps: true,
        syncWallpapers: true,
        syncNotifications: true,
        backupData: true,
        encryptData: true,
        conflictResolution: 'newest', // 'newest', 'manual', 'device-priority'
        devicePriority: []
      },
      connectedDevices: [],
      currentDevice: {
        id: null,
        name: 'Realme 9i 5G',
        type: 'phone',
        systemVersion: 'Android 12',
        lastActive: null,
        syncStatus: 'unknown'
      },
      syncHistory: [],
      syncStatus: {
        lastSync: null,
        syncInProgress: false,
        currentOperation: null,
        progress: 0,
        error: null
      },
      accountInfo: null,
      cloudStorage: {
        used: 0,
        total: 100 * 1024 * 1024, // 100 MB free storage
        lastBackup: null
      },
      initialized: false
    };
    
    // Listeners
    this.listeners = [];
    
    // Sync interval
    this.syncInterval = null;
    
    // Generate a unique device ID
    this.state.currentDevice.id = `device_${Date.now()}`;
  }
  
  /**
   * Initialize the cross-device sync service
   */
  async initialize() {
    if (this.state.initialized) {
      return true;
    }
    
    try {
      // Load saved settings
      await this._loadSettings();
      
      // Check if user is signed in
      const isSignedIn = await this._checkSignInStatus();
      
      if (isSignedIn) {
        // Get connected devices
        await this._loadConnectedDevices();
        
        // Get sync history
        await this._loadSyncHistory();
        
        // Start automatic sync if enabled
        if (this.state.syncSettings.autoSync) {
          this._startAutoSync();
        }
      }
      
      this.state.initialized = true;
      console.log('CrossDeviceSyncService initialized');
      
      // Update current device status
      this.state.currentDevice.lastActive = new Date().toISOString();
      this.state.currentDevice.syncStatus = isSignedIn ? 'ready' : 'signed_out';
      
      // Notify listeners
      this._notifyListeners('serviceInitialized', { 
        success: true,
        isSignedIn
      });
      
      return true;
    } catch (error) {
      console.error('Failed to initialize CrossDeviceSyncService:', error);
      return false;
    }
  }
  
  /**
   * Load saved settings from storage
   */
  async _loadSettings() {
    // In a real app, this would load from device storage
    console.log('CrossDeviceSyncService: Loading settings...');
  }
  
  /**
   * Check if user is signed in
   */
  async _checkSignInStatus() {
    // In a real app, this would check actual sign in status
    // For the prototype, we'll simulate being signed out initially
    
    console.log('CrossDeviceSyncService: Checking sign in status...');
    
    if (!this.state.accountInfo) {
      return false;
    }
    
    return true;
  }
  
  /**
   * Load connected devices
   */
  async _loadConnectedDevices() {
    // In a real app, this would get devices from the cloud
    // For the prototype, we'll use some example devices
    
    console.log('CrossDeviceSyncService: Loading connected devices...');
    
    if (!this.state.accountInfo) {
      return [];
    }
    
    this.state.connectedDevices = [
      {
        id: this.state.currentDevice.id,
        name: this.state.currentDevice.name,
        type: this.state.currentDevice.type,
        systemVersion: this.state.currentDevice.systemVersion,
        lastActive: new Date().toISOString(),
        syncStatus: 'current',
        isCurrentDevice: true
      },
      {
        id: 'device_tablet_001',
        name: 'Galaxy Tab S7',
        type: 'tablet',
        systemVersion: 'Android 13',
        lastActive: '2025-03-08T13:45:22Z',
        syncStatus: 'synced',
        isCurrentDevice: false
      },
      {
        id: 'device_watch_001',
        name: 'Galaxy Watch 5',
        type: 'watch',
        systemVersion: 'Wear OS 3.5',
        lastActive: '2025-03-09T19:20:15Z',
        syncStatus: 'synced',
        isCurrentDevice: false
      }
    ];
    
    return this.state.connectedDevices;
  }
  
  /**
   * Load sync history
   */
  async _loadSyncHistory() {
    // In a real app, this would get sync history from storage or cloud
    // For the prototype, we'll use some example history
    
    console.log('CrossDeviceSyncService: Loading sync history...');
    
    if (!this.state.accountInfo) {
      return [];
    }
    
    this.state.syncHistory = [
      {
        id: 'sync_001',
        timestamp: '2025-03-09T08:30:15Z',
        deviceId: this.state.currentDevice.id,
        deviceName: this.state.currentDevice.name,
        direction: 'upload',
        status: 'success',
        items: {
          themes: 2,
          layouts: 1,
          widgets: 5,
          settings: 1
        },
        dataSize: 1.2 * 1024 * 1024 // 1.2 MB
      },
      {
        id: 'sync_002',
        timestamp: '2025-03-09T14:15:30Z',
        deviceId: 'device_tablet_001',
        deviceName: 'Galaxy Tab S7',
        direction: 'download',
        status: 'success',
        items: {
          themes: 0,
          layouts: 1,
          widgets: 0,
          settings: 1
        },
        dataSize: 0.8 * 1024 * 1024 // 0.8 MB
      },
      {
        id: 'sync_003',
        timestamp: '2025-03-09T19:20:15Z',
        deviceId: 'device_watch_001',
        deviceName: 'Galaxy Watch 5',
        direction: 'bidirectional',
        status: 'partial',
        items: {
          themes: 1,
          layouts: 0,
          widgets: 2,
          settings: 1
        },
        error: 'Some widgets incompatible with watch screen size',
        dataSize: 0.5 * 1024 * 1024 // 0.5 MB
      }
    ];
    
    // Update cloud storage usage
    this.state.cloudStorage.used = this.state.syncHistory.reduce(
      (total, sync) => total + (sync.dataSize || 0), 
      0
    );
    
    this.state.cloudStorage.lastBackup = this.state.syncHistory
      .filter(sync => sync.direction === 'upload' && sync.status === 'success')
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))[0]?.timestamp;
    
    return this.state.syncHistory;
  }
  
  /**
   * Start automatic sync
   */
  _startAutoSync() {
    // Clear any existing interval
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
    }
    
    // Set up interval for automatic sync
    this.syncInterval = setInterval(() => {
      // Only sync if signed in, not already syncing, and settings allow it
      if (this.state.accountInfo && 
          !this.state.syncStatus.syncInProgress && 
          this.state.syncSettings.autoSync) {
        
        // Check if we should only sync on Wi-Fi
        if (this.state.syncSettings.syncOnWifiOnly) {
          // In a real app, we would check actual network status
          // For the prototype, assume Wi-Fi is connected 80% of the time
          const wifiConnected = Math.random() > 0.2;
          
          if (!wifiConnected) {
            console.log('Auto sync skipped: not on Wi-Fi');
            return;
          }
        }
        
        // Perform sync
        this.synchronize();
      }
    }, this.state.syncSettings.syncInterval);
    
    console.log(`Auto sync started with interval: ${this.state.syncSettings.syncInterval / 60000} minutes`);
  }
  
  /**
   * Sign in with account
   */
  async signIn(email, password) {
    if (this.state.accountInfo) {
      return {
        success: false,
        error: 'Already signed in'
      };
    }
    
    try {
      console.log(`Signing in with email: ${email}`);
      
      // In a real app, this would authenticate with a server
      // For the prototype, we'll simulate a successful sign in
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // 90% success rate for sign in
      if (Math.random() > 0.1) {
        // Set account info
        this.state.accountInfo = {
          id: `user_${Date.now()}`,
          email,
          name: email.split('@')[0],
          signInDate: new Date().toISOString(),
          subscription: 'free', // 'free' or 'premium'
          settings: {
            defaultDevice: this.state.currentDevice.id
          }
        };
        
        // Update device status
        this.state.currentDevice.syncStatus = 'ready';
        this.state.currentDevice.lastActive = new Date().toISOString();
        
        // Load connected devices
        await this._loadConnectedDevices();
        
        // Load sync history
        await this._loadSyncHistory();
        
        // Start automatic sync if enabled
        if (this.state.syncSettings.autoSync) {
          this._startAutoSync();
        }
        
        // Notify listeners
        this._notifyListeners('signedIn', {
          email,
          timestamp: new Date().toISOString()
        });
        
        return {
          success: true,
          accountInfo: this.state.accountInfo
        };
      } else {
        throw new Error('Invalid credentials');
      }
    } catch (error) {
      console.error('Sign in failed:', error);
      return {
        success: false,
        error: error.message || 'Failed to sign in'
      };
    }
  }
  
  /**
   * Sign out
   */
  async signOut() {
    if (!this.state.accountInfo) {
      return {
        success: false,
        error: 'Not signed in'
      };
    }
    
    try {
      console.log('Signing out...');
      
      // In a real app, this would sign out from the server
      // For the prototype, we'll simulate a successful sign out
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Stop automatic sync
      if (this.syncInterval) {
        clearInterval(this.syncInterval);
        this.syncInterval = null;
      }
      
      // Clear account and sync data
      const previousEmail = this.state.accountInfo.email;
      this.state.accountInfo = null;
      this.state.connectedDevices = [];
      this.state.syncHistory = [];
      this.state.cloudStorage.used = 0;
      this.state.cloudStorage.lastBackup = null;
      
      // Update device status
      this.state.currentDevice.syncStatus = 'signed_out';
      
      // Notify listeners
      this._notifyListeners('signedOut', {
        email: previousEmail,
        timestamp: new Date().toISOString()
      });
      
      return {
        success: true
      };
    } catch (error) {
      console.error('Sign out failed:', error);
      return {
        success: false,
        error: error.message || 'Failed to sign out'
      };
    }
  }
  
  /**
   * Synchronize data with cloud and other devices
   */
  async synchronize(options = {}) {
    if (!this.state.accountInfo) {
      return {
        success: false,
        error: 'Not signed in'
      };
    }
    
    if (this.state.syncStatus.syncInProgress) {
      return {
        success: false,
        error: 'Sync already in progress'
      };
    }
    
    try {
      console.log('Starting synchronization...');
      
      // Set sync in progress
      this.state.syncStatus.syncInProgress = true;
      this.state.syncStatus.currentOperation = 'preparing';
      this.state.syncStatus.progress = 0;
      this.state.syncStatus.error = null;
      
      // Notify sync started
      this._notifyListeners('syncStarted', {
        timestamp: new Date().toISOString(),
        options
      });
      
      // Calculate what to sync based on options and default settings
      const syncItems = {
        preferences: options.syncPreferences !== undefined ? 
          options.syncPreferences : this.state.syncSettings.syncPreferences,
        themes: options.syncThemes !== undefined ? 
          options.syncThemes : this.state.syncSettings.syncThemes,
        layouts: options.syncLayouts !== undefined ? 
          options.syncLayouts : this.state.syncSettings.syncLayouts,
        widgets: options.syncWidgets !== undefined ? 
          options.syncWidgets : this.state.syncSettings.syncWidgets,
        apps: options.syncApps !== undefined ? 
          options.syncApps : this.state.syncSettings.syncApps,
        wallpapers: options.syncWallpapers !== undefined ? 
          options.syncWallpapers : this.state.syncSettings.syncWallpapers
      };
      
      // Simulate sync process
      await this._simulateSyncProcess(syncItems);
      
      // Update last sync time
      this.state.syncStatus.lastSync = new Date().toISOString();
      
      // Add to sync history
      const syncId = `sync_${Date.now()}`;
      const syncEntry = {
        id: syncId,
        timestamp: this.state.syncStatus.lastSync,
        deviceId: this.state.currentDevice.id,
        deviceName: this.state.currentDevice.name,
        direction: 'bidirectional',
        status: 'success',
        items: {
          themes: syncItems.themes ? Math.floor(Math.random() * 3) : 0,
          layouts: syncItems.layouts ? Math.floor(Math.random() * 2) : 0,
          widgets: syncItems.widgets ? Math.floor(Math.random() * 5) : 0,
          settings: syncItems.preferences ? 1 : 0
        },
        dataSize: (Math.random() * 2 + 0.5) * 1024 * 1024 // 0.5-2.5 MB
      };
      
      this.state.syncHistory.unshift(syncEntry);
      
      // Update cloud storage usage
      this.state.cloudStorage.used += syncEntry.dataSize;
      this.state.cloudStorage.lastBackup = syncEntry.timestamp;
      
      // Reset sync status
      this.state.syncStatus.syncInProgress = false;
      this.state.syncStatus.currentOperation = null;
      this.state.syncStatus.progress = 100;
      
      // Update device status
      this.state.currentDevice.syncStatus = 'synced';
      this.state.currentDevice.lastActive = new Date().toISOString();
      
      // Update other devices' sync status
      this.state.connectedDevices.forEach(device => {
        if (!device.isCurrentDevice) {
          device.syncStatus = 'pending';
        }
      });
      
      // Notify sync completed
      this._notifyListeners('syncCompleted', {
        syncId,
        timestamp: new Date().toISOString(),
        items: syncEntry.items,
        dataSize: syncEntry.dataSize
      });
      
      return {
        success: true,
        syncId,
        items: syncEntry.items
      };
    } catch (error) {
      console.error('Sync failed:', error);
      
      // Update sync status on error
      this.state.syncStatus.syncInProgress = false;
      this.state.syncStatus.error = error.message || 'Unknown error during sync';
      
      // Add failed sync to history
      const syncId = `sync_${Date.now()}`;
      const syncEntry = {
        id: syncId,
        timestamp: new Date().toISOString(),
        deviceId: this.state.currentDevice.id,
        deviceName: this.state.currentDevice.name,
        direction: 'bidirectional',
        status: 'failed',
        error: this.state.syncStatus.error
      };
      
      this.state.syncHistory.unshift(syncEntry);
      
      // Notify sync failed
      this._notifyListeners('syncFailed', {
        syncId,
        timestamp: new Date().toISOString(),
        error: this.state.syncStatus.error
      });
      
      return {
        success: false,
        error: this.state.syncStatus.error
      };
    }
  }
  
  /**
   * Simulate sync process (for prototype)
   */
  async _simulateSyncProcess(syncItems) {
    // Step 1: Preparing
    this.state.syncStatus.currentOperation = 'preparing';
    this.state.syncStatus.progress = 10;
    await new Promise(resolve => setTimeout(resolve, 500));
    this._notifyListeners('syncProgress', { 
      operation: 'preparing', 
      progress: 10,
      message: 'Preparing sync...'
    });
    
    // Step 2: Uploading
    this.state.syncStatus.currentOperation = 'uploading';
    this.state.syncStatus.progress = 30;
    await new Promise(resolve => setTimeout(resolve, 800));
    this._notifyListeners('syncProgress', { 
      operation: 'uploading', 
      progress: 30,
      message: 'Uploading changes...'
    });
    
    // Step 3: Downloading
    this.state.syncStatus.currentOperation = 'downloading';
    this.state.syncStatus.progress = 60;
    await new Promise(resolve => setTimeout(resolve, 700));
    this._notifyListeners('syncProgress', { 
      operation: 'downloading', 
      progress: 60,
      message: 'Downloading updates...'
    });
    
    // Step 4: Applying changes
    this.state.syncStatus.currentOperation = 'applying';
    this.state.syncStatus.progress = 85;
    await new Promise(resolve => setTimeout(resolve, 600));
    this._notifyListeners('syncProgress', { 
      operation: 'applying', 
      progress: 85,
      message: 'Applying changes...'
    });
    
    // Step 5: Finalizing
    this.state.syncStatus.currentOperation = 'finalizing';
    this.state.syncStatus.progress = 95;
    await new Promise(resolve => setTimeout(resolve, 400));
    this._notifyListeners('syncProgress', { 
      operation: 'finalizing', 
      progress: 95,
      message: 'Finalizing sync...'
    });
    
    // Completed
    this.state.syncStatus.currentOperation = 'completed';
    this.state.syncStatus.progress = 100;
    await new Promise(resolve => setTimeout(resolve, 200));
    this._notifyListeners('syncProgress', { 
      operation: 'completed', 
      progress: 100,
      message: 'Sync completed'
    });
  }
  
  /**
   * Get sync conflicts
   */
  async getSyncConflicts() {
    if (!this.state.accountInfo) {
      return {
        success: false,
        error: 'Not signed in'
      };
    }
    
    // In a real app, this would get actual sync conflicts from the server
    // For the prototype, we'll simulate some conflicts
    
    // 30% chance of having conflicts
    if (Math.random() > 0.7) {
      const conflicts = [
        {
          id: `conflict_${Date.now()}_1`,
          type: 'theme',
          name: 'Dark Ocean Theme',
          localVersion: {
            lastModified: '2025-03-09T15:30:00Z',
            device: this.state.currentDevice.name
          },
          remoteVersion: {
            lastModified: '2025-03-09T18:45:00Z',
            device: 'Galaxy Tab S7'
          }
        },
        {
          id: `conflict_${Date.now()}_2`,
          type: 'layout',
          name: 'Home Screen Layout',
          localVersion: {
            lastModified: '2025-03-10T09:15:00Z',
            device: this.state.currentDevice.name
          },
          remoteVersion: {
            lastModified: '2025-03-10T07:30:00Z',
            device: 'Galaxy Tab S7'
          }
        }
      ];
      
      return {
        success: true,
        conflicts
      };
    }
    
    return {
      success: true,
      conflicts: []
    };
  }
  
  /**
   * Resolve a sync conflict
   */
  async resolveConflict(conflictId, resolution) {
    if (!this.state.accountInfo) {
      return {
        success: false,
        error: 'Not signed in'
      };
    }
    
    if (!['local', 'remote', 'both'].includes(resolution)) {
      return {
        success: false,
        error: 'Invalid resolution option'
      };
    }
    
    console.log(`Resolving conflict ${conflictId} with option: ${resolution}`);
    
    // In a real app, this would apply the resolution on the server
    // For the prototype, we'll simulate success
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Notify listeners
    this._notifyListeners('conflictResolved', {
      conflictId,
      resolution,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true
    };
  }
  
  /**
   * Add a new device to the account
   */
  async addDevice(deviceInfo) {
    if (!this.state.accountInfo) {
      return {
        success: false,
        error: 'Not signed in'
      };
    }
    
    if (!deviceInfo || !deviceInfo.name || !deviceInfo.type) {
      return {
        success: false,
        error: 'Invalid device information'
      };
    }
    
    try {
      console.log(`Adding new device: ${deviceInfo.name}`);
      
      // In a real app, this would register the device with the server
      // For the prototype, we'll simulate adding a device
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Generate device ID
      const deviceId = `device_${deviceInfo.type}_${Date.now()}`;
      
      // Create device object
      const newDevice = {
        id: deviceId,
        name: deviceInfo.name,
        type: deviceInfo.type,
        systemVersion: deviceInfo.systemVersion || 'Unknown',
        lastActive: new Date().toISOString(),
        syncStatus: 'new',
        isCurrentDevice: false
      };
      
      // Add to devices list
      this.state.connectedDevices.push(newDevice);
      
      // Notify listeners
      this._notifyListeners('deviceAdded', {
        deviceId,
        device: newDevice,
        timestamp: new Date().toISOString()
      });
      
      return {
        success: true,
        deviceId,
        device: newDevice
      };
    } catch (error) {
      console.error('Add device failed:', error);
      return {
        success: false,
        error: error.message || 'Failed to add device'
      };
    }
  }
  
  /**
   * Remove a device from the account
   */
  async removeDevice(deviceId) {
    if (!this.state.accountInfo) {
      return {
        success: false,
        error: 'Not signed in'
      };
    }
    
    // Can't remove current device
    if (deviceId === this.state.currentDevice.id) {
      return {
        success: false,
        error: 'Cannot remove current device'
      };
    }
    
    // Find device
    const deviceIndex = this.state.connectedDevices.findIndex(d => d.id === deviceId);
    
    if (deviceIndex === -1) {
      return {
        success: false,
        error: 'Device not found'
      };
    }
    
    try {
      console.log(`Removing device: ${deviceId}`);
      
      // In a real app, this would unregister the device with the server
      // For the prototype, we'll simulate removal
      
      // Get device info before removing
      const device = this.state.connectedDevices[deviceIndex];
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Remove from devices list
      this.state.connectedDevices.splice(deviceIndex, 1);
      
      // Notify listeners
      this._notifyListeners('deviceRemoved', {
        deviceId,
        deviceName: device.name,
        timestamp: new Date().toISOString()
      });
      
      return {
        success: true
      };
    } catch (error) {
      console.error('Remove device failed:', error);
      return {
        success: false,
        error: error.message || 'Failed to remove device'
      };
    }
  }
  
  /**
   * Get sync status for current device
   */
  getSyncStatus() {
    return {
      lastSync: this.state.syncStatus.lastSync,
      syncInProgress: this.state.syncStatus.syncInProgress,
      currentOperation: this.state.syncStatus.currentOperation,
      progress: this.state.syncStatus.progress,
      error: this.state.syncStatus.error
    };
  }
  
  /**
   * Update sync settings
   */
  updateSettings(settings) {
    // Store previous settings
    const previousAutoSync = this.state.syncSettings.autoSync;
    const previousInterval = this.state.syncSettings.syncInterval;
    
    // Update settings
    this.state.syncSettings = {
      ...this.state.syncSettings,
      ...settings
    };
    
    // Handle auto sync changes
    if (!previousAutoSync && this.state.syncSettings.autoSync && this.state.accountInfo) {
      this._startAutoSync();
    } else if (previousAutoSync && !this.state.syncSettings.autoSync && this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    } else if (previousInterval !== this.state.syncSettings.syncInterval && 
               this.state.syncSettings.autoSync && 
               this.syncInterval) {
      // Restart sync with new interval
      this._startAutoSync();
    }
    
    // Notify listeners
    this._notifyListeners('settingsUpdated', {
      settings: this.state.syncSettings,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true,
      settings: this.state.syncSettings
    };
  }
  
  /**
   * Get sync settings
   */
  getSettings() {
    return this.state.syncSettings;
  }
  
  /**
   * Get connected devices
   */
  getConnectedDevices() {
    return this.state.connectedDevices;
  }
  
  /**
   * Get current device info
   */
  getCurrentDevice() {
    return this.state.currentDevice;
  }
  
  /**
   * Get sync history
   */
  getSyncHistory() {
    return this.state.syncHistory;
  }
  
  /**
   * Get account info
   */
  getAccountInfo() {
    return this.state.accountInfo;
  }
  
  /**
   * Get cloud storage info
   */
  getCloudStorage() {
    return this.state.cloudStorage;
  }
  
  /**
   * Enable or disable cross-device sync
   */
  setEnabled(enabled) {
    this.state.enabled = enabled;
    
    // Start or stop auto sync
    if (enabled && this.state.accountInfo && this.state.syncSettings.autoSync && !this.syncInterval) {
      this._startAutoSync();
    } else if (!enabled && this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
    
    // Notify listeners
    this._notifyListeners('enabledStateChanged', {
      enabled,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Subscribe to cross-device sync events
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from cross-device sync events
   */
  unsubscribe(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  /**
   * Notify all listeners of an event
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in cross-device sync service listener:', error);
      }
    });
  }
  
  /**
   * Clean up the service
   */
  cleanup() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
    
    this.listeners = [];
  }
}

// Export as singleton
export const CrossDeviceSyncService = new CrossDeviceSyncServiceClass();