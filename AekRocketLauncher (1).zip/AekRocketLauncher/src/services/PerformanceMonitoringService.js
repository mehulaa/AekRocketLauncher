/**
 * Service for Real-Time Performance Monitoring
 * Provides 3D visualizations of battery, RAM, CPU usage and other system metrics
 */

class PerformanceMonitoringServiceClass {
  constructor() {
    // State
    this.state = {
      enabled: true,
      monitoringActive: false,
      monitoringSettings: {
        updateInterval: 2000, // milliseconds
        showBattery: true,
        showCPU: true,
        showRAM: true,
        showNetwork: true,
        showStorage: true,
        showTemperature: true,
        showNetworkSpeed: true,
        historyLength: 60, // How many data points to keep
        visualizationType: '3d_bars', // '3d_bars', '3d_wave', '3d_glow', 'flat_charts'
        colorTheme: 'gradient', // 'gradient', 'solid', 'heat', 'cool'
        animationSpeed: 'medium', // 'slow', 'medium', 'fast'
        detailLevel: 'normal', // 'basic', 'normal', 'detailed'
        showNotifications: true,
        powerSaving: false,
        autoAdjustRefresh: true
      },
      currentMetrics: {
        battery: {
          level: 0,
          charging: false,
          temperature: 0,
          voltage: 0,
          health: 'unknown',
          remainingTime: 0
        },
        cpu: {
          usage: 0,
          temperature: 0,
          frequency: 0,
          cores: []
        },
        ram: {
          total: 0,
          used: 0,
          free: 0,
          apps: []
        },
        network: {
          wifi: {
            connected: false,
            signalStrength: 0,
            downloadSpeed: 0,
            uploadSpeed: 0,
            dataUsed: 0
          },
          mobile: {
            connected: false,
            signalStrength: 0,
            networkType: '',
            downloadSpeed: 0,
            uploadSpeed: 0,
            dataUsed: 0
          }
        },
        storage: {
          total: 0,
          used: 0,
          free: 0,
          apps: []
        },
        temperature: {
          battery: 0,
          cpu: 0,
          ambient: 0
        }
      },
      historicalData: {
        battery: [],
        cpu: [],
        ram: [],
        network: []
      },
      topResourceApps: [],
      warnings: [],
      optimizationSuggestions: [],
      lastUpdate: null,
      initialized: false
    };
    
    // Listeners
    this.listeners = [];
    
    // Monitoring interval
    this.monitoringInterval = null;
    
    // Network speed test interval
    this.speedTestInterval = null;
  }
  
  /**
   * Initialize the performance monitoring service
   */
  async initialize() {
    if (this.state.initialized) {
      return true;
    }
    
    try {
      // Load saved settings
      await this._loadSettings();
      
      // Request necessary permissions
      await this._requestPermissions();
      
      this.state.initialized = true;
      console.log('PerformanceMonitoringService initialized');
      
      // Start monitoring if enabled
      if (this.state.enabled) {
        this.startMonitoring();
      }
      
      // Notify listeners
      this._notifyListeners('serviceInitialized', { success: true });
      
      return true;
    } catch (error) {
      console.error('Failed to initialize PerformanceMonitoringService:', error);
      return false;
    }
  }
  
  /**
   * Load saved settings from storage
   */
  async _loadSettings() {
    // In a real app, this would load from device storage
    console.log('PerformanceMonitoringService: Loading settings...');
  }
  
  /**
   * Request permissions needed for performance monitoring
   */
  async _requestPermissions() {
    // In a real app, this would request actual permissions
    // For the prototype, we'll simulate successful permission grants
    
    console.log('PerformanceMonitoringService: Requesting permissions...');
    
    return {
      batteryStats: true,
      usageStats: true,
      networkStats: true
    };
  }
  
  /**
   * Start monitoring device performance
   */
  startMonitoring() {
    if (this.monitoringActive) {
      return true;
    }
    
    console.log('Starting performance monitoring...');
    
    this.state.monitoringActive = true;
    
    // Set up monitoring interval
    this.monitoringInterval = setInterval(() => {
      this._updateMetrics();
    }, this.state.monitoringSettings.updateInterval);
    
    // Set up network speed test interval (less frequent)
    this.speedTestInterval = setInterval(() => {
      this._testNetworkSpeed();
    }, 60000); // Every minute
    
    // Update immediately
    this._updateMetrics();
    this._testNetworkSpeed();
    
    // Notify listeners
    this._notifyListeners('monitoringStarted', {
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Stop monitoring device performance
   */
  stopMonitoring() {
    if (!this.monitoringActive) {
      return true;
    }
    
    console.log('Stopping performance monitoring...');
    
    this.state.monitoringActive = false;
    
    // Clear monitoring intervals
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    
    if (this.speedTestInterval) {
      clearInterval(this.speedTestInterval);
      this.speedTestInterval = null;
    }
    
    // Notify listeners
    this._notifyListeners('monitoringStopped', {
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Update performance metrics
   */
  _updateMetrics() {
    if (!this.state.monitoringActive) {
      return;
    }
    
    // In a real app, this would query actual system metrics
    // For the prototype, we'll generate simulated values
    
    // Generate current timestamp
    const timestamp = new Date().toISOString();
    
    // Update battery metrics
    this._updateBatteryMetrics(timestamp);
    
    // Update CPU metrics
    this._updateCPUMetrics(timestamp);
    
    // Update RAM metrics
    this._updateRAMMetrics(timestamp);
    
    // Update storage metrics
    this._updateStorageMetrics();
    
    // Update temperature metrics
    this._updateTemperatureMetrics();
    
    // Update network metrics (except speed, which is updated separately)
    this._updateNetworkMetrics(timestamp);
    
    // Find top resource-consuming apps
    this._updateTopResourceApps();
    
    // Generate any warnings based on current metrics
    this._generateWarnings();
    
    // Generate optimization suggestions
    this._generateOptimizationSuggestions();
    
    // Update last update timestamp
    this.state.lastUpdate = timestamp;
    
    // Notify listeners
    this._notifyListeners('metricsUpdated', {
      metrics: this.state.currentMetrics,
      timestamp
    });
  }
  
  /**
   * Update battery metrics
   */
  _updateBatteryMetrics(timestamp) {
    if (!this.state.monitoringSettings.showBattery) {
      return;
    }
    
    // Get previous battery level or default to 80%
    const prevLevel = this.state.currentMetrics.battery.level || 80;
    
    // Simulate slight battery drain or charge
    const charging = Math.random() > 0.7; // 30% chance of charging
    let levelChange;
    
    if (charging) {
      // When charging, increase by 0-0.5%
      levelChange = Math.random() * 0.5;
    } else {
      // When not charging, decrease by 0-0.3%
      levelChange = -Math.random() * 0.3;
    }
    
    // Calculate new level, ensuring it stays between 0-100
    let newLevel = Math.min(100, Math.max(0, prevLevel + levelChange));
    
    // Round to 1 decimal place
    newLevel = parseFloat(newLevel.toFixed(1));
    
    // Update battery metrics
    this.state.currentMetrics.battery = {
      level: newLevel,
      charging: charging,
      temperature: 25 + Math.random() * 10, // 25-35°C
      voltage: 3.7 + Math.random() * 0.5, // 3.7-4.2V
      health: 'good',
      remainingTime: charging ? 0 : Math.floor((newLevel / 10) * 60) // ~10% = 60 minutes
    };
    
    // Add to historical data
    this.state.historicalData.battery.push({
      timestamp,
      level: newLevel,
      charging
    });
    
    // Trim historical data if needed
    if (this.state.historicalData.battery.length > this.state.monitoringSettings.historyLength) {
      this.state.historicalData.battery.shift();
    }
  }
  
  /**
   * Update CPU metrics
   */
  _updateCPUMetrics(timestamp) {
    if (!this.state.monitoringSettings.showCPU) {
      return;
    }
    
    // Generate CPU usage (overall)
    // Higher when RAM is higher, simulating system load correlation
    const ramUsagePercent = this.state.currentMetrics.ram.used / 
      (this.state.currentMetrics.ram.total || 1) * 100;
    
    const baseUsage = 5 + (ramUsagePercent / 5); // Base CPU usage influenced by RAM usage
    const randomVariation = Math.random() * 20; // Random variation
    
    // Calculate overall CPU usage
    const cpuUsage = Math.min(100, Math.max(0, baseUsage + randomVariation));
    
    // Generate data for 8 CPU cores with different usage patterns
    const cores = [];
    for (let i = 0; i < 8; i++) {
      const coreVariation = Math.random() * 30 - 15; // +/- 15% variation from overall
      cores.push({
        id: i,
        usage: Math.min(100, Math.max(0, cpuUsage + coreVariation)),
        frequency: 1.2 + Math.random() * 1.8 // 1.2-3.0 GHz
      });
    }
    
    // Overall CPU frequency (avg of cores)
    const avgFrequency = cores.reduce((sum, core) => sum + core.frequency, 0) / cores.length;
    
    // Update CPU metrics
    this.state.currentMetrics.cpu = {
      usage: parseFloat(cpuUsage.toFixed(1)),
      temperature: 35 + (cpuUsage / 10), // Higher usage = higher temp
      frequency: parseFloat(avgFrequency.toFixed(2)),
      cores
    };
    
    // Add to historical data
    this.state.historicalData.cpu.push({
      timestamp,
      usage: cpuUsage,
      temperature: this.state.currentMetrics.cpu.temperature
    });
    
    // Trim historical data if needed
    if (this.state.historicalData.cpu.length > this.state.monitoringSettings.historyLength) {
      this.state.historicalData.cpu.shift();
    }
  }
  
  /**
   * Update RAM metrics
   */
  _updateRAMMetrics(timestamp) {
    if (!this.state.monitoringSettings.showRAM) {
      return;
    }
    
    // Total RAM (fixed)
    const totalRAM = 6 * 1024; // 6 GB in MB
    
    // Generate RAM usage
    const baseRAMUsage = 1.5 * 1024; // Base system usage (1.5 GB)
    const randomVariation = Math.random() * 1024; // Random variation up to 1 GB
    
    // Calculate used RAM
    const usedRAM = Math.min(totalRAM, baseRAMUsage + randomVariation);
    
    // Generate data for top RAM-using apps
    const appNames = [
      'System UI', 'Android System', 'Facebook', 'Chrome', 'Spotify',
      'Instagram', 'Gmail', 'WhatsApp', 'Google Play Services', 'Camera'
    ];
    
    const apps = [];
    let remainingRAM = usedRAM * 0.7; // 70% of RAM is attributed to specific apps
    
    for (let i = 0; i < 5; i++) {
      if (remainingRAM <= 0) break;
      
      const appRAM = i === 0 ? 
        remainingRAM * (0.3 + Math.random() * 0.2) : // First app uses 30-50% of remaining
        remainingRAM * (0.1 + Math.random() * 0.2);  // Others use 10-30% of remaining
      
      apps.push({
        name: appNames[i],
        ram: Math.floor(appRAM),
        percentage: parseFloat((appRAM / totalRAM * 100).toFixed(1))
      });
      
      remainingRAM -= appRAM;
    }
    
    // Add "Other" category for remaining RAM
    const otherRAM = usedRAM - apps.reduce((sum, app) => sum + app.ram, 0);
    if (otherRAM > 0) {
      apps.push({
        name: 'Other apps',
        ram: Math.floor(otherRAM),
        percentage: parseFloat((otherRAM / totalRAM * 100).toFixed(1))
      });
    }
    
    // Update RAM metrics
    this.state.currentMetrics.ram = {
      total: totalRAM,
      used: Math.floor(usedRAM),
      free: Math.floor(totalRAM - usedRAM),
      apps
    };
    
    // Add to historical data
    this.state.historicalData.ram.push({
      timestamp,
      used: usedRAM,
      free: totalRAM - usedRAM
    });
    
    // Trim historical data if needed
    if (this.state.historicalData.ram.length > this.state.monitoringSettings.historyLength) {
      this.state.historicalData.ram.shift();
    }
  }
  
  /**
   * Update storage metrics
   */
  _updateStorageMetrics() {
    if (!this.state.monitoringSettings.showStorage) {
      return;
    }
    
    // Total storage (fixed)
    const totalStorage = 64 * 1024; // 64 GB in MB
    
    // Generate storage usage (relatively static)
    const systemStorage = 10 * 1024; // 10 GB for system
    const appStorage = 15 * 1024; // 15 GB for apps
    const mediaStorage = 20 * 1024; // 20 GB for media
    
    const usedStorage = systemStorage + appStorage + mediaStorage;
    
    // Generate data for top storage-using apps
    const appNames = [
      'Photos', 'WhatsApp', 'Spotify', 'Netflix', 'YouTube',
      'Facebook', 'Instagram', 'Files', 'Camera', 'Downloads'
    ];
    
    const apps = [];
    let remainingStorage = appStorage + mediaStorage; // Attributable to specific apps/categories
    
    for (let i = 0; i < 5; i++) {
      if (remainingStorage <= 0) break;
      
      const appStorage = i === 0 ? 
        remainingStorage * (0.3 + Math.random() * 0.2) : // First app uses 30-50% of remaining
        remainingStorage * (0.1 + Math.random() * 0.1);  // Others use 10-20% of remaining
      
      apps.push({
        name: appNames[i],
        storage: Math.floor(appStorage),
        percentage: parseFloat((appStorage / totalStorage * 100).toFixed(1))
      });
      
      remainingStorage -= appStorage;
    }
    
    // Add "System" category
    apps.push({
      name: 'System',
      storage: Math.floor(systemStorage),
      percentage: parseFloat((systemStorage / totalStorage * 100).toFixed(1))
    });
    
    // Add "Other" category for remaining storage
    const otherStorage = usedStorage - systemStorage - 
      apps.reduce((sum, app) => sum + (app.name !== 'System' ? app.storage : 0), 0);
    
    if (otherStorage > 0) {
      apps.push({
        name: 'Other',
        storage: Math.floor(otherStorage),
        percentage: parseFloat((otherStorage / totalStorage * 100).toFixed(1))
      });
    }
    
    // Update storage metrics
    this.state.currentMetrics.storage = {
      total: totalStorage,
      used: Math.floor(usedStorage),
      free: Math.floor(totalStorage - usedStorage),
      apps
    };
  }
  
  /**
   * Update temperature metrics
   */
  _updateTemperatureMetrics() {
    if (!this.state.monitoringSettings.showTemperature) {
      return;
    }
    
    // CPU temp (correlated with CPU usage)
    const cpuUsage = this.state.currentMetrics.cpu.usage || 50;
    const cpuTemp = 30 + (cpuUsage / 10) * 3; // 30-60°C based on CPU usage
    
    // Battery temp (correlated with charging state)
    const charging = this.state.currentMetrics.battery.charging;
    const batteryTemp = charging ? 
      30 + Math.random() * 8 : // 30-38°C when charging
      27 + Math.random() * 5;  // 27-32°C when not charging
    
    // Ambient temp (simulated)
    const ambientTemp = 22 + Math.random() * 5; // 22-27°C
    
    // Update temperature metrics
    this.state.currentMetrics.temperature = {
      battery: parseFloat(batteryTemp.toFixed(1)),
      cpu: parseFloat(cpuTemp.toFixed(1)),
      ambient: parseFloat(ambientTemp.toFixed(1))
    };
  }
  
  /**
   * Update network metrics
   */
  _updateNetworkMetrics(timestamp) {
    if (!this.state.monitoringSettings.showNetwork) {
      return;
    }
    
    // Wi-Fi connection (80% chance of being connected)
    const wifiConnected = Math.random() > 0.2;
    let wifiSignalStrength = 0;
    let wifiDataUsed = this.state.currentMetrics.network.wifi?.dataUsed || 0;
    
    // Mobile data connection (50% chance of being connected when Wi-Fi is off)
    const mobileConnected = !wifiConnected && Math.random() > 0.5;
    let mobileSignalStrength = 0;
    let mobileNetworkType = '';
    let mobileDataUsed = this.state.currentMetrics.network.mobile?.dataUsed || 0;
    
    // Update Wi-Fi metrics if connected
    if (wifiConnected) {
      wifiSignalStrength = Math.floor(Math.random() * 5) + 1; // 1-5 bars
      
      // Simulate data usage increase
      const dataIncrement = Math.random() * 1; // 0-1 MB increment
      wifiDataUsed += dataIncrement;
    }
    
    // Update mobile metrics if connected
    if (mobileConnected) {
      mobileSignalStrength = Math.floor(Math.random() * 5) + 1; // 1-5 bars
      
      // Determine network type (4G, 5G, etc.)
      const networkTypes = ['3G', '4G', '4G+', '5G'];
      const typeIndex = Math.floor(Math.random() * networkTypes.length);
      mobileNetworkType = networkTypes[typeIndex];
      
      // Simulate data usage increase
      const dataIncrement = Math.random() * 0.5; // 0-0.5 MB increment
      mobileDataUsed += dataIncrement;
    }
    
    // Preserve download/upload speeds from previous state
    // (these are updated separately in the speed test)
    const wifiDownloadSpeed = this.state.currentMetrics.network.wifi?.downloadSpeed || 0;
    const wifiUploadSpeed = this.state.currentMetrics.network.wifi?.uploadSpeed || 0;
    const mobileDownloadSpeed = this.state.currentMetrics.network.mobile?.downloadSpeed || 0;
    const mobileUploadSpeed = this.state.currentMetrics.network.mobile?.uploadSpeed || 0;
    
    // Update network metrics
    this.state.currentMetrics.network = {
      wifi: {
        connected: wifiConnected,
        signalStrength: wifiSignalStrength,
        downloadSpeed: wifiDownloadSpeed,
        uploadSpeed: wifiUploadSpeed,
        dataUsed: parseFloat(wifiDataUsed.toFixed(2))
      },
      mobile: {
        connected: mobileConnected,
        signalStrength: mobileSignalStrength,
        networkType: mobileNetworkType,
        downloadSpeed: mobileDownloadSpeed,
        uploadSpeed: mobileUploadSpeed,
        dataUsed: parseFloat(mobileDataUsed.toFixed(2))
      }
    };
    
    // Add to historical data
    this.state.historicalData.network.push({
      timestamp,
      wifiConnected,
      wifiSignalStrength,
      mobileConnected,
      mobileSignalStrength,
      activeNetwork: wifiConnected ? 'wifi' : (mobileConnected ? 'mobile' : null)
    });
    
    // Trim historical data if needed
    if (this.state.historicalData.network.length > this.state.monitoringSettings.historyLength) {
      this.state.historicalData.network.shift();
    }
  }
  
  /**
   * Test network speed
   */
  _testNetworkSpeed() {
    if (!this.state.monitoringActive || !this.state.monitoringSettings.showNetworkSpeed) {
      return;
    }
    
    // In a real app, this would perform an actual speed test
    // For the prototype, we'll generate simulated values
    
    // Check which network is active
    const wifiConnected = this.state.currentMetrics.network.wifi?.connected;
    const mobileConnected = this.state.currentMetrics.network.mobile?.connected;
    
    // Update Wi-Fi speed if connected
    if (wifiConnected) {
      // Generate random speeds (higher for Wi-Fi)
      const downloadSpeed = 20 + Math.random() * 80; // 20-100 Mbps
      const uploadSpeed = 5 + Math.random() * 25; // 5-30 Mbps
      
      this.state.currentMetrics.network.wifi.downloadSpeed = parseFloat(downloadSpeed.toFixed(2));
      this.state.currentMetrics.network.wifi.uploadSpeed = parseFloat(uploadSpeed.toFixed(2));
    }
    
    // Update mobile speed if connected
    if (mobileConnected) {
      // Determine speeds based on network type
      const networkType = this.state.currentMetrics.network.mobile.networkType;
      let downloadSpeed, uploadSpeed;
      
      switch (networkType) {
        case '3G':
          downloadSpeed = 1 + Math.random() * 5; // 1-6 Mbps
          uploadSpeed = 0.5 + Math.random() * 1.5; // 0.5-2 Mbps
          break;
        case '4G':
          downloadSpeed = 10 + Math.random() * 20; // 10-30 Mbps
          uploadSpeed = 3 + Math.random() * 7; // 3-10 Mbps
          break;
        case '4G+':
          downloadSpeed = 20 + Math.random() * 30; // 20-50 Mbps
          uploadSpeed = 5 + Math.random() * 15; // 5-20 Mbps
          break;
        case '5G':
          downloadSpeed = 50 + Math.random() * 450; // 50-500 Mbps
          uploadSpeed = 20 + Math.random() * 80; // 20-100 Mbps
          break;
        default:
          downloadSpeed = 5 + Math.random() * 15; // 5-20 Mbps
          uploadSpeed = 2 + Math.random() * 8; // 2-10 Mbps
      }
      
      this.state.currentMetrics.network.mobile.downloadSpeed = parseFloat(downloadSpeed.toFixed(2));
      this.state.currentMetrics.network.mobile.uploadSpeed = parseFloat(uploadSpeed.toFixed(2));
    }
    
    // Notify listeners about speed test results
    this._notifyListeners('speedTestCompleted', {
      wifi: {
        connected: wifiConnected,
        downloadSpeed: this.state.currentMetrics.network.wifi.downloadSpeed,
        uploadSpeed: this.state.currentMetrics.network.wifi.uploadSpeed
      },
      mobile: {
        connected: mobileConnected,
        downloadSpeed: this.state.currentMetrics.network.mobile.downloadSpeed,
        uploadSpeed: this.state.currentMetrics.network.mobile.uploadSpeed,
        networkType: this.state.currentMetrics.network.mobile.networkType
      },
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * Update list of top resource-consuming apps
   */
  _updateTopResourceApps() {
    // Combine data from RAM and CPU usage
    const appsData = {};
    
    // Add RAM-using apps
    this.state.currentMetrics.ram.apps.forEach(app => {
      if (app.name === 'Other apps' || app.name === 'System') {
        return;
      }
      
      appsData[app.name] = {
        name: app.name,
        ramUsage: app.ram,
        ramPercentage: app.percentage,
        cpuUsage: 0,
        cpuPercentage: 0,
        batteryDrain: 0
      };
    });
    
    // Simulate CPU usage for these apps
    Object.values(appsData).forEach(app => {
      // CPU usage somewhat correlates with RAM usage
      const cpuPercentage = (app.ramPercentage / 2) + (Math.random() * 10);
      app.cpuPercentage = parseFloat(cpuPercentage.toFixed(1));
      app.cpuUsage = parseFloat(((this.state.currentMetrics.cpu.usage * cpuPercentage) / 100).toFixed(1));
      
      // Simulate battery drain
      app.batteryDrain = parseFloat(((app.cpuPercentage + app.ramPercentage) / 50).toFixed(2));
    });
    
    // Sort by combined resource usage
    const sortedApps = Object.values(appsData).sort((a, b) => {
      const scoreA = a.cpuPercentage + a.ramPercentage;
      const scoreB = b.cpuPercentage + b.ramPercentage;
      return scoreB - scoreA;
    });
    
    // Keep top 5 apps
    this.state.topResourceApps = sortedApps.slice(0, 5);
  }
  
  /**
   * Generate warnings based on current metrics
   */
  _generateWarnings() {
    const warnings = [];
    
    // Check battery
    const batteryLevel = this.state.currentMetrics.battery.level;
    const batteryTemp = this.state.currentMetrics.temperature.battery;
    
    if (batteryLevel < 20 && !this.state.currentMetrics.battery.charging) {
      warnings.push({
        type: 'battery_low',
        level: batteryLevel < 10 ? 'critical' : 'warning',
        message: `Battery level is low (${batteryLevel}%)`,
        timestamp: new Date().toISOString()
      });
    }
    
    if (batteryTemp > 37) {
      warnings.push({
        type: 'battery_temp',
        level: batteryTemp > 40 ? 'critical' : 'warning',
        message: `Battery temperature is high (${batteryTemp.toFixed(1)}°C)`,
        timestamp: new Date().toISOString()
      });
    }
    
    // Check CPU
    const cpuTemp = this.state.currentMetrics.temperature.cpu;
    const cpuUsage = this.state.currentMetrics.cpu.usage;
    
    if (cpuTemp > 45) {
      warnings.push({
        type: 'cpu_temp',
        level: cpuTemp > 50 ? 'critical' : 'warning',
        message: `CPU temperature is high (${cpuTemp.toFixed(1)}°C)`,
        timestamp: new Date().toISOString()
      });
    }
    
    if (cpuUsage > 80) {
      warnings.push({
        type: 'cpu_usage',
        level: cpuUsage > 90 ? 'critical' : 'warning',
        message: `CPU usage is high (${cpuUsage.toFixed(1)}%)`,
        timestamp: new Date().toISOString()
      });
    }
    
    // Check RAM
    const ramTotal = this.state.currentMetrics.ram.total;
    const ramUsed = this.state.currentMetrics.ram.used;
    const ramPercentage = (ramUsed / ramTotal) * 100;
    
    if (ramPercentage > 85) {
      warnings.push({
        type: 'ram_usage',
        level: ramPercentage > 95 ? 'critical' : 'warning',
        message: `RAM usage is high (${ramPercentage.toFixed(1)}%)`,
        timestamp: new Date().toISOString()
      });
    }
    
    // Check storage
    const storageTotal = this.state.currentMetrics.storage.total;
    const storageFree = this.state.currentMetrics.storage.free;
    const storagePercentageFree = (storageFree / storageTotal) * 100;
    
    if (storagePercentageFree < 15) {
      warnings.push({
        type: 'storage_low',
        level: storagePercentageFree < 5 ? 'critical' : 'warning',
        message: `Storage space is low (${storagePercentageFree.toFixed(1)}% free)`,
        timestamp: new Date().toISOString()
      });
    }
    
    // Update warnings, only keeping new ones
    const currentWarningTypes = this.state.warnings.map(w => w.type);
    const newWarnings = warnings.filter(w => !currentWarningTypes.includes(w.type));
    
    // Add new warnings and sort by level (critical first)
    this.state.warnings = [...this.state.warnings, ...newWarnings]
      .sort((a, b) => a.level === 'critical' ? -1 : 1);
    
    // Limit to 5 most recent/important warnings
    if (this.state.warnings.length > 5) {
      this.state.warnings = this.state.warnings.slice(0, 5);
    }
    
    // Notify about new warnings
    if (newWarnings.length > 0 && this.state.monitoringSettings.showNotifications) {
      this._notifyListeners('warningsGenerated', {
        warnings: newWarnings,
        timestamp: new Date().toISOString()
      });
    }
  }
  
  /**
   * Generate optimization suggestions
   */
  _generateOptimizationSuggestions() {
    const suggestions = [];
    
    // RAM optimization suggestion
    const ramUsagePercent = (this.state.currentMetrics.ram.used / this.state.currentMetrics.ram.total) * 100;
    if (ramUsagePercent > 70) {
      suggestions.push({
        type: 'ram_optimization',
        message: 'Close unused apps to free up memory',
        impact: 'medium',
        apps: this.state.topResourceApps.slice(0, 3).map(app => app.name)
      });
    }
    
    // Battery optimization suggestions
    const batteryLevel = this.state.currentMetrics.battery.level;
    if (batteryLevel < 30 && !this.state.currentMetrics.battery.charging) {
      // Find battery-draining apps
      const batteryDrainers = this.state.topResourceApps
        .filter(app => app.batteryDrain > 0.2)
        .map(app => app.name);
      
      if (batteryDrainers.length > 0) {
        suggestions.push({
          type: 'battery_optimization',
          message: 'Close battery-draining apps to extend battery life',
          impact: 'high',
          apps: batteryDrainers
        });
      }
      
      // Suggest power saving mode
      suggestions.push({
        type: 'power_mode',
        message: 'Enable power saving mode to extend battery life',
        impact: 'high',
        action: 'enable_power_saving'
      });
    }
    
    // Storage optimization suggestion
    const storageFreePercent = (this.state.currentMetrics.storage.free / this.state.currentMetrics.storage.total) * 100;
    if (storageFreePercent < 20) {
      suggestions.push({
        type: 'storage_optimization',
        message: 'Clear cache or unused media to free up storage space',
        impact: 'medium',
        action: 'clear_cache'
      });
    }
    
    // Performance optimization suggestion
    const cpuUsage = this.state.currentMetrics.cpu.usage;
    if (cpuUsage > 70) {
      suggestions.push({
        type: 'performance_optimization',
        message: 'Close resource-intensive apps to improve performance',
        impact: 'medium',
        apps: this.state.topResourceApps.slice(0, 2).map(app => app.name)
      });
    }
    
    // Temperature optimization suggestion
    const cpuTemp = this.state.currentMetrics.temperature.cpu;
    if (cpuTemp > 40) {
      suggestions.push({
        type: 'temperature_optimization',
        message: 'Close heavy apps to reduce device temperature',
        impact: 'high',
        apps: this.state.topResourceApps.slice(0, 2).map(app => app.name)
      });
    }
    
    // Update suggestions
    this.state.optimizationSuggestions = suggestions;
  }
  
  /**
   * Dismiss a warning
   */
  dismissWarning(warningType) {
    const index = this.state.warnings.findIndex(w => w.type === warningType);
    
    if (index !== -1) {
      // Remove the warning
      this.state.warnings.splice(index, 1);
      
      return true;
    }
    
    return false;
  }
  
  /**
   * Apply suggested optimization
   */
  applyOptimization(type) {
    // In a real app, this would perform the actual optimizations
    // For the prototype, we'll simulate the effects
    
    console.log(`Applying optimization: ${type}`);
    
    switch (type) {
      case 'ram_optimization':
        // Simulate closing unused apps
        this.state.currentMetrics.ram.used = this.state.currentMetrics.ram.used * 0.7;
        
        // Update RAM-using apps
        this.state.currentMetrics.ram.apps.forEach(app => {
          app.ram = Math.floor(app.ram * 0.7);
          app.percentage = parseFloat((app.ram / this.state.currentMetrics.ram.total * 100).toFixed(1));
        });
        
        // Update CPU usage (correlated with RAM)
        this.state.currentMetrics.cpu.usage = this.state.currentMetrics.cpu.usage * 0.8;
        this.state.currentMetrics.cpu.cores.forEach(core => {
          core.usage = core.usage * 0.8;
        });
        break;
        
      case 'battery_optimization':
        // No direct effect on battery level, but reduce drain rate
        // This would be reflected in the next metrics update
        break;
        
      case 'power_mode':
        // Simulate enabling power saving mode
        this.state.currentMetrics.cpu.usage = this.state.currentMetrics.cpu.usage * 0.6;
        this.state.currentMetrics.cpu.cores.forEach(core => {
          core.usage = core.usage * 0.6;
          core.frequency = core.frequency * 0.7;
        });
        
        // Update CPU frequency
        this.state.currentMetrics.cpu.frequency = 
          this.state.currentMetrics.cpu.cores.reduce((sum, core) => sum + core.frequency, 0) / 
          this.state.currentMetrics.cpu.cores.length;
        break;
        
      case 'storage_optimization':
        // Simulate clearing cache
        this.state.currentMetrics.storage.used -= 2 * 1024; // -2 GB
        this.state.currentMetrics.storage.free += 2 * 1024; // +2 GB
        
        // Update storage-using apps
        const otherApp = this.state.currentMetrics.storage.apps.find(app => app.name === 'Other');
        if (otherApp) {
          otherApp.storage -= 2 * 1024;
          otherApp.percentage = parseFloat(
            (otherApp.storage / this.state.currentMetrics.storage.total * 100).toFixed(1)
          );
        }
        break;
        
      case 'performance_optimization':
        // Simulate closing resource-intensive apps
        this.state.currentMetrics.cpu.usage = this.state.currentMetrics.cpu.usage * 0.6;
        this.state.currentMetrics.ram.used = this.state.currentMetrics.ram.used * 0.8;
        
        // Update CPU cores
        this.state.currentMetrics.cpu.cores.forEach(core => {
          core.usage = core.usage * 0.6;
        });
        
        // Temperature reduction
        this.state.currentMetrics.temperature.cpu -= 5;
        break;
        
      case 'temperature_optimization':
        // Simulate closing heavy apps to reduce temperature
        this.state.currentMetrics.temperature.cpu -= 8;
        this.state.currentMetrics.temperature.battery -= 3;
        
        // Also reduce CPU usage
        this.state.currentMetrics.cpu.usage = this.state.currentMetrics.cpu.usage * 0.7;
        this.state.currentMetrics.cpu.cores.forEach(core => {
          core.usage = core.usage * 0.7;
        });
        break;
        
      default:
        // Unknown optimization type
        return false;
    }
    
    // Remove the applied optimization suggestion
    this.state.optimizationSuggestions = this.state.optimizationSuggestions.filter(s => s.type !== type);
    
    // Regenerate warnings after optimization
    this._generateWarnings();
    
    // Notify listeners about optimization
    this._notifyListeners('optimizationApplied', {
      type,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Update monitoring settings
   */
  updateSettings(settings) {
    // Store previous update interval
    const previousInterval = this.state.monitoringSettings.updateInterval;
    
    // Update settings
    this.state.monitoringSettings = {
      ...this.state.monitoringSettings,
      ...settings
    };
    
    // Adjust monitoring interval if changed and monitoring is active
    if (this.state.monitoringActive && 
        previousInterval !== this.state.monitoringSettings.updateInterval && 
        this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      
      this.monitoringInterval = setInterval(() => {
        this._updateMetrics();
      }, this.state.monitoringSettings.updateInterval);
    }
    
    // Notify listeners
    this._notifyListeners('settingsUpdated', {
      settings: this.state.monitoringSettings,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true,
      settings: this.state.monitoringSettings
    };
  }
  
  /**
   * Set visualization type
   */
  setVisualizationType(type) {
    if (!['3d_bars', '3d_wave', '3d_glow', 'flat_charts'].includes(type)) {
      return {
        success: false,
        error: 'Invalid visualization type'
      };
    }
    
    this.state.monitoringSettings.visualizationType = type;
    
    // Notify listeners
    this._notifyListeners('visualizationChanged', {
      type,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true,
      type
    };
  }
  
  /**
   * Enable or disable performance monitoring
   */
  setEnabled(enabled) {
    this.state.enabled = enabled;
    
    // Start or stop monitoring
    if (enabled && !this.state.monitoringActive) {
      this.startMonitoring();
    } else if (!enabled && this.state.monitoringActive) {
      this.stopMonitoring();
    }
    
    // Notify listeners
    this._notifyListeners('enabledStateChanged', {
      enabled,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Get current performance metrics
   */
  getCurrentMetrics() {
    return {
      metrics: this.state.currentMetrics,
      lastUpdate: this.state.lastUpdate
    };
  }
  
  /**
   * Get historical performance data
   */
  getHistoricalData() {
    return this.state.historicalData;
  }
  
  /**
   * Get top resource-consuming apps
   */
  getTopResourceApps() {
    return this.state.topResourceApps;
  }
  
  /**
   * Get active warnings
   */
  getWarnings() {
    return this.state.warnings;
  }
  
  /**
   * Get optimization suggestions
   */
  getOptimizationSuggestions() {
    return this.state.optimizationSuggestions;
  }
  
  /**
   * Get monitoring settings
   */
  getSettings() {
    return this.state.monitoringSettings;
  }
  
  /**
   * Subscribe to performance monitoring events
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from performance monitoring events
   */
  unsubscribe(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  /**
   * Notify all listeners of an event
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in performance monitoring service listener:', error);
      }
    });
  }
  
  /**
   * Clean up the service
   */
  cleanup() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    
    if (this.speedTestInterval) {
      clearInterval(this.speedTestInterval);
      this.speedTestInterval = null;
    }
    
    this.state.monitoringActive = false;
    this.listeners = [];
  }
}

// Export as singleton
export const PerformanceMonitoringService = new PerformanceMonitoringServiceClass();