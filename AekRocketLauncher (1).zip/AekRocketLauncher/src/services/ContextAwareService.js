/**
 * Service for context-aware features
 * Detects user context (time, location, activity) and provides intelligent adaptations
 */

class ContextAwareServiceClass {
  constructor() {
    // Default state
    this.state = {
      timeContext: 'day', // 'morning', 'day', 'evening', 'night'
      locationContext: 'home', // 'home', 'work', 'commuting', 'other'
      activityContext: 'active', // 'idle', 'active', 'productive', 'entertainment'
      detectedMood: 'neutral', // 'happy', 'stressed', 'relaxed', 'tired', 'neutral'
      currentWeather: null,
      localEvents: [],
      recentApps: [],
      frequentApps: {},
      appSuggestions: [],
      contextSwitches: 0,
      initialized: false
    };
    
    // Listeners for context changes
    this.listeners = [];
    
    // Context detection intervals
    this.timeContextInterval = null;
    this.appUsageInterval = null;
  }
  
  /**
   * Initialize the context-aware service
   */
  async initialize() {
    try {
      if (this.initialized) {
        return true;
      }
      
      // Start the context detection processes
      this._startTimeContextDetection();
      this._startAppUsageTracking();
      
      // Try to get current location context
      this._detectLocationContext();
      
      // Generate initial app suggestions
      this._generateAppSuggestions();
      
      this.initialized = true;
      console.log('ContextAwareService initialized');
      return true;
    } catch (error) {
      console.error('Failed to initialize ContextAwareService:', error);
      return false;
    }
  }
  
  /**
   * Detect time context (morning, day, evening, night)
   */
  _startTimeContextDetection() {
    // Immediately detect current time context
    this._updateTimeContext();
    
    // Set up interval to check time context every 15 minutes
    this.timeContextInterval = setInterval(() => {
      this._updateTimeContext();
    }, 15 * 60 * 1000);
  }
  
  /**
   * Update the time context based on current time
   */
  _updateTimeContext() {
    const now = new Date();
    const hour = now.getHours();
    
    let newTimeContext;
    
    if (hour >= 5 && hour < 12) {
      newTimeContext = 'morning';
    } else if (hour >= 12 && hour < 17) {
      newTimeContext = 'day';
    } else if (hour >= 17 && hour < 22) {
      newTimeContext = 'evening';
    } else {
      newTimeContext = 'night';
    }
    
    // Only update if context changed
    if (this.state.timeContext !== newTimeContext) {
      const oldContext = this.state.timeContext;
      this.state.timeContext = newTimeContext;
      this.state.contextSwitches++;
      
      // Generate new app suggestions based on new time context
      this._generateAppSuggestions();
      
      // Notify listeners of context change
      this._notifyListeners('timeContextChanged', { 
        from: oldContext, 
        to: newTimeContext,
        timestamp: now.toISOString()
      });
    }
  }
  
  /**
   * Detect location context (home, work, commuting, other)
   */
  _detectLocationContext() {
    // In a real implementation, this would use device location or connectivity patterns
    // For the prototype, we'll simulate location changes
    
    // Get the day of week and hour to make predictable patterns
    const now = new Date();
    const dayOfWeek = now.getDay(); // 0 = Sunday, 1 = Monday, etc.
    const hour = now.getHours();
    
    let newLocationContext;
    
    // Weekday simulation
    if (dayOfWeek >= 1 && dayOfWeek <= 5) {
      if (hour >= 9 && hour < 17) {
        newLocationContext = 'work';
      } else if ((hour >= 8 && hour < 9) || (hour >= 17 && hour < 18)) {
        newLocationContext = 'commuting';
      } else {
        newLocationContext = 'home';
      }
    } else {
      // Weekend simulation
      newLocationContext = hour >= 10 && hour < 18 ? 'other' : 'home';
    }
    
    // Only update if context changed
    if (this.state.locationContext !== newLocationContext) {
      const oldContext = this.state.locationContext;
      this.state.locationContext = newLocationContext;
      this.state.contextSwitches++;
      
      // Generate new app suggestions based on new location context
      this._generateAppSuggestions();
      
      // Notify listeners of context change
      this._notifyListeners('locationContextChanged', { 
        from: oldContext, 
        to: newLocationContext,
        timestamp: now.toISOString()
      });
    }
  }
  
  /**
   * Start tracking app usage patterns
   */
  _startAppUsageTracking() {
    // Immediately generate initial app usage data
    this._updateAppUsageData();
    
    // Set up interval to update app usage data every 5 minutes
    this.appUsageInterval = setInterval(() => {
      this._updateAppUsageData();
    }, 5 * 60 * 1000);
  }
  
  /**
   * Update app usage data and activity context
   */
  _updateAppUsageData() {
    // In a real implementation, this would track actual app usage
    // For the prototype, we'll simulate app usage based on time and location context
    
    // Generate recent apps based on time and location
    const recentApps = this._generateSimulatedRecentApps();
    this.state.recentApps = recentApps;
    
    // Update frequent apps counters
    recentApps.forEach(app => {
      if (!this.state.frequentApps[app.packageName]) {
        this.state.frequentApps[app.packageName] = {
          count: 0,
          lastUsed: new Date().toISOString(),
          contexts: {}
        };
      }
      
      this.state.frequentApps[app.packageName].count++;
      this.state.frequentApps[app.packageName].lastUsed = new Date().toISOString();
      
      // Track which contexts this app is used in
      const timeContext = this.state.timeContext;
      const locationContext = this.state.locationContext;
      
      if (!this.state.frequentApps[app.packageName].contexts[timeContext]) {
        this.state.frequentApps[app.packageName].contexts[timeContext] = 0;
      }
      this.state.frequentApps[app.packageName].contexts[timeContext]++;
      
      if (!this.state.frequentApps[app.packageName].contexts[locationContext]) {
        this.state.frequentApps[app.packageName].contexts[locationContext] = 0;
      }
      this.state.frequentApps[app.packageName].contexts[locationContext]++;
    });
    
    // Determine activity context based on recent apps
    this._updateActivityContext(recentApps);
    
    // Generate new app suggestions
    this._generateAppSuggestions();
  }
  
  /**
   * Generate simulated recent apps based on time and location
   */
  _generateSimulatedRecentApps() {
    const timeContext = this.state.timeContext;
    const locationContext = this.state.locationContext;
    
    // Base set of common apps
    const commonApps = [
      { packageName: 'com.android.chrome', appName: 'Chrome', category: 'Productivity' },
      { packageName: 'com.whatsapp', appName: 'WhatsApp', category: 'Communication' }
    ];
    
    // Apps specifically for different time contexts
    const timeContextApps = {
      morning: [
        { packageName: 'com.android.calendar', appName: 'Calendar', category: 'Productivity' },
        { packageName: 'com.weather.forecast', appName: 'Weather', category: 'Utility' },
        { packageName: 'com.news.app', appName: 'News', category: 'News' }
      ],
      day: [
        { packageName: 'com.slack', appName: 'Slack', category: 'Productivity' },
        { packageName: 'com.google.docs', appName: 'Google Docs', category: 'Productivity' },
        { packageName: 'com.email.app', appName: 'Email', category: 'Communication' }
      ],
      evening: [
        { packageName: 'com.netflix', appName: 'Netflix', category: 'Entertainment' },
        { packageName: 'com.spotify.music', appName: 'Spotify', category: 'Entertainment' },
        { packageName: 'com.instagram.android', appName: 'Instagram', category: 'Social' }
      ],
      night: [
        { packageName: 'com.spotify.music', appName: 'Spotify', category: 'Entertainment' },
        { packageName: 'com.amazon.kindle', appName: 'Kindle', category: 'Reading' },
        { packageName: 'com.calm', appName: 'Calm', category: 'Wellness' }
      ]
    };
    
    // Apps specifically for different location contexts
    const locationContextApps = {
      home: [
        { packageName: 'com.netflix', appName: 'Netflix', category: 'Entertainment' },
        { packageName: 'com.spotify.music', appName: 'Spotify', category: 'Entertainment' },
        { packageName: 'com.home.automation', appName: 'Smart Home', category: 'Utility' }
      ],
      work: [
        { packageName: 'com.slack', appName: 'Slack', category: 'Productivity' },
        { packageName: 'com.microsoft.teams', appName: 'Teams', category: 'Productivity' },
        { packageName: 'com.google.drive', appName: 'Drive', category: 'Productivity' }
      ],
      commuting: [
        { packageName: 'com.spotify.music', appName: 'Spotify', category: 'Entertainment' },
        { packageName: 'com.audible.application', appName: 'Audible', category: 'Entertainment' },
        { packageName: 'com.google.maps', appName: 'Maps', category: 'Navigation' }
      ],
      other: [
        { packageName: 'com.google.maps', appName: 'Maps', category: 'Navigation' },
        { packageName: 'com.yelp.android', appName: 'Yelp', category: 'Food & Drink' },
        { packageName: 'com.instagram.android', appName: 'Instagram', category: 'Social' }
      ]
    };
    
    // Combine apps based on current contexts
    const contextApps = [
      ...commonApps,
      ...timeContextApps[timeContext],
      ...locationContextApps[locationContext]
    ];
    
    // Remove duplicates
    const uniqueApps = [];
    const seenPackages = new Set();
    
    for (const app of contextApps) {
      if (!seenPackages.has(app.packageName)) {
        uniqueApps.push(app);
        seenPackages.add(app.packageName);
      }
    }
    
    // Add usage duration (simulated)
    return uniqueApps.map(app => ({
      ...app,
      lastUsed: new Date().toISOString(),
      usageDuration: Math.floor(Math.random() * 30) + 1 // 1-30 minutes
    }));
  }
  
  /**
   * Update the activity context based on recent apps
   */
  _updateActivityContext(recentApps) {
    if (!recentApps || recentApps.length === 0) {
      return;
    }
    
    // Count app categories
    const categoryCounts = {};
    recentApps.forEach(app => {
      if (!categoryCounts[app.category]) {
        categoryCounts[app.category] = 0;
      }
      categoryCounts[app.category] += app.usageDuration || 1;
    });
    
    // Determine predominant activity
    let maxCount = 0;
    let predominantCategory = '';
    
    for (const [category, count] of Object.entries(categoryCounts)) {
      if (count > maxCount) {
        maxCount = count;
        predominantCategory = category;
      }
    }
    
    // Map category to activity context
    let newActivityContext;
    
    if (['Productivity', 'Communication', 'Business'].includes(predominantCategory)) {
      newActivityContext = 'productive';
    } else if (['Entertainment', 'Social', 'Games'].includes(predominantCategory)) {
      newActivityContext = 'entertainment';
    } else if (['Utility', 'Tools', 'Navigation'].includes(predominantCategory)) {
      newActivityContext = 'active';
    } else {
      newActivityContext = 'idle';
    }
    
    // Only update if context changed
    if (this.state.activityContext !== newActivityContext) {
      const oldContext = this.state.activityContext;
      this.state.activityContext = newActivityContext;
      this.state.contextSwitches++;
      
      // Notify listeners of context change
      this._notifyListeners('activityContextChanged', { 
        from: oldContext, 
        to: newActivityContext,
        timestamp: new Date().toISOString()
      });
    }
  }
  
  /**
   * Generate app suggestions based on current context
   */
  _generateAppSuggestions() {
    const timeContext = this.state.timeContext;
    const locationContext = this.state.locationContext;
    const activityContext = this.state.activityContext;
    
    // Get the most frequently used apps in this context
    const suggestions = [];
    const seenPackages = new Set();
    
    // First add apps that are frequently used in this exact time+location context
    for (const [packageName, data] of Object.entries(this.state.frequentApps)) {
      if (data.contexts[timeContext] && data.contexts[locationContext]) {
        suggestions.push({
          packageName,
          score: (data.contexts[timeContext] + data.contexts[locationContext]) / 2,
          reason: `Frequently used during ${timeContext} at ${locationContext}`
        });
        seenPackages.add(packageName);
      }
    }
    
    // Then add apps that are appropriate for the current context but may not have been used yet
    const contextualSuggestions = this._getContextualAppSuggestions();
    
    for (const app of contextualSuggestions) {
      if (!seenPackages.has(app.packageName)) {
        suggestions.push({
          packageName: app.packageName,
          score: 0.5, // Medium priority
          reason: app.reason
        });
        seenPackages.add(app.packageName);
      }
    }
    
    // Sort by score (descending)
    suggestions.sort((a, b) => b.score - a.score);
    
    // Take top 5
    this.state.appSuggestions = suggestions.slice(0, 5);
    
    // Notify listeners
    this._notifyListeners('appSuggestionsUpdated', {
      suggestions: this.state.appSuggestions,
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * Get contextual app suggestions based on current context
   */
  _getContextualAppSuggestions() {
    const timeContext = this.state.timeContext;
    const locationContext = this.state.locationContext;
    
    const suggestions = [];
    
    // Morning suggestions
    if (timeContext === 'morning') {
      suggestions.push(
        { packageName: 'com.android.calendar', reason: 'Check your schedule for today' },
        { packageName: 'com.weather.forecast', reason: 'Check today\'s weather' },
        { packageName: 'com.news.app', reason: 'Catch up on the latest news' }
      );
    }
    
    // Work location suggestions
    if (locationContext === 'work') {
      suggestions.push(
        { packageName: 'com.slack', reason: 'Stay in touch with your team' },
        { packageName: 'com.microsoft.teams', reason: 'Join your scheduled meetings' },
        { packageName: 'com.google.drive', reason: 'Access your work documents' }
      );
    }
    
    // Commuting suggestions
    if (locationContext === 'commuting') {
      suggestions.push(
        { packageName: 'com.spotify.music', reason: 'Listen to music while commuting' },
        { packageName: 'com.google.maps', reason: 'Navigate to your destination' },
        { packageName: 'com.audible.application', reason: 'Listen to an audiobook' }
      );
    }
    
    // Evening suggestions
    if (timeContext === 'evening' && locationContext === 'home') {
      suggestions.push(
        { packageName: 'com.netflix', reason: 'Relax with your favorite shows' },
        { packageName: 'com.fooddelivery.app', reason: 'Order dinner' },
        { packageName: 'com.home.automation', reason: 'Control your home devices' }
      );
    }
    
    // Night suggestions
    if (timeContext === 'night') {
      suggestions.push(
        { packageName: 'com.calm', reason: 'Prepare for sleep with meditation' },
        { packageName: 'com.amazon.kindle', reason: 'Read before bed' },
        { packageName: 'com.sleeptracker.app', reason: 'Track your sleep' }
      );
    }
    
    return suggestions;
  }
  
  /**
   * Detect user's mood based on app usage, interactions, etc.
   */
  async detectMood() {
    // In a real implementation, this would use more sophisticated methods
    // For the prototype, we'll use a simple heuristic based on app categories
    
    // Get recent app usage
    const recentApps = this.state.recentApps;
    
    if (!recentApps || recentApps.length === 0) {
      return 'neutral';
    }
    
    // Define mood-related app categories
    const categoryMoodMap = {
      'Entertainment': 'happy',
      'Games': 'happy',
      'Social': 'happy',
      'Productivity': 'focused',
      'Business': 'focused',
      'Wellness': 'relaxed',
      'Health & Fitness': 'relaxed',
      'News': 'informed',
      'Weather': 'prepared'
    };
    
    // Count app categories
    const categoryCounts = {};
    recentApps.forEach(app => {
      if (!categoryCounts[app.category]) {
        categoryCounts[app.category] = 0;
      }
      categoryCounts[app.category]++;
    });
    
    // Determine predominant mood
    let maxCount = 0;
    let predominantMood = 'neutral';
    
    for (const [category, count] of Object.entries(categoryCounts)) {
      if (count > maxCount && categoryMoodMap[category]) {
        maxCount = count;
        predominantMood = categoryMoodMap[category];
      }
    }
    
    // Update mood if changed
    if (this.state.detectedMood !== predominantMood) {
      const oldMood = this.state.detectedMood;
      this.state.detectedMood = predominantMood;
      
      // Notify listeners of mood change
      this._notifyListeners('moodChanged', {
        from: oldMood,
        to: predominantMood,
        timestamp: new Date().toISOString()
      });
    }
    
    return predominantMood;
  }
  
  /**
   * Get the current context
   */
  getCurrentContext() {
    return {
      time: this.state.timeContext,
      location: this.state.locationContext,
      activity: this.state.activityContext,
      mood: this.state.detectedMood,
      suggestions: this.state.appSuggestions
    };
  }
  
  /**
   * Get detailed app usage statistics
   */
  getAppUsageStats() {
    return {
      recentApps: this.state.recentApps,
      frequentApps: this.state.frequentApps
    };
  }
  
  /**
   * Subscribe to context changes
   * @param {Function} listener - The listener function
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from context changes
   * @param {Function} listener - The listener to remove
   */
  unsubscribe(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  /**
   * Notify all listeners of context changes
   * @param {string} event - The event type
   * @param {object} data - The event data
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in context service listener:', error);
      }
    });
  }
  
  /**
   * Clean up the service
   */
  cleanup() {
    if (this.timeContextInterval) {
      clearInterval(this.timeContextInterval);
    }
    
    if (this.appUsageInterval) {
      clearInterval(this.appUsageInterval);
    }
    
    this.listeners = [];
    console.log('ContextAwareService cleaned up');
  }
}

// Export as singleton
export const ContextAwareService = new ContextAwareServiceClass();