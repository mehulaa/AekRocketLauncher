/**
 * Service for mood detection and mood-based interface adaptation
 * Uses facial recognition and app usage patterns to detect user mood
 */

class MoodDetectionServiceClass {
  constructor() {
    // State
    this.state = {
      enabled: true,
      currentMood: 'neutral', // 'happy', 'sad', 'stressed', 'relaxed', 'tired', 'focused', 'neutral'
      moodConfidence: 0.0, // 0.0 to 1.0
      moodTimestamp: null,
      moodHistory: [],
      detectionSettings: {
        useFacialRecognition: true,
        useAppUsagePatterns: true,
        useTypingPatterns: false,
        detectionInterval: 5 * 60 * 1000, // 5 minutes
        minConfidence: 0.6, // Minimum confidence to register mood change
        sensitivity: 0.7, // 0.0 to 1.0
        notifyOnMoodChange: true
      },
      moodBasedThemes: {
        happy: {
          id: 'mood_happy',
          name: 'Vibrant',
          primaryColor: '#FFC107',
          accentColor: '#FF5722',
          backgroundColor: '#FFECB3',
          textColor: '#212121',
          isDark: false,
          animations: 'playful'
        },
        sad: {
          id: 'mood_sad',
          name: 'Calm Blue',
          primaryColor: '#42A5F5',
          accentColor: '#1976D2',
          backgroundColor: '#E3F2FD',
          textColor: '#212121',
          isDark: false,
          animations: 'gentle'
        },
        stressed: {
          id: 'mood_stressed',
          name: 'Serene',
          primaryColor: '#66BB6A',
          accentColor: '#388E3C',
          backgroundColor: '#E8F5E9',
          textColor: '#212121',
          isDark: false,
          animations: 'minimal'
        },
        relaxed: {
          id: 'mood_relaxed',
          name: 'Sunset',
          primaryColor: '#FF9800',
          accentColor: '#F57C00',
          backgroundColor: '#FFF3E0',
          textColor: '#212121',
          isDark: false,
          animations: 'fluid'
        },
        tired: {
          id: 'mood_tired',
          name: 'Night Mode',
          primaryColor: '#5E35B1',
          accentColor: '#7E57C2',
          backgroundColor: '#212121',
          textColor: '#FFFFFF',
          isDark: true,
          animations: 'minimal'
        },
        focused: {
          id: 'mood_focused',
          name: 'Productivity',
          primaryColor: '#00ACC1',
          accentColor: '#00838F',
          backgroundColor: '#E0F7FA',
          textColor: '#212121',
          isDark: false,
          animations: 'efficient'
        },
        neutral: {
          id: 'mood_neutral',
          name: 'Balanced',
          primaryColor: '#9E9E9E',
          accentColor: '#607D8B',
          backgroundColor: '#FAFAFA',
          textColor: '#212121',
          isDark: false,
          animations: 'standard'
        }
      },
      initialized: false,
      detectionActive: false
    };
    
    // Listeners
    this.listeners = [];
    
    // Detection interval reference
    this.detectionInterval = null;
  }
  
  /**
   * Initialize the mood detection service
   */
  async initialize() {
    if (this.state.initialized) {
      return true;
    }
    
    try {
      // Load saved settings
      await this._loadSettings();
      
      // Set initial mood from history if available
      await this._loadMoodHistory();
      
      this.state.initialized = true;
      console.log('MoodDetectionService initialized');
      
      // Start mood detection if enabled
      if (this.state.enabled) {
        this.startDetection();
      }
      
      // Notify listeners
      this._notifyListeners('serviceInitialized', { success: true });
      
      return true;
    } catch (error) {
      console.error('Failed to initialize MoodDetectionService:', error);
      return false;
    }
  }
  
  /**
   * Load saved settings from storage
   */
  async _loadSettings() {
    // In a real app, this would load from device storage
    // For the prototype, we use default values
    console.log('MoodDetectionService: Loading settings...');
  }
  
  /**
   * Load mood history from storage
   */
  async _loadMoodHistory() {
    // In a real app, this would load from device storage
    // For the prototype, we'll generate some simulated history
    const now = new Date();
    
    // Generate some mood history for the last day
    const moods = ['happy', 'neutral', 'focused', 'relaxed', 'neutral', 'tired'];
    const history = [];
    
    for (let i = 0; i < moods.length; i++) {
      const timestamp = new Date(now.getTime() - ((moods.length - i) * 4 * 60 * 60 * 1000));
      
      history.push({
        mood: moods[i],
        confidence: 0.7 + Math.random() * 0.3, // 0.7 to 1.0
        timestamp: timestamp.toISOString(),
        source: Math.random() > 0.5 ? 'facial' : 'usage'
      });
    }
    
    this.state.moodHistory = history;
    
    // Set current mood from the most recent history entry
    if (history.length > 0) {
      const lastMood = history[history.length - 1];
      this.state.currentMood = lastMood.mood;
      this.state.moodConfidence = lastMood.confidence;
      this.state.moodTimestamp = lastMood.timestamp;
    }
  }
  
  /**
   * Start mood detection
   */
  startDetection() {
    if (!this.state.enabled || this.state.detectionActive) {
      return false;
    }
    
    this.state.detectionActive = true;
    
    // Perform an initial mood detection
    this._detectMood();
    
    // Set up interval for periodic detection
    this.detectionInterval = setInterval(() => {
      this._detectMood();
    }, this.state.detectionSettings.detectionInterval);
    
    console.log('MoodDetectionService: Started detection');
    
    // Notify listeners
    this._notifyListeners('detectionStarted', { 
      timestamp: new Date().toISOString() 
    });
    
    return true;
  }
  
  /**
   * Stop mood detection
   */
  stopDetection() {
    if (!this.state.detectionActive) {
      return false;
    }
    
    this.state.detectionActive = false;
    
    // Clear detection interval
    if (this.detectionInterval) {
      clearInterval(this.detectionInterval);
      this.detectionInterval = null;
    }
    
    console.log('MoodDetectionService: Stopped detection');
    
    // Notify listeners
    this._notifyListeners('detectionStopped', { 
      timestamp: new Date().toISOString() 
    });
    
    return true;
  }
  
  /**
   * Perform mood detection
   */
  async _detectMood() {
    try {
      let detectedMood = 'neutral';
      let confidence = 0.0;
      let source = 'default';
      
      // Combine results from different detection methods
      const detectionResults = [];
      
      // Use facial recognition if enabled
      if (this.state.detectionSettings.useFacialRecognition) {
        const facialResult = await this._detectMoodFromFacialExpression();
        if (facialResult) {
          detectionResults.push({
            ...facialResult,
            weight: 0.6 // Facial expressions have higher weight
          });
        }
      }
      
      // Use app usage patterns if enabled
      if (this.state.detectionSettings.useAppUsagePatterns) {
        const usageResult = await this._detectMoodFromAppUsage();
        if (usageResult) {
          detectionResults.push({
            ...usageResult,
            weight: 0.4 // App usage has lower weight
          });
        }
      }
      
      // Use typing patterns if enabled
      if (this.state.detectionSettings.useTypingPatterns) {
        const typingResult = await this._detectMoodFromTypingPatterns();
        if (typingResult) {
          detectionResults.push({
            ...typingResult,
            weight: 0.3 // Typing patterns have lower weight
          });
        }
      }
      
      // If we have results, combine them weighted by confidence and method weight
      if (detectionResults.length > 0) {
        // Calculate weighted score for each mood
        const moodScores = {};
        
        for (const result of detectionResults) {
          if (!moodScores[result.mood]) {
            moodScores[result.mood] = 0;
          }
          
          moodScores[result.mood] += result.confidence * result.weight;
        }
        
        // Find the mood with the highest weighted score
        let highestScore = 0;
        
        for (const [mood, score] of Object.entries(moodScores)) {
          if (score > highestScore) {
            highestScore = score;
            detectedMood = mood;
            // Normalize confidence to 0-1 range
            confidence = Math.min(1.0, highestScore / Math.max(...detectionResults.map(r => r.weight)));
            source = detectionResults.find(r => r.mood === mood).source;
          }
        }
      } else {
        // If no detection methods return results, keep the current mood
        detectedMood = this.state.currentMood;
        confidence = this.state.moodConfidence;
        source = 'previous';
      }
      
      // Only update the mood if confidence exceeds minimum threshold
      if (confidence >= this.state.detectionSettings.minConfidence) {
        const previousMood = this.state.currentMood;
        const timestamp = new Date().toISOString();
        
        // Update current mood
        this.state.currentMood = detectedMood;
        this.state.moodConfidence = confidence;
        this.state.moodTimestamp = timestamp;
        
        // Add to mood history if the mood changed
        if (previousMood !== detectedMood) {
          this.state.moodHistory.push({
            mood: detectedMood,
            confidence,
            timestamp,
            source
          });
          
          // Keep history from growing too large
          if (this.state.moodHistory.length > 20) {
            this.state.moodHistory.shift();
          }
          
          // Notify mood change if enabled
          if (this.state.detectionSettings.notifyOnMoodChange) {
            this._notifyMoodChange(previousMood, detectedMood, confidence);
          }
        }
        
        // Notify listeners of detection results
        this._notifyListeners('moodDetected', {
          mood: detectedMood,
          confidence,
          timestamp,
          source,
          changed: previousMood !== detectedMood
        });
      }
      
      return {
        mood: detectedMood,
        confidence,
        source
      };
    } catch (error) {
      console.error('Error detecting mood:', error);
      return null;
    }
  }
  
  /**
   * Detect mood from facial expression
   */
  async _detectMoodFromFacialExpression() {
    // In a real app, this would use camera and ML model
    // For the prototype, we'll simulate detection results
    
    // Randomly decide if we can detect a face
    const faceDetected = Math.random() > 0.2;
    
    if (!faceDetected) {
      return null;
    }
    
    // Generate a simulated mood detection result
    const moods = ['happy', 'sad', 'stressed', 'relaxed', 'tired', 'neutral', 'focused'];
    const randomIndex = Math.floor(Math.random() * moods.length);
    const detectedMood = moods[randomIndex];
    
    // Generate a realistic confidence value
    // Higher confidence for more distinctive moods
    let confidence;
    if (detectedMood === 'happy' || detectedMood === 'sad') {
      confidence = 0.75 + (Math.random() * 0.25); // 0.75 to 1.0
    } else if (detectedMood === 'neutral') {
      confidence = 0.6 + (Math.random() * 0.3); // 0.6 to 0.9
    } else {
      confidence = 0.6 + (Math.random() * 0.2); // 0.6 to 0.8
    }
    
    console.log(`Facial mood detection: ${detectedMood} (${confidence.toFixed(2)} confidence)`);
    
    return {
      mood: detectedMood,
      confidence,
      source: 'facial'
    };
  }
  
  /**
   * Detect mood from app usage patterns
   */
  async _detectMoodFromAppUsage() {
    // In a real app, this would analyze actual app usage
    // For the prototype, we'll simulate detection results
    
    // Simulated app categories related to moods
    const appCategoryMoods = {
      'Entertainment': 'happy',
      'Games': 'happy',
      'Music': 'relaxed',
      'Productivity': 'focused',
      'Health': 'relaxed',
      'Social': 'happy',
      'News': 'stressed',
      'Finance': 'stressed',
      'Reading': 'relaxed'
    };
    
    // Simulated recent app usage
    const recentCategories = [];
    for (let i = 0; i < 3; i++) {
      const categories = Object.keys(appCategoryMoods);
      const randomIndex = Math.floor(Math.random() * categories.length);
      recentCategories.push(categories[randomIndex]);
    }
    
    // Count instances of each mood
    const moodCounts = {};
    recentCategories.forEach(category => {
      const mood = appCategoryMoods[category];
      if (!moodCounts[mood]) {
        moodCounts[mood] = 0;
      }
      moodCounts[mood]++;
    });
    
    // Find the most frequent mood
    let maxCount = 0;
    let dominantMood = 'neutral';
    
    for (const [mood, count] of Object.entries(moodCounts)) {
      if (count > maxCount) {
        maxCount = count;
        dominantMood = mood;
      }
    }
    
    // Calculate confidence based on how dominant the mood is
    const confidence = Math.min(1.0, 0.5 + (maxCount / recentCategories.length) * 0.5);
    
    console.log(`App usage mood detection: ${dominantMood} (${confidence.toFixed(2)} confidence)`);
    
    return {
      mood: dominantMood,
      confidence,
      source: 'usage'
    };
  }
  
  /**
   * Detect mood from typing patterns
   */
  async _detectMoodFromTypingPatterns() {
    // In a real app, this would analyze typing speed, pressure, etc.
    // For the prototype, we'll return null to indicate no data available
    return null;
  }
  
  /**
   * Notify about mood change
   */
  _notifyMoodChange(previousMood, newMood, confidence) {
    console.log(`Mood changed from ${previousMood} to ${newMood} (${confidence.toFixed(2)} confidence)`);
    
    // Get theme for the new mood
    const moodTheme = this.getMoodTheme(newMood);
    
    // Notify listeners of mood change
    this._notifyListeners('moodChanged', {
      from: previousMood,
      to: newMood,
      confidence,
      timestamp: new Date().toISOString(),
      suggestedTheme: moodTheme
    });
  }
  
  /**
   * Manually set the current mood
   */
  setMood(mood, confidence = 0.9) {
    if (!Object.keys(this.state.moodBasedThemes).includes(mood)) {
      return false;
    }
    
    const previousMood = this.state.currentMood;
    const timestamp = new Date().toISOString();
    
    // Update current mood
    this.state.currentMood = mood;
    this.state.moodConfidence = confidence;
    this.state.moodTimestamp = timestamp;
    
    // Add to mood history
    this.state.moodHistory.push({
      mood,
      confidence,
      timestamp,
      source: 'manual'
    });
    
    // Keep history from growing too large
    if (this.state.moodHistory.length > 20) {
      this.state.moodHistory.shift();
    }
    
    // Notify mood change
    this._notifyMoodChange(previousMood, mood, confidence);
    
    return true;
  }
  
  /**
   * Get the current detected mood
   */
  getCurrentMood() {
    return {
      mood: this.state.currentMood,
      confidence: this.state.moodConfidence,
      timestamp: this.state.moodTimestamp
    };
  }
  
  /**
   * Get mood history
   */
  getMoodHistory() {
    return this.state.moodHistory;
  }
  
  /**
   * Get theme for a specific mood
   */
  getMoodTheme(mood) {
    return this.state.moodBasedThemes[mood] || this.state.moodBasedThemes.neutral;
  }
  
  /**
   * Get the current mood-based theme
   */
  getCurrentMoodTheme() {
    return this.getMoodTheme(this.state.currentMood);
  }
  
  /**
   * Get all mood-based themes
   */
  getAllMoodThemes() {
    return this.state.moodBasedThemes;
  }
  
  /**
   * Update a mood-based theme
   */
  updateMoodTheme(mood, themeData) {
    if (!this.state.moodBasedThemes[mood]) {
      return false;
    }
    
    this.state.moodBasedThemes[mood] = {
      ...this.state.moodBasedThemes[mood],
      ...themeData
    };
    
    // Notify listeners
    this._notifyListeners('moodThemeUpdated', {
      mood,
      theme: this.state.moodBasedThemes[mood]
    });
    
    return true;
  }
  
  /**
   * Reset a mood theme to default
   */
  resetMoodTheme(mood) {
    // In a real app, this would reset to the default theme
    // For the prototype, we'll just notify that it would happen
    console.log(`Reset mood theme for ${mood} to default`);
    
    // Notify listeners
    this._notifyListeners('moodThemeReset', { mood });
    
    return true;
  }
  
  /**
   * Update detection settings
   */
  updateSettings(settings) {
    // Store previous interval setting
    const previousInterval = this.state.detectionSettings.detectionInterval;
    
    // Update settings
    this.state.detectionSettings = {
      ...this.state.detectionSettings,
      ...settings
    };
    
    // If detection interval changed and detection is active,
    // restart the detection with the new interval
    if (this.state.detectionActive && 
        previousInterval !== this.state.detectionSettings.detectionInterval &&
        this.detectionInterval) {
      clearInterval(this.detectionInterval);
      this.detectionInterval = setInterval(() => {
        this._detectMood();
      }, this.state.detectionSettings.detectionInterval);
    }
    
    // Notify listeners
    this._notifyListeners('settingsUpdated', { 
      settings: this.state.detectionSettings 
    });
    
    return true;
  }
  
  /**
   * Enable or disable mood detection
   */
  setEnabled(enabled) {
    // If toggling from disabled to enabled, start detection
    if (!this.state.enabled && enabled) {
      this.state.enabled = true;
      this.startDetection();
    }
    // If toggling from enabled to disabled, stop detection
    else if (this.state.enabled && !enabled) {
      this.state.enabled = false;
      this.stopDetection();
    }
    
    // Notify listeners
    this._notifyListeners('enabledStateChanged', { enabled });
    
    return true;
  }
  
  /**
   * Get the current detection settings
   */
  getSettings() {
    return this.state.detectionSettings;
  }
  
  /**
   * Subscribe to mood detection events
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from mood detection events
   */
  unsubscribe(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  /**
   * Notify all listeners of an event
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in mood detection service listener:', error);
      }
    });
  }
  
  /**
   * Clean up the service
   */
  cleanup() {
    this.stopDetection();
    this.listeners = [];
  }
}

// Export as singleton
export const MoodDetectionService = new MoodDetectionServiceClass();