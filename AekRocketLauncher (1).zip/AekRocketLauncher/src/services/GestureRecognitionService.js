/**
 * Service for 3D gesture recognition and custom gesture management
 * Handles detection, training, and matching of gesture patterns
 */

class GestureRecognitionServiceClass {
  constructor() {
    // State
    this.state = {
      customGestures: {},
      gestureHistory: [],
      trainingMode: false,
      currentTrainingGesture: null,
      gestureDetectionEnabled: true,
      gestureSettings: {
        sensitivity: 0.7, // 0.0 to 1.0
        minConfidence: 0.6, // Minimum confidence for recognition
        motionThreshold: 0.1, // Minimum motion to register gesture point
        gestureTimeout: 1500, // Maximum time for a gesture (ms)
        useCamera: false // Whether to use camera for air gestures
      },
      lastRecognizedGesture: null,
      initialized: false
    };
    
    // Listeners
    this.listeners = [];
    
    // Active gesture tracking
    this.activeGesture = null;
    this.gestureTimer = null;
  }
  
  /**
   * Initialize the gesture recognition service
   */
  async initialize() {
    if (this.state.initialized) {
      return true;
    }
    
    try {
      // Load saved custom gestures
      await this._loadSavedGestures();
      
      this.state.initialized = true;
      console.log('GestureRecognitionService initialized');
      
      // Notify listeners that service is ready
      this._notifyListeners('serviceInitialized', { success: true });
      
      return true;
    } catch (error) {
      console.error('Failed to initialize GestureRecognitionService:', error);
      return false;
    }
  }
  
  /**
   * Load saved custom gestures from storage
   */
  async _loadSavedGestures() {
    // In a real app, this would load from device storage
    // For the prototype, we'll create some default gestures
    
    this.state.customGestures = {
      'Z': {
        name: 'Z Gesture',
        points: this._generateZGesture(),
        action: {
          type: 'launch_app',
          packageName: 'com.spotify.music',
          description: 'Launch Spotify'
        },
        created: new Date().toISOString()
      },
      'O': {
        name: 'Circle Gesture',
        points: this._generateCircleGesture(),
        action: {
          type: 'launch_app',
          packageName: 'com.whatsapp',
          description: 'Open WhatsApp'
        },
        created: new Date().toISOString()
      },
      'swipe_up': {
        name: 'Swipe Up',
        points: this._generateSwipeGesture('up'),
        action: {
          type: 'system_action',
          action: 'open_notifications',
          description: 'Open Notifications'
        },
        created: new Date().toISOString()
      },
      'swipe_down': {
        name: 'Swipe Down',
        points: this._generateSwipeGesture('down'),
        action: {
          type: 'system_action',
          action: 'close_notifications',
          description: 'Close Notifications'
        },
        created: new Date().toISOString()
      }
    };
  }
  
  /**
   * Generate a 'Z' gesture path
   */
  _generateZGesture() {
    // Simplified Z gesture path
    return [
      { x: 0.2, y: 0.3, t: 0 },
      { x: 0.4, y: 0.3, t: 100 },
      { x: 0.6, y: 0.3, t: 200 },
      { x: 0.8, y: 0.3, t: 300 },
      { x: 0.7, y: 0.4, t: 400 },
      { x: 0.6, y: 0.5, t: 500 },
      { x: 0.5, y: 0.6, t: 600 },
      { x: 0.4, y: 0.7, t: 700 },
      { x: 0.2, y: 0.7, t: 800 },
      { x: 0.4, y: 0.7, t: 900 },
      { x: 0.6, y: 0.7, t: 1000 },
      { x: 0.8, y: 0.7, t: 1100 }
    ];
  }
  
  /**
   * Generate a circle gesture path
   */
  _generateCircleGesture() {
    // Simplified circle gesture
    const points = [];
    const centerX = 0.5;
    const centerY = 0.5;
    const radius = 0.2;
    
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2;
      points.push({
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius,
        t: i * 100
      });
    }
    
    return points;
  }
  
  /**
   * Generate a swipe gesture path
   */
  _generateSwipeGesture(direction) {
    const points = [];
    
    switch (direction) {
      case 'up':
        for (let i = 0; i < 6; i++) {
          points.push({
            x: 0.5,
            y: 0.8 - (i * 0.1),
            t: i * 50
          });
        }
        break;
        
      case 'down':
        for (let i = 0; i < 6; i++) {
          points.push({
            x: 0.5,
            y: 0.3 + (i * 0.1),
            t: i * 50
          });
        }
        break;
        
      case 'left':
        for (let i = 0; i < 6; i++) {
          points.push({
            x: 0.8 - (i * 0.1),
            y: 0.5,
            t: i * 50
          });
        }
        break;
        
      case 'right':
        for (let i = 0; i < 6; i++) {
          points.push({
            x: 0.3 + (i * 0.1),
            y: 0.5,
            t: i * 50
          });
        }
        break;
    }
    
    return points;
  }
  
  /**
   * Begin tracking a new gesture
   */
  beginGesture(startPoint) {
    if (!this.state.gestureDetectionEnabled || this.activeGesture) {
      return false;
    }
    
    // Initialize a new active gesture
    this.activeGesture = {
      points: [startPoint],
      startTime: Date.now()
    };
    
    // Start the gesture timeout timer
    this.gestureTimer = setTimeout(() => {
      this._cancelGesture();
    }, this.state.gestureSettings.gestureTimeout);
    
    return true;
  }
  
  /**
   * Continue tracking the current gesture
   */
  updateGesture(point) {
    if (!this.activeGesture) {
      return false;
    }
    
    // Get the last point
    const lastPoint = this.activeGesture.points[this.activeGesture.points.length - 1];
    
    // Calculate distance from last point
    const distance = Math.sqrt(
      Math.pow(point.x - lastPoint.x, 2) + 
      Math.pow(point.y - lastPoint.y, 2)
    );
    
    // Only add the point if it's moved enough (reduces noise)
    if (distance >= this.state.gestureSettings.motionThreshold) {
      // Add timestamp to the point
      point.t = Date.now() - this.activeGesture.startTime;
      
      // Add the point to the active gesture
      this.activeGesture.points.push(point);
    }
    
    return true;
  }
  
  /**
   * End the current gesture and attempt recognition
   */
  endGesture() {
    if (!this.activeGesture) {
      return null;
    }
    
    // Clear the timeout timer
    if (this.gestureTimer) {
      clearTimeout(this.gestureTimer);
      this.gestureTimer = null;
    }
    
    // If we're in training mode, use this gesture for training
    if (this.state.trainingMode && this.state.currentTrainingGesture) {
      const result = this._addTrainingGesture(this.activeGesture.points);
      this.activeGesture = null;
      return result;
    }
    
    // If we have enough points, try to recognize the gesture
    if (this.activeGesture.points.length >= 3) {
      const recognizedGesture = this._recognizeGesture(this.activeGesture.points);
      
      // Add to gesture history
      this.state.gestureHistory.push({
        points: this.activeGesture.points,
        timestamp: new Date().toISOString(),
        recognized: recognizedGesture ? recognizedGesture.gestureId : null,
        confidence: recognizedGesture ? recognizedGesture.confidence : 0
      });
      
      // Keep history from growing too large
      if (this.state.gestureHistory.length > 20) {
        this.state.gestureHistory.shift();
      }
      
      // Clean up active gesture
      this.activeGesture = null;
      
      if (recognizedGesture) {
        this.state.lastRecognizedGesture = recognizedGesture;
        
        // Notify listeners
        this._notifyListeners('gestureRecognized', recognizedGesture);
        
        return recognizedGesture;
      }
    } else {
      // Not enough points for a valid gesture
      this.activeGesture = null;
    }
    
    return null;
  }
  
  /**
   * Cancel the current gesture tracking
   */
  _cancelGesture() {
    if (this.gestureTimer) {
      clearTimeout(this.gestureTimer);
      this.gestureTimer = null;
    }
    
    this.activeGesture = null;
    
    // Notify listeners that gesture was canceled
    this._notifyListeners('gestureCanceled', { 
      reason: 'timeout',
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * Recognize a gesture by comparing to stored gestures
   */
  _recognizeGesture(points) {
    if (!points || points.length < 3) {
      return null;
    }
    
    let bestMatch = null;
    let highestConfidence = this.state.gestureSettings.minConfidence;
    
    // Compare the input gesture against each stored gesture
    for (const [gestureId, gesture] of Object.entries(this.state.customGestures)) {
      const confidence = this._calculateGestureSimilarity(points, gesture.points);
      
      if (confidence > highestConfidence) {
        highestConfidence = confidence;
        bestMatch = {
          gestureId,
          gestureName: gesture.name,
          confidence,
          action: gesture.action
        };
      }
    }
    
    return bestMatch;
  }
  
  /**
   * Calculate similarity between two gestures (0.0 to 1.0)
   */
  _calculateGestureSimilarity(gestureA, gestureB) {
    // This is a simplified implementation
    // A real implementation would use more sophisticated algorithms (e.g., $1 Recognizer or DTW)
    
    // Normalize both gestures
    const normalizedA = this._normalizeGesture(gestureA);
    const normalizedB = this._normalizeGesture(gestureB);
    
    // Resample to ensure both have the same number of points
    const resampledA = this._resampleGesture(normalizedA, 32);
    const resampledB = this._resampleGesture(normalizedB, 32);
    
    // Calculate path distance
    let totalDistance = 0;
    
    for (let i = 0; i < resampledA.length; i++) {
      const pointA = resampledA[i];
      const pointB = resampledB[i];
      
      // Euclidean distance between corresponding points
      const distance = Math.sqrt(
        Math.pow(pointA.x - pointB.x, 2) + 
        Math.pow(pointA.y - pointB.y, 2)
      );
      
      totalDistance += distance;
    }
    
    // Average distance
    const avgDistance = totalDistance / resampledA.length;
    
    // Convert to a similarity score (0 to 1)
    // Lower distance = higher similarity
    const similarity = Math.max(0, 1 - (avgDistance * 2));
    
    return similarity;
  }
  
  /**
   * Normalize a gesture to be centered and scaled
   */
  _normalizeGesture(points) {
    if (!points || points.length === 0) {
      return [];
    }
    
    // Find bounding box
    let minX = 1, minY = 1, maxX = 0, maxY = 0;
    
    for (const point of points) {
      minX = Math.min(minX, point.x);
      minY = Math.min(minY, point.y);
      maxX = Math.max(maxX, point.x);
      maxY = Math.max(maxY, point.y);
    }
    
    // Calculate dimensions
    const width = maxX - minX;
    const height = maxY - minY;
    const scale = Math.max(width, height);
    
    if (scale === 0) {
      return points;
    }
    
    // Normalize all points
    return points.map(point => ({
      x: (point.x - minX) / scale,
      y: (point.y - minY) / scale,
      t: point.t
    }));
  }
  
  /**
   * Resample a gesture to have a specific number of points
   */
  _resampleGesture(points, numPoints) {
    if (!points || points.length < 2 || numPoints <= 0) {
      return points;
    }
    
    // Calculate path length
    let pathLength = 0;
    
    for (let i = 1; i < points.length; i++) {
      pathLength += Math.sqrt(
        Math.pow(points[i].x - points[i-1].x, 2) + 
        Math.pow(points[i].y - points[i-1].y, 2)
      );
    }
    
    // Calculate interval
    const interval = pathLength / (numPoints - 1);
    
    const resampled = [points[0]];
    let accumulatedDistance = 0;
    
    for (let i = 1; i < points.length && resampled.length < numPoints; i++) {
      const prevPoint = points[i-1];
      const currPoint = points[i];
      
      const segmentDistance = Math.sqrt(
        Math.pow(currPoint.x - prevPoint.x, 2) + 
        Math.pow(currPoint.y - prevPoint.y, 2)
      );
      
      if (accumulatedDistance + segmentDistance >= interval) {
        while (accumulatedDistance + segmentDistance >= interval && resampled.length < numPoints) {
          const remainingDistance = interval - accumulatedDistance;
          const ratio = remainingDistance / segmentDistance;
          
          // Interpolate a new point
          const newPoint = {
            x: prevPoint.x + ratio * (currPoint.x - prevPoint.x),
            y: prevPoint.y + ratio * (currPoint.y - prevPoint.y),
            t: prevPoint.t + ratio * (currPoint.t - prevPoint.t)
          };
          
          resampled.push(newPoint);
          
          // Update for next iteration
          accumulatedDistance = 0;
        }
      } else {
        accumulatedDistance += segmentDistance;
      }
    }
    
    // Ensure we have exactly numPoints
    while (resampled.length < numPoints) {
      resampled.push(points[points.length - 1]);
    }
    
    return resampled;
  }
  
  /**
   * Begin training a new custom gesture
   */
  beginTrainingMode(gestureName, action) {
    this.state.trainingMode = true;
    this.state.currentTrainingGesture = {
      name: gestureName,
      action: action,
      trainingSamples: []
    };
    
    // Notify listeners
    this._notifyListeners('trainingStarted', { gestureName });
    
    return true;
  }
  
  /**
   * Add a training sample during gesture training
   */
  _addTrainingGesture(points) {
    if (!this.state.trainingMode || !this.state.currentTrainingGesture) {
      return false;
    }
    
    // Add training sample
    this.state.currentTrainingGesture.trainingSamples.push(points);
    
    // Notify listeners
    this._notifyListeners('trainingSampleAdded', {
      gestureName: this.state.currentTrainingGesture.name,
      samplesCount: this.state.currentTrainingGesture.trainingSamples.length
    });
    
    return true;
  }
  
  /**
   * Finish training and save the new gesture
   */
  finishTraining() {
    if (!this.state.trainingMode || !this.state.currentTrainingGesture) {
      return false;
    }
    
    const { name, action, trainingSamples } = this.state.currentTrainingGesture;
    
    if (trainingSamples.length === 0) {
      // Notify listeners of failure
      this._notifyListeners('trainingFinished', { 
        success: false,
        gestureName: name,
        reason: 'No training samples provided'
      });
      
      this.state.trainingMode = false;
      this.state.currentTrainingGesture = null;
      
      return false;
    }
    
    // Generate a gesture ID
    const gestureId = name.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    
    // Average the training samples (simple implementation)
    // A real implementation would use more sophisticated techniques
    const averagedPoints = this._averageTrainingSamples(trainingSamples);
    
    // Save the new gesture
    this.state.customGestures[gestureId] = {
      name,
      points: averagedPoints,
      action,
      created: new Date().toISOString()
    };
    
    // Reset training mode
    this.state.trainingMode = false;
    this.state.currentTrainingGesture = null;
    
    // Notify listeners
    this._notifyListeners('trainingFinished', { 
      success: true,
      gestureName: name,
      gestureId
    });
    
    return true;
  }
  
  /**
   * Average multiple training samples into a single gesture
   */
  _averageTrainingSamples(samples) {
    if (!samples || samples.length === 0) {
      return [];
    }
    
    // Normalize and resample all samples
    const normalizedSamples = samples.map(sample => {
      const normalized = this._normalizeGesture(sample);
      return this._resampleGesture(normalized, 32);
    });
    
    // Average corresponding points
    const averagedPoints = [];
    
    for (let i = 0; i < normalizedSamples[0].length; i++) {
      let sumX = 0;
      let sumY = 0;
      let sumT = 0;
      
      for (const sample of normalizedSamples) {
        sumX += sample[i].x;
        sumY += sample[i].y;
        sumT += sample[i].t;
      }
      
      averagedPoints.push({
        x: sumX / normalizedSamples.length,
        y: sumY / normalizedSamples.length,
        t: sumT / normalizedSamples.length
      });
    }
    
    return averagedPoints;
  }
  
  /**
   * Delete a custom gesture
   */
  deleteGesture(gestureId) {
    if (!this.state.customGestures[gestureId]) {
      return false;
    }
    
    const gestureName = this.state.customGestures[gestureId].name;
    
    // Delete the gesture
    delete this.state.customGestures[gestureId];
    
    // Notify listeners
    this._notifyListeners('gestureDeleted', { gestureId, gestureName });
    
    return true;
  }
  
  /**
   * Update settings for gesture recognition
   */
  updateSettings(settings) {
    this.state.gestureSettings = {
      ...this.state.gestureSettings,
      ...settings
    };
    
    // Notify listeners
    this._notifyListeners('settingsUpdated', { settings: this.state.gestureSettings });
    
    return true;
  }
  
  /**
   * Enable or disable gesture detection
   */
  setGestureDetectionEnabled(enabled) {
    this.state.gestureDetectionEnabled = enabled;
    
    // Notify listeners
    this._notifyListeners('detectionStateChanged', { enabled });
    
    return true;
  }
  
  /**
   * Get all custom gestures
   */
  getAllGestures() {
    return this.state.customGestures;
  }
  
  /**
   * Get a specific gesture by ID
   */
  getGesture(gestureId) {
    return this.state.customGestures[gestureId] || null;
  }
  
  /**
   * Get the last recognized gesture
   */
  getLastRecognizedGesture() {
    return this.state.lastRecognizedGesture;
  }
  
  /**
   * Get gesture detection settings
   */
  getSettings() {
    return this.state.gestureSettings;
  }
  
  /**
   * Subscribe to gesture events
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from gesture events
   */
  unsubscribe(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  /**
   * Notify all listeners of an event
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in gesture service listener:', error);
      }
    });
  }
}

// Export as singleton
export const GestureRecognitionService = new GestureRecognitionServiceClass();