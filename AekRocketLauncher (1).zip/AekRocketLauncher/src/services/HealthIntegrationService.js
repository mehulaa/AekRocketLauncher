/**
 * Service for Health Integration
 * Connects with fitness apps and devices for health tracking on the launcher
 */

class HealthIntegrationServiceClass {
  constructor() {
    // State
    this.state = {
      enabled: true,
      connectedApps: [],
      healthData: {
        steps: [],
        sleep: [],
        heartRate: [],
        workouts: [],
        calories: [],
        water: []
      },
      goals: {
        steps: 10000,
        sleep: 8,
        calories: 2500,
        water: 8
      },
      permissions: {
        steps: false,
        sleep: false,
        heartRate: false,
        workouts: false,
        calories: false,
        water: false
      },
      healthWidgetConfig: {
        showSteps: true,
        showSleep: true,
        showHeartRate: true,
        showCalories: true,
        showWater: true,
        layout: 'grid', // 'grid', 'list', 'compact'
        accentColor: '#4CAF50',
        showTrendsChart: true,
        timeRange: 'week' // 'day', 'week', 'month'
      },
      lastSync: null,
      initialized: false
    };
    
    // Listeners
    this.listeners = [];
    
    // Sync interval
    this.syncInterval = null;
  }
  
  /**
   * Initialize the health integration service
   */
  async initialize() {
    if (this.state.initialized) {
      return true;
    }
    
    try {
      // Load saved settings
      await this._loadSettings();
      
      // Request permissions
      await this._requestPermissions();
      
      // Discover connected health apps and devices
      await this._discoverHealthApps();
      
      // Load historical health data
      await this._loadHealthData();
      
      this.state.initialized = true;
      console.log('HealthIntegrationService initialized');
      
      // Start periodic sync if enabled
      if (this.state.enabled && this.state.connectedApps.length > 0) {
        this._startSync();
      }
      
      // Notify listeners
      this._notifyListeners('serviceInitialized', {
        success: true,
        connectedApps: this.state.connectedApps.length
      });
      
      return true;
    } catch (error) {
      console.error('Failed to initialize HealthIntegrationService:', error);
      return false;
    }
  }
  
  /**
   * Load saved settings from storage
   */
  async _loadSettings() {
    // In a real app, this would load from device storage
    console.log('HealthIntegrationService: Loading settings...');
  }
  
  /**
   * Request permissions for health data access
   */
  async _requestPermissions() {
    // In a real app, this would request actual permissions from the OS
    // For the prototype, we'll simulate permission grants
    
    console.log('HealthIntegrationService: Requesting permissions...');
    
    // Simulate permissions being granted (80% chance)
    const permissionTypes = ['steps', 'sleep', 'heartRate', 'workouts', 'calories', 'water'];
    
    permissionTypes.forEach(type => {
      this.state.permissions[type] = Math.random() < 0.8;
    });
    
    return this.state.permissions;
  }
  
  /**
   * Discover health apps and devices
   */
  async _discoverHealthApps() {
    // In a real app, this would discover actual health apps installed on the device
    // For the prototype, we'll simulate discovering some common health apps
    
    console.log('HealthIntegrationService: Discovering health apps...');
    
    // Define some common health apps
    const potentialApps = [
      {
        id: 'googlefit',
        name: 'Google Fit',
        icon: 'googlefit',
        capabilities: ['steps', 'sleep', 'heartRate', 'workouts', 'calories'],
        isInstalled: Math.random() < 0.7
      },
      {
        id: 'samsung_health',
        name: 'Samsung Health',
        icon: 'samsunghealth',
        capabilities: ['steps', 'sleep', 'heartRate', 'workouts', 'calories', 'water'],
        isInstalled: Math.random() < 0.5
      },
      {
        id: 'mi_fit',
        name: 'Mi Fit',
        icon: 'mifit',
        capabilities: ['steps', 'sleep', 'heartRate'],
        isInstalled: Math.random() < 0.4
      },
      {
        id: 'fitbit',
        name: 'Fitbit',
        icon: 'fitbit',
        capabilities: ['steps', 'sleep', 'heartRate', 'workouts', 'calories'],
        isInstalled: Math.random() < 0.3
      },
      {
        id: 'strava',
        name: 'Strava',
        icon: 'strava',
        capabilities: ['workouts'],
        isInstalled: Math.random() < 0.3
      },
      {
        id: 'water_reminder',
        name: 'Water Reminder',
        icon: 'water',
        capabilities: ['water'],
        isInstalled: Math.random() < 0.4
      }
    ];
    
    // Filter to installed apps only
    this.state.connectedApps = potentialApps.filter(app => app.isInstalled);
    
    return this.state.connectedApps;
  }
  
  /**
   * Load health data from connected apps
   */
  async _loadHealthData() {
    if (this.state.connectedApps.length === 0) {
      return;
    }
    
    console.log('HealthIntegrationService: Loading health data...');
    
    // In a real app, this would fetch actual health data from connected apps
    // For the prototype, we'll generate some realistic example data
    
    // Get date for 30 days ago
    const now = new Date();
    const thirtyDaysAgo = new Date(now);
    thirtyDaysAgo.setDate(now.getDate() - 30);
    
    // Generate daily data for the last 30 days
    const healthData = {
      steps: [],
      sleep: [],
      heartRate: [],
      workouts: [],
      calories: [],
      water: []
    };
    
    // Only generate data for types we have permissions for
    for (let i = 0; i < 30; i++) {
      const date = new Date(thirtyDaysAgo);
      date.setDate(thirtyDaysAgo.getDate() + i);
      const dateStr = date.toISOString().split('T')[0];
      
      // Steps data (if we have permission)
      if (this.state.permissions.steps) {
        // Generate realistic step count (more on weekdays, less on weekends)
        const isWeekend = date.getDay() === 0 || date.getDay() === 6;
        const baseSteps = isWeekend ? 5000 : 8000;
        const variance = isWeekend ? 3000 : 4000;
        const steps = Math.max(0, Math.floor(baseSteps + (Math.random() * variance - variance/2)));
        
        healthData.steps.push({
          date: dateStr,
          value: steps,
          goal: this.state.goals.steps,
          source: this._getRandomSource('steps')
        });
      }
      
      // Sleep data (if we have permission)
      if (this.state.permissions.sleep) {
        // Generate realistic sleep duration (hours)
        const baseSleep = 7;
        const variance = 2;
        const sleep = Math.max(0, parseFloat((baseSleep + (Math.random() * variance - variance/2)).toFixed(1)));
        
        healthData.sleep.push({
          date: dateStr,
          value: sleep,
          goal: this.state.goals.sleep,
          stages: {
            deep: parseFloat((sleep * 0.2).toFixed(1)),
            light: parseFloat((sleep * 0.5).toFixed(1)),
            rem: parseFloat((sleep * 0.25).toFixed(1)),
            awake: parseFloat((sleep * 0.05).toFixed(1))
          },
          source: this._getRandomSource('sleep')
        });
      }
      
      // Heart rate data (if we have permission)
      if (this.state.permissions.heartRate) {
        // Generate realistic heart rate data
        const baseHR = 70;
        const variance = 15;
        
        // Daily average
        const avgHR = Math.floor(baseHR + (Math.random() * variance - variance/2));
        
        // Daily min/max
        const minHR = Math.max(45, avgHR - Math.floor(Math.random() * 15) - 10);
        const maxHR = Math.min(180, avgHR + Math.floor(Math.random() * 30) + 20);
        
        healthData.heartRate.push({
          date: dateStr,
          average: avgHR,
          min: minHR,
          max: maxHR,
          source: this._getRandomSource('heartRate')
        });
      }
      
      // Calories data (if we have permission)
      if (this.state.permissions.calories) {
        // Generate realistic calorie burn data (correlated with steps)
        const baseCalories = 1800;
        const stepBasedCalories = this.state.permissions.steps ? 
          healthData.steps[healthData.steps.length - 1].value * 0.05 : 
          Math.random() * 500;
        
        const calories = Math.floor(baseCalories + stepBasedCalories);
        
        healthData.calories.push({
          date: dateStr,
          value: calories,
          goal: this.state.goals.calories,
          source: this._getRandomSource('calories')
        });
      }
      
      // Water intake data (if we have permission)
      if (this.state.permissions.water) {
        // Generate realistic water intake (glasses)
        const baseWater = 5;
        const variance = 4;
        const water = Math.max(0, Math.floor(baseWater + (Math.random() * variance - variance/2)));
        
        healthData.water.push({
          date: dateStr,
          value: water,
          goal: this.state.goals.water,
          source: this._getRandomSource('water')
        });
      }
    }
    
    // Generate some workout data (if we have permission)
    if (this.state.permissions.workouts) {
      // Types of workouts
      const workoutTypes = ['walking', 'running', 'cycling', 'swimming', 'gym', 'yoga', 'hiking'];
      
      // Generate 5-12 workouts over the 30 day period
      const numWorkouts = Math.floor(Math.random() * 8) + 5;
      
      for (let i = 0; i < numWorkouts; i++) {
        // Random date in the last 30 days
        const workoutDate = new Date(thirtyDaysAgo);
        workoutDate.setDate(thirtyDaysAgo.getDate() + Math.floor(Math.random() * 30));
        const dateStr = workoutDate.toISOString().split('T')[0];
        
        // Random workout type
        const workoutType = workoutTypes[Math.floor(Math.random() * workoutTypes.length)];
        
        // Duration in minutes
        let duration;
        switch (workoutType) {
          case 'walking':
            duration = 20 + Math.floor(Math.random() * 40);
            break;
          case 'running':
            duration = 15 + Math.floor(Math.random() * 30);
            break;
          case 'cycling':
            duration = 30 + Math.floor(Math.random() * 60);
            break;
          case 'swimming':
            duration = 20 + Math.floor(Math.random() * 25);
            break;
          case 'gym':
            duration = 45 + Math.floor(Math.random() * 30);
            break;
          case 'yoga':
            duration = 30 + Math.floor(Math.random() * 30);
            break;
          case 'hiking':
            duration = 60 + Math.floor(Math.random() * 120);
            break;
          default:
            duration = 30 + Math.floor(Math.random() * 30);
        }
        
        // Distance in km (for applicable workout types)
        let distance = null;
        if (['walking', 'running', 'cycling', 'hiking'].includes(workoutType)) {
          let speed;
          switch (workoutType) {
            case 'walking':
              speed = 4 + Math.random() * 2; // 4-6 km/h
              break;
            case 'running':
              speed = 8 + Math.random() * 4; // 8-12 km/h
              break;
            case 'cycling':
              speed = 15 + Math.random() * 10; // 15-25 km/h
              break;
            case 'hiking':
              speed = 3 + Math.random() * 2; // 3-5 km/h
              break;
          }
          distance = parseFloat(((speed * duration / 60)).toFixed(2));
        }
        
        // Calories burned
        let caloriesPerMinute;
        switch (workoutType) {
          case 'walking':
            caloriesPerMinute = 4 + Math.random() * 2;
            break;
          case 'running':
            caloriesPerMinute = 8 + Math.random() * 4;
            break;
          case 'cycling':
            caloriesPerMinute = 6 + Math.random() * 4;
            break;
          case 'swimming':
            caloriesPerMinute = 7 + Math.random() * 3;
            break;
          case 'gym':
            caloriesPerMinute = 6 + Math.random() * 4;
            break;
          case 'yoga':
            caloriesPerMinute = 3 + Math.random() * 2;
            break;
          case 'hiking':
            caloriesPerMinute = 5 + Math.random() * 3;
            break;
          default:
            caloriesPerMinute = 5 + Math.random() * 3;
        }
        const calories = Math.floor(caloriesPerMinute * duration);
        
        // Generate random start time (between 6am and 8pm)
        const hour = 6 + Math.floor(Math.random() * 14);
        const minute = Math.floor(Math.random() * 60);
        workoutDate.setHours(hour, minute, 0, 0);
        
        healthData.workouts.push({
          id: `workout_${i}`,
          type: workoutType,
          date: dateStr,
          startTime: workoutDate.toISOString(),
          duration: duration,
          distance: distance,
          calories: calories,
          heartRate: this.state.permissions.heartRate ? {
            average: 110 + Math.floor(Math.random() * 40),
            max: 140 + Math.floor(Math.random() * 40)
          } : null,
          source: this._getRandomSource('workouts')
        });
      }
      
      // Sort workouts by date
      healthData.workouts.sort((a, b) => new Date(a.startTime) - new Date(b.startTime));
    }
    
    // Save the generated health data
    this.state.healthData = healthData;
    
    // Update last sync timestamp
    this.state.lastSync = new Date().toISOString();
    
    return healthData;
  }
  
  /**
   * Helper to get a random source app for a specific data type
   */
  _getRandomSource(dataType) {
    // Filter apps that support this data type
    const supportingApps = this.state.connectedApps.filter(
      app => app.capabilities.includes(dataType)
    );
    
    if (supportingApps.length === 0) {
      return 'unknown';
    }
    
    // Randomly select one of the supporting apps
    const randomApp = supportingApps[Math.floor(Math.random() * supportingApps.length)];
    return randomApp.id;
  }
  
  /**
   * Start periodic sync with health apps
   */
  _startSync() {
    // Clear any existing interval
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
    }
    
    // Sync every 30 minutes
    this.syncInterval = setInterval(() => {
      this._syncHealthData();
    }, 30 * 60 * 1000);
    
    // Do an immediate sync
    this._syncHealthData();
  }
  
  /**
   * Sync health data from connected apps
   */
  async _syncHealthData() {
    if (!this.state.enabled || this.state.connectedApps.length === 0) {
      return;
    }
    
    console.log('HealthIntegrationService: Syncing health data...');
    
    // In a real app, this would fetch latest health data from connected apps
    // For the prototype, we'll update today's data
    
    const today = new Date().toISOString().split('T')[0];
    
    // Update data for today
    if (this.state.permissions.steps) {
      // Find today's entry or create new one
      const todayIndex = this.state.healthData.steps.findIndex(entry => entry.date === today);
      
      // Generate new steps value (either update existing or create new)
      const baseSteps = 4000; // Base steps by this time of day
      const variance = 2000;
      const steps = Math.max(0, Math.floor(baseSteps + (Math.random() * variance - variance/2)));
      
      if (todayIndex >= 0) {
        // Update existing entry
        this.state.healthData.steps[todayIndex].value = steps;
      } else {
        // Create new entry
        this.state.healthData.steps.push({
          date: today,
          value: steps,
          goal: this.state.goals.steps,
          source: this._getRandomSource('steps')
        });
      }
    }
    
    // Similar updates for other data types
    // ... (skipping for brevity, but similar logic to the steps update)
    
    // Update last sync timestamp
    this.state.lastSync = new Date().toISOString();
    
    // Notify listeners
    this._notifyListeners('healthDataSynced', {
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Get health data summary for a specific time range
   */
  getHealthSummary(timeRange = 'week') {
    // Make sure we have health data
    if (!this.state.healthData.steps.length) {
      return {
        success: false,
        error: 'No health data available'
      };
    }
    
    // Calculate date range
    const now = new Date();
    let startDate;
    
    switch (timeRange) {
      case 'day':
        startDate = new Date(now);
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'week':
        startDate = new Date(now);
        startDate.setDate(now.getDate() - 7);
        break;
      case 'month':
        startDate = new Date(now);
        startDate.setDate(now.getDate() - 30);
        break;
      default:
        startDate = new Date(now);
        startDate.setDate(now.getDate() - 7);
    }
    
    const startDateStr = startDate.toISOString().split('T')[0];
    
    // Prepare summary object
    const summary = {
      timeRange,
      period: {
        start: startDateStr,
        end: now.toISOString().split('T')[0]
      },
      steps: {
        available: this.state.permissions.steps,
        total: 0,
        average: 0,
        best: 0,
        goalProgress: 0,
        trend: 0,
        data: []
      },
      sleep: {
        available: this.state.permissions.sleep,
        total: 0,
        average: 0,
        best: 0,
        goalProgress: 0,
        trend: 0,
        data: []
      },
      heartRate: {
        available: this.state.permissions.heartRate,
        averageDaily: 0,
        min: 0,
        max: 0,
        data: []
      },
      calories: {
        available: this.state.permissions.calories,
        total: 0,
        average: 0,
        goalProgress: 0,
        data: []
      },
      water: {
        available: this.state.permissions.water,
        total: 0,
        average: 0,
        goalProgress: 0,
        data: []
      },
      workouts: {
        available: this.state.permissions.workouts,
        count: 0,
        totalDuration: 0,
        totalCalories: 0,
        totalDistance: 0,
        favorite: null,
        recent: []
      }
    };
    
    // Filter data for the time range
    if (this.state.permissions.steps) {
      const filteredSteps = this.state.healthData.steps.filter(
        entry => entry.date >= startDateStr
      );
      
      if (filteredSteps.length > 0) {
        summary.steps.data = filteredSteps;
        summary.steps.total = filteredSteps.reduce((sum, entry) => sum + entry.value, 0);
        summary.steps.average = Math.round(summary.steps.total / filteredSteps.length);
        summary.steps.best = Math.max(...filteredSteps.map(entry => entry.value));
        summary.steps.goalProgress = Math.min(100, Math.round((summary.steps.average / this.state.goals.steps) * 100));
        
        // Calculate trend (comparison with previous period)
        if (timeRange !== 'day' && this.state.healthData.steps.length > filteredSteps.length * 2) {
          const prevPeriodStart = new Date(startDate);
          prevPeriodStart.setDate(startDate.getDate() - filteredSteps.length);
          const prevPeriodStartStr = prevPeriodStart.toISOString().split('T')[0];
          
          const prevPeriod = this.state.healthData.steps.filter(
            entry => entry.date >= prevPeriodStartStr && entry.date < startDateStr
          );
          
          if (prevPeriod.length > 0) {
            const prevAvg = prevPeriod.reduce((sum, entry) => sum + entry.value, 0) / prevPeriod.length;
            summary.steps.trend = Math.round(((summary.steps.average - prevAvg) / prevAvg) * 100);
          }
        }
      }
    }
    
    // Similar processing for sleep data
    if (this.state.permissions.sleep) {
      const filteredSleep = this.state.healthData.sleep.filter(
        entry => entry.date >= startDateStr
      );
      
      if (filteredSleep.length > 0) {
        summary.sleep.data = filteredSleep;
        summary.sleep.total = filteredSleep.reduce((sum, entry) => sum + entry.value, 0);
        summary.sleep.average = parseFloat((summary.sleep.total / filteredSleep.length).toFixed(1));
        summary.sleep.best = Math.max(...filteredSleep.map(entry => entry.value));
        summary.sleep.goalProgress = Math.min(100, Math.round((summary.sleep.average / this.state.goals.sleep) * 100));
        
        // Calculate trend (similar to steps)
        // (Code omitted for brevity but follows same pattern)
      }
    }
    
    // Process heart rate data
    if (this.state.permissions.heartRate) {
      const filteredHR = this.state.healthData.heartRate.filter(
        entry => entry.date >= startDateStr
      );
      
      if (filteredHR.length > 0) {
        summary.heartRate.data = filteredHR;
        
        const averages = filteredHR.map(entry => entry.average);
        summary.heartRate.averageDaily = Math.round(averages.reduce((sum, val) => sum + val, 0) / averages.length);
        
        const allMins = filteredHR.map(entry => entry.min);
        summary.heartRate.min = Math.min(...allMins);
        
        const allMaxes = filteredHR.map(entry => entry.max);
        summary.heartRate.max = Math.max(...allMaxes);
      }
    }
    
    // Process calorie data
    if (this.state.permissions.calories) {
      const filteredCalories = this.state.healthData.calories.filter(
        entry => entry.date >= startDateStr
      );
      
      if (filteredCalories.length > 0) {
        summary.calories.data = filteredCalories;
        summary.calories.total = filteredCalories.reduce((sum, entry) => sum + entry.value, 0);
        summary.calories.average = Math.round(summary.calories.total / filteredCalories.length);
        summary.calories.goalProgress = Math.min(100, Math.round((summary.calories.average / this.state.goals.calories) * 100));
      }
    }
    
    // Process water data
    if (this.state.permissions.water) {
      const filteredWater = this.state.healthData.water.filter(
        entry => entry.date >= startDateStr
      );
      
      if (filteredWater.length > 0) {
        summary.water.data = filteredWater;
        summary.water.total = filteredWater.reduce((sum, entry) => sum + entry.value, 0);
        summary.water.average = parseFloat((summary.water.total / filteredWater.length).toFixed(1));
        summary.water.goalProgress = Math.min(100, Math.round((summary.water.average / this.state.goals.water) * 100));
      }
    }
    
    // Process workout data
    if (this.state.permissions.workouts) {
      const filteredWorkouts = this.state.healthData.workouts.filter(
        workout => workout.date >= startDateStr
      );
      
      if (filteredWorkouts.length > 0) {
        summary.workouts.count = filteredWorkouts.length;
        summary.workouts.totalDuration = filteredWorkouts.reduce((sum, workout) => sum + workout.duration, 0);
        summary.workouts.totalCalories = filteredWorkouts.reduce((sum, workout) => sum + workout.calories, 0);
        
        // Calculate total distance for workouts with distance
        const workoutsWithDistance = filteredWorkouts.filter(workout => workout.distance !== null);
        if (workoutsWithDistance.length > 0) {
          summary.workouts.totalDistance = parseFloat(workoutsWithDistance.reduce(
            (sum, workout) => sum + workout.distance, 0
          ).toFixed(2));
        }
        
        // Find favorite workout type (most frequent)
        const typeCount = {};
        filteredWorkouts.forEach(workout => {
          typeCount[workout.type] = (typeCount[workout.type] || 0) + 1;
        });
        
        let favoriteType = null;
        let maxCount = 0;
        for (const [type, count] of Object.entries(typeCount)) {
          if (count > maxCount) {
            maxCount = count;
            favoriteType = type;
          }
        }
        
        if (favoriteType) {
          summary.workouts.favorite = {
            type: favoriteType,
            count: maxCount
          };
        }
        
        // Get 3 most recent workouts
        summary.workouts.recent = filteredWorkouts
          .sort((a, b) => new Date(b.startTime) - new Date(a.startTime))
          .slice(0, 3);
      }
    }
    
    return {
      success: true,
      summary
    };
  }
  
  /**
   * Update health goal
   */
  updateGoal(goalType, value) {
    if (!this.state.goals.hasOwnProperty(goalType)) {
      return {
        success: false,
        error: `Invalid goal type: ${goalType}`
      };
    }
    
    this.state.goals[goalType] = value;
    
    // Notify listeners
    this._notifyListeners('goalUpdated', {
      goalType,
      value,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true,
      goals: this.state.goals
    };
  }
  
  /**
   * Update health widget configuration
   */
  updateWidgetConfig(config) {
    this.state.healthWidgetConfig = {
      ...this.state.healthWidgetConfig,
      ...config
    };
    
    // Notify listeners
    this._notifyListeners('widgetConfigUpdated', {
      config: this.state.healthWidgetConfig,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true,
      config: this.state.healthWidgetConfig
    };
  }
  
  /**
   * Connect to a health app
   */
  async connectApp(appId) {
    // In a real app, this would initiate an actual connection
    // For the prototype, we'll simulate a connection
    
    // Check if already connected
    if (this.state.connectedApps.some(app => app.id === appId)) {
      return {
        success: false,
        error: 'App is already connected'
      };
    }
    
    console.log(`Connecting to health app: ${appId}`);
    
    try {
      // Simulate connection process
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Add to connected apps (with 90% success rate)
      if (Math.random() < 0.9) {
        const appData = {
          id: appId,
          name: appId.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' '),
          icon: appId.toLowerCase(),
          capabilities: ['steps', 'sleep'], // Basic capabilities
          connectedAt: new Date().toISOString()
        };
        
        this.state.connectedApps.push(appData);
        
        // Reload health data
        await this._loadHealthData();
        
        // Notify listeners
        this._notifyListeners('appConnected', {
          app: appData,
          timestamp: new Date().toISOString()
        });
        
        return {
          success: true,
          app: appData
        };
      } else {
        throw new Error('Connection failed');
      }
    } catch (error) {
      console.error(`Error connecting to health app ${appId}:`, error);
      return {
        success: false,
        error: 'Failed to connect to health app'
      };
    }
  }
  
  /**
   * Disconnect from a health app
   */
  disconnectApp(appId) {
    const index = this.state.connectedApps.findIndex(app => app.id === appId);
    
    if (index === -1) {
      return {
        success: false,
        error: 'App is not connected'
      };
    }
    
    // Get app data before removing
    const app = this.state.connectedApps[index];
    
    // Remove from connected apps
    this.state.connectedApps.splice(index, 1);
    
    // Notify listeners
    this._notifyListeners('appDisconnected', {
      appId,
      appName: app.name,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true
    };
  }
  
  /**
   * Get detailed data for a specific health metric
   */
  getDetailedData(dataType, timeRange = 'week') {
    if (!this.state.permissions[dataType]) {
      return {
        success: false,
        error: `No permission for ${dataType} data`
      };
    }
    
    if (!this.state.healthData[dataType] || this.state.healthData[dataType].length === 0) {
      return {
        success: false,
        error: `No ${dataType} data available`
      };
    }
    
    // Calculate date range
    const now = new Date();
    let startDate;
    
    switch (timeRange) {
      case 'day':
        startDate = new Date(now);
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'week':
        startDate = new Date(now);
        startDate.setDate(now.getDate() - 7);
        break;
      case 'month':
        startDate = new Date(now);
        startDate.setDate(now.getDate() - 30);
        break;
      default:
        startDate = new Date(now);
        startDate.setDate(now.getDate() - 7);
    }
    
    const startDateStr = startDate.toISOString().split('T')[0];
    
    // Filter data for the time range
    const filteredData = this.state.healthData[dataType].filter(
      entry => entry.date >= startDateStr
    );
    
    // Process data based on type
    let processedData;
    
    switch (dataType) {
      case 'steps':
        processedData = {
          daily: filteredData,
          total: filteredData.reduce((sum, entry) => sum + entry.value, 0),
          average: Math.round(
            filteredData.reduce((sum, entry) => sum + entry.value, 0) / filteredData.length
          ),
          goal: this.state.goals.steps,
          goalProgress: filteredData.map(entry => ({
            date: entry.date,
            percentage: Math.min(100, Math.round((entry.value / this.state.goals.steps) * 100))
          }))
        };
        break;
        
      case 'sleep':
        processedData = {
          daily: filteredData,
          total: filteredData.reduce((sum, entry) => sum + entry.value, 0),
          average: parseFloat(
            (filteredData.reduce((sum, entry) => sum + entry.value, 0) / filteredData.length).toFixed(1)
          ),
          goal: this.state.goals.sleep,
          stages: {
            deep: parseFloat(
              (filteredData.reduce((sum, entry) => sum + (entry.stages?.deep || 0), 0) / filteredData.length).toFixed(1)
            ),
            light: parseFloat(
              (filteredData.reduce((sum, entry) => sum + (entry.stages?.light || 0), 0) / filteredData.length).toFixed(1)
            ),
            rem: parseFloat(
              (filteredData.reduce((sum, entry) => sum + (entry.stages?.rem || 0), 0) / filteredData.length).toFixed(1)
            ),
            awake: parseFloat(
              (filteredData.reduce((sum, entry) => sum + (entry.stages?.awake || 0), 0) / filteredData.length).toFixed(1)
            )
          },
          goalProgress: filteredData.map(entry => ({
            date: entry.date,
            percentage: Math.min(100, Math.round((entry.value / this.state.goals.sleep) * 100))
          }))
        };
        break;
        
      case 'heartRate':
        processedData = {
          daily: filteredData,
          average: Math.round(
            filteredData.reduce((sum, entry) => sum + entry.average, 0) / filteredData.length
          ),
          min: Math.min(...filteredData.map(entry => entry.min)),
          max: Math.max(...filteredData.map(entry => entry.max))
        };
        break;
        
      case 'workouts':
        processedData = {
          workouts: filteredData,
          count: filteredData.length,
          totalDuration: filteredData.reduce((sum, entry) => sum + entry.duration, 0),
          totalCalories: filteredData.reduce((sum, entry) => sum + entry.calories, 0),
          byType: {}
        };
        
        // Group workouts by type
        filteredData.forEach(workout => {
          if (!processedData.byType[workout.type]) {
            processedData.byType[workout.type] = {
              count: 0,
              totalDuration: 0,
              totalCalories: 0,
              totalDistance: 0,
              workouts: []
            };
          }
          
          processedData.byType[workout.type].count++;
          processedData.byType[workout.type].totalDuration += workout.duration;
          processedData.byType[workout.type].totalCalories += workout.calories;
          if (workout.distance) {
            processedData.byType[workout.type].totalDistance += workout.distance;
          }
          processedData.byType[workout.type].workouts.push(workout);
        });
        break;
        
      default:
        processedData = filteredData;
    }
    
    return {
      success: true,
      dataType,
      timeRange,
      data: processedData
    };
  }
  
  /**
   * Enable or disable health integration
   */
  setEnabled(enabled) {
    this.state.enabled = enabled;
    
    // Start or stop sync
    if (enabled && this.state.connectedApps.length > 0 && !this.syncInterval) {
      this._startSync();
    } else if (!enabled && this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
    
    // Notify listeners
    this._notifyListeners('enabledStateChanged', {
      enabled,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Get current health goals
   */
  getGoals() {
    return this.state.goals;
  }
  
  /**
   * Get health widget configuration
   */
  getWidgetConfig() {
    return this.state.healthWidgetConfig;
  }
  
  /**
   * Get connected health apps
   */
  getConnectedApps() {
    return this.state.connectedApps;
  }
  
  /**
   * Get health permissions status
   */
  getPermissions() {
    return this.state.permissions;
  }
  
  /**
   * Get last sync time
   */
  getLastSync() {
    return this.state.lastSync;
  }
  
  /**
   * Subscribe to health integration events
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from health integration events
   */
  unsubscribe(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  /**
   * Notify all listeners of an event
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in health integration service listener:', error);
      }
    });
  }
  
  /**
   * Clean up the service
   */
  cleanup() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
    
    this.listeners = [];
  }
}

// Export as singleton
export const HealthIntegrationService = new HealthIntegrationServiceClass();