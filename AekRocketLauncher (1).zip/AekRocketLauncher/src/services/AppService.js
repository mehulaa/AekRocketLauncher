import { NativeModules, PermissionsAndroid, Platform } from 'react-native';
import { PreferenceService } from './PreferenceService';

// This service interfaces with native Android features to access app information
class AppServiceClass {
  constructor() {
    this.installedApps = [];
    this.appCategories = {};
    this.customGroups = {};
    this.appDrawerOpen = false;
    this.listeners = [];
  }

  /**
   * Initialize and load installed apps
   */
  async initialize() {
    try {
      // Request required permissions for Android
      if (Platform.OS === 'android') {
        await this._requestPermissions();
      }
      
      // Load installed apps from device
      await this._loadInstalledApps();
      
      // Load custom app categories from preferences
      const savedCategories = await PreferenceService.getItem('appCategories');
      if (savedCategories) {
        this.appCategories = JSON.parse(savedCategories);
      }
      
      // Load custom app groups from preferences
      const savedGroups = await PreferenceService.getItem('customGroups');
      if (savedGroups) {
        this.customGroups = JSON.parse(savedGroups);
      }
      
      return true;
    } catch (error) {
      console.error('Error initializing AppService:', error);
      return false;
    }
  }
  
  /**
   * Request required Android permissions
   */
  async _requestPermissions() {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
        {
          title: "3D Launcher Storage Permission",
          message: "3D Launcher needs access to your storage to load custom wallpapers and icons",
          buttonNeutral: "Ask Me Later",
          buttonNegative: "Cancel",
          buttonPositive: "OK"
        }
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    } catch (err) {
      console.warn(err);
      return false;
    }
  }
  
  /**
   * Load installed apps from the device
   */
  async _loadInstalledApps() {
    try {
      if (Platform.OS === 'android' && NativeModules.AppListModule) {
        // This would require a native module to get installed apps
        // This is a simplified example of how it would be used
        this.installedApps = await NativeModules.AppListModule.getInstalledApps();
      } else {
        // For development/testing, use mock data
        this.installedApps = [
          { packageName: 'com.android.chrome', appName: 'Chrome', isSystemApp: false },
          { packageName: 'com.google.android.gm', appName: 'Gmail', isSystemApp: false },
          { packageName: 'com.google.android.youtube', appName: 'YouTube', isSystemApp: false },
          // Add more as needed for testing
        ];
      }
      
      // Notify listeners about updated app list
      this._notifyListeners('appsUpdated', this.installedApps);
      
      return this.installedApps;
    } catch (error) {
      console.error('Failed to load installed apps:', error);
      return [];
    }
  }
  
  /**
   * Launch an app on the device
   */
  async launchApp(packageName) {
    try {
      if (Platform.OS === 'android' && NativeModules.AppLauncherModule) {
        await NativeModules.AppLauncherModule.launchApp(packageName);
        return true;
      } else {
        console.log('Would launch app:', packageName);
        return false;
      }
    } catch (error) {
      console.error('Failed to launch app:', error);
      return false;
    }
  }
  
  /**
   * Get all installed apps
   */
  getInstalledApps() {
    return this.installedApps;
  }
  
  /**
   * Update app categories
   */
  async updateAppCategories(categories) {
    this.appCategories = categories;
    await PreferenceService.setItem('appCategories', JSON.stringify(categories));
    this._notifyListeners('categoriesUpdated', categories);
  }
  
  /**
   * Update custom app groups
   */
  async updateCustomGroups(groups) {
    this.customGroups = groups;
    await PreferenceService.setItem('customGroups', JSON.stringify(groups));
    this._notifyListeners('groupsUpdated', groups);
  }
  
  /**
   * Get apps by category
   */
  getAppsByCategory(category) {
    if (!this.appCategories[category]) return [];
    
    return this.installedApps.filter(app => 
      this.appCategories[category].includes(app.packageName)
    );
  }
  
  /**
   * Get apps in a custom group
   */
  getAppsInGroup(groupName) {
    if (!this.customGroups[groupName]) return [];
    
    return this.installedApps.filter(app => 
      this.customGroups[groupName].includes(app.packageName)
    );
  }
  
  /**
   * Set app drawer open state
   */
  setAppDrawerOpen(isOpen) {
    this.appDrawerOpen = isOpen;
    this._notifyListeners('drawerStateChanged', isOpen);
  }
  
  /**
   * Check if app drawer is open
   */
  isAppDrawerOpen() {
    return this.appDrawerOpen;
  }
  
  /**
   * Add a listener for AppService events
   */
  addListener(listener) {
    this.listeners.push(listener);
    return () => this.removeListener(listener);
  }
  
  /**
   * Remove a listener
   */
  removeListener(listener) {
    const index = this.listeners.indexOf(listener);
    if (index > -1) {
      this.listeners.splice(index, 1);
    }
  }
  
  /**
   * Notify all listeners of an event
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      if (listener[event]) {
        listener[event](data);
      }
    });
  }
}

// Export a singleton instance
export const AppService = new AppServiceClass();
