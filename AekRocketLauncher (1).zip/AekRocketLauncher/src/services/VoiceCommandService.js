/**
 * Service for voice commands and voice-to-3D interface functionality
 * Processes voice input and converts it to actions and 3D visualizations
 */

class VoiceCommandServiceClass {
  constructor() {
    // State
    this.state = {
      enabled: true,
      listening: false,
      processingCommand: false,
      lastCommand: null,
      lastResponse: null,
      commandHistory: [],
      recognizedCommands: {},
      commandSettings: {
        wakeWord: 'launcher', // Default wake word
        voiceLocale: 'en-US',
        sensitivity: 0.8, // 0.0 to 1.0
        continuousListening: false, // Whether to listen continuously after wake word
        listeningTimeout: 8000, // ms to listen for a command
        useVisualFeedback: true
      },
      initialized: false
    };
    
    // Command registry - maps command patterns to handlers
    this.commandPatterns = {};
    
    // Listeners
    this.listeners = [];
    
    // Command processing timeout
    this.listeningTimeout = null;
  }
  
  /**
   * Initialize the voice command service
   */
  async initialize() {
    if (this.state.initialized) {
      return true;
    }
    
    try {
      // Load saved settings
      await this._loadSettings();
      
      // Register default commands
      this._registerDefaultCommands();
      
      this.state.initialized = true;
      console.log('VoiceCommandService initialized');
      
      // Notify listeners
      this._notifyListeners('serviceInitialized', { success: true });
      
      return true;
    } catch (error) {
      console.error('Failed to initialize VoiceCommandService:', error);
      return false;
    }
  }
  
  /**
   * Load saved settings from storage
   */
  async _loadSettings() {
    // In a real app, this would load from device storage
    // For the prototype, we use default values
    console.log('VoiceCommandService: Loading settings...');
  }
  
  /**
   * Register default command patterns and handlers
   */
  _registerDefaultCommands() {
    // App launch commands
    this.registerCommand(
      'open (.+)',
      'open_app',
      'Open or launch an application',
      this._handleOpenAppCommand.bind(this)
    );
    
    this.registerCommand(
      'launch (.+)',
      'open_app',
      'Open or launch an application',
      this._handleOpenAppCommand.bind(this)
    );
    
    // Show commands
    this.registerCommand(
      'show (.+)',
      'show_ui',
      'Show launcher UI elements or information',
      this._handleShowCommand.bind(this)
    );
    
    this.registerCommand(
      'display (.+)',
      'show_ui',
      'Show launcher UI elements or information',
      this._handleShowCommand.bind(this)
    );
    
    // Search commands
    this.registerCommand(
      'search for (.+)',
      'search',
      'Search for content or apps',
      this._handleSearchCommand.bind(this)
    );
    
    this.registerCommand(
      'find (.+)',
      'search',
      'Search for content or apps',
      this._handleSearchCommand.bind(this)
    );
    
    // System actions
    this.registerCommand(
      'change theme to (.+)',
      'change_theme',
      'Change the launcher theme',
      this._handleThemeCommand.bind(this)
    );
    
    this.registerCommand(
      'set wallpaper to (.+)',
      'change_wallpaper',
      'Change the launcher wallpaper',
      this._handleWallpaperCommand.bind(this)
    );
    
    // Utility commands
    this.registerCommand(
      'what time is it',
      'show_time',
      'Display the current time',
      this._handleTimeCommand.bind(this)
    );
    
    this.registerCommand(
      'weather',
      'show_weather',
      'Show weather information',
      this._handleWeatherCommand.bind(this)
    );
    
    this.registerCommand(
      'help',
      'show_help',
      'Show available voice commands',
      this._handleHelpCommand.bind(this)
    );
  }
  
  /**
   * Start listening for voice commands
   * @param {boolean} requireWakeWord - Whether to require the wake word
   */
  startListening(requireWakeWord = true) {
    if (!this.state.enabled) {
      return false;
    }
    
    // If already listening, do nothing
    if (this.state.listening) {
      return true;
    }
    
    this.state.listening = true;
    this.state.processingCommand = false;
    
    // In a real app, this would start the speech recognition
    // For the prototype, we'll simulate it
    console.log('Voice Command Service: Started listening' + 
                (requireWakeWord ? ' for wake word' : ''));
    
    // Set listening timeout
    this.listeningTimeout = setTimeout(() => {
      this.stopListening('timeout');
    }, this.state.commandSettings.listeningTimeout);
    
    // Notify listeners
    this._notifyListeners('listeningStarted', { 
      requireWakeWord,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Stop listening for voice commands
   */
  stopListening(reason = 'manual') {
    // If not listening, do nothing
    if (!this.state.listening) {
      return true;
    }
    
    // Clear timeout
    if (this.listeningTimeout) {
      clearTimeout(this.listeningTimeout);
      this.listeningTimeout = null;
    }
    
    this.state.listening = false;
    
    // In a real app, this would stop the speech recognition
    console.log('Voice Command Service: Stopped listening, reason:', reason);
    
    // Notify listeners
    this._notifyListeners('listeningStopped', { 
      reason,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Process a voice command
   * @param {string} text - The voice command text
   */
  async processCommand(text) {
    if (!this.state.enabled || this.state.processingCommand) {
      return null;
    }
    
    this.state.processingCommand = true;
    
    try {
      console.log('Processing voice command:', text);
      
      // Check for wake word
      const wakeWordRegex = new RegExp(`^(hey |ok |okay )?(${this.state.commandSettings.wakeWord})\\s+`, 'i');
      const hasWakeWord = wakeWordRegex.test(text);
      
      // If wake word is detected, remove it from the command
      let commandText = text;
      if (hasWakeWord) {
        commandText = text.replace(wakeWordRegex, '');
      }
      
      // Normalize the command text
      commandText = commandText.trim().toLowerCase();
      
      // Add to command history
      this.state.commandHistory.push({
        command: commandText,
        timestamp: new Date().toISOString(),
        hasWakeWord
      });
      
      // Keep history from growing too large
      if (this.state.commandHistory.length > 20) {
        this.state.commandHistory.shift();
      }
      
      // Store as last command
      this.state.lastCommand = {
        text: commandText,
        timestamp: new Date().toISOString()
      };
      
      // Find matching command pattern
      const matchedCommand = this._findMatchingCommand(commandText);
      
      let response = null;
      
      if (matchedCommand) {
        // Process the command
        response = await matchedCommand.handler(
          commandText, 
          matchedCommand.args
        );
        
        // Store recognized command
        if (!this.state.recognizedCommands[matchedCommand.type]) {
          this.state.recognizedCommands[matchedCommand.type] = 0;
        }
        this.state.recognizedCommands[matchedCommand.type]++;
      } else {
        // No matching command found
        response = {
          success: false,
          message: "I didn't understand that command. Try saying 'help' for a list of commands."
        };
      }
      
      // Store as last response
      this.state.lastResponse = {
        ...response,
        timestamp: new Date().toISOString()
      };
      
      // Notify listeners
      this._notifyListeners('commandProcessed', {
        command: commandText,
        response,
        matched: matchedCommand ? true : false,
        matchedType: matchedCommand ? matchedCommand.type : null
      });
      
      // If not using continuous listening, stop listening
      if (!this.state.commandSettings.continuousListening) {
        this.stopListening('commandCompleted');
      }
      
      this.state.processingCommand = false;
      return response;
    } catch (error) {
      console.error('Error processing voice command:', error);
      
      this.state.processingCommand = false;
      this.stopListening('error');
      
      return {
        success: false,
        message: "Sorry, I had trouble processing that command."
      };
    }
  }
  
  /**
   * Find a matching command pattern for the given text
   */
  _findMatchingCommand(text) {
    for (const [pattern, data] of Object.entries(this.commandPatterns)) {
      const regex = new RegExp(`^${pattern}$`, 'i');
      const match = text.match(regex);
      
      if (match) {
        // Extract arguments (captured groups from the regex)
        const args = match.slice(1);
        
        return {
          pattern,
          type: data.type,
          handler: data.handler,
          args
        };
      }
    }
    
    return null;
  }
  
  /**
   * Register a new command pattern
   * @param {string} pattern - Regex pattern for the command
   * @param {string} type - Command type identifier
   * @param {string} description - Description of what the command does
   * @param {function} handler - Function to handle the command
   */
  registerCommand(pattern, type, description, handler) {
    this.commandPatterns[pattern] = {
      type,
      description,
      handler
    };
    
    return true;
  }
  
  /**
   * Unregister a command pattern
   */
  unregisterCommand(pattern) {
    if (this.commandPatterns[pattern]) {
      delete this.commandPatterns[pattern];
      return true;
    }
    return false;
  }
  
  /**
   * Get all registered command patterns
   */
  getRegisteredCommands() {
    const commands = [];
    
    for (const [pattern, data] of Object.entries(this.commandPatterns)) {
      commands.push({
        pattern,
        type: data.type,
        description: data.description
      });
    }
    
    return commands;
  }
  
  /**
   * Command handler for "open" commands
   */
  async _handleOpenAppCommand(text, args) {
    if (!args || args.length === 0) {
      return {
        success: false,
        message: "I didn't hear which app you wanted to open."
      };
    }
    
    const appName = args[0].trim();
    
    // In a real app, this would actually launch the application
    // For the prototype, we'll simulate it
    console.log(`Voice Command: Opening app "${appName}"`);
    
    // Visualize the app opening in 3D
    this._visualizeAppOpen(appName);
    
    return {
      success: true,
      message: `Opening ${appName}`,
      action: {
        type: 'open_app',
        appName,
        visualize: true
      }
    };
  }
  
  /**
   * Command handler for "show" commands
   */
  async _handleShowCommand(text, args) {
    if (!args || args.length === 0) {
      return {
        success: false,
        message: "I didn't hear what you wanted to show."
      };
    }
    
    const target = args[0].trim().toLowerCase();
    
    switch (target) {
      case 'schedule':
      case 'calendar':
      case 'my schedule':
      case 'my calendar':
        console.log('Voice Command: Showing calendar');
        this._visualizeCalendar();
        return {
          success: true,
          message: 'Here\'s your schedule',
          action: {
            type: 'show_ui',
            target: 'calendar',
            visualize: true
          }
        };
        
      case 'notifications':
      case 'my notifications':
        console.log('Voice Command: Showing notifications');
        this._visualizeNotifications();
        return {
          success: true,
          message: 'Here are your notifications',
          action: {
            type: 'show_ui',
            target: 'notifications',
            visualize: true
          }
        };
        
      case 'apps':
      case 'all apps':
      case 'my apps':
        console.log('Voice Command: Showing all apps');
        this._visualizeAppDrawer();
        return {
          success: true,
          message: 'Here are all your apps',
          action: {
            type: 'show_ui',
            target: 'app_drawer',
            visualize: true
          }
        };
        
      default:
        return {
          success: false,
          message: `I'm not sure how to show ${target}.`
        };
    }
  }
  
  /**
   * Command handler for "search" commands
   */
  async _handleSearchCommand(text, args) {
    if (!args || args.length === 0) {
      return {
        success: false,
        message: "I didn't hear what you wanted to search for."
      };
    }
    
    const searchQuery = args[0].trim();
    
    console.log(`Voice Command: Searching for "${searchQuery}"`);
    this._visualizeSearch(searchQuery);
    
    return {
      success: true,
      message: `Searching for ${searchQuery}`,
      action: {
        type: 'search',
        query: searchQuery,
        visualize: true
      }
    };
  }
  
  /**
   * Command handler for theme commands
   */
  async _handleThemeCommand(text, args) {
    if (!args || args.length === 0) {
      return {
        success: false,
        message: "I didn't hear which theme you wanted."
      };
    }
    
    const themeName = args[0].trim();
    
    console.log(`Voice Command: Changing theme to "${themeName}"`);
    this._visualizeThemeChange(themeName);
    
    return {
      success: true,
      message: `Changing theme to ${themeName}`,
      action: {
        type: 'change_theme',
        theme: themeName,
        visualize: true
      }
    };
  }
  
  /**
   * Command handler for wallpaper commands
   */
  async _handleWallpaperCommand(text, args) {
    if (!args || args.length === 0) {
      return {
        success: false,
        message: "I didn't hear which wallpaper you wanted."
      };
    }
    
    const wallpaperName = args[0].trim();
    
    console.log(`Voice Command: Changing wallpaper to "${wallpaperName}"`);
    this._visualizeWallpaperChange(wallpaperName);
    
    return {
      success: true,
      message: `Changing wallpaper to ${wallpaperName}`,
      action: {
        type: 'change_wallpaper',
        wallpaper: wallpaperName,
        visualize: true
      }
    };
  }
  
  /**
   * Command handler for time commands
   */
  async _handleTimeCommand() {
    const now = new Date();
    const timeString = now.toLocaleTimeString(
      this.state.commandSettings.voiceLocale, 
      { hour: 'numeric', minute: 'numeric' }
    );
    
    console.log(`Voice Command: Showing time (${timeString})`);
    this._visualizeTime(now);
    
    return {
      success: true,
      message: `The time is ${timeString}`,
      action: {
        type: 'show_time',
        time: now.toISOString(),
        visualize: true
      }
    };
  }
  
  /**
   * Command handler for weather commands
   */
  async _handleWeatherCommand() {
    // In a real app, this would fetch actual weather data
    // For the prototype, we'll use simulated data
    const weatherData = {
      temperature: 72,
      condition: 'Sunny',
      location: 'Current Location',
      forecast: [
        { day: 'Today', high: 75, low: 65, condition: 'Sunny' },
        { day: 'Tomorrow', high: 78, low: 67, condition: 'Partly Cloudy' }
      ]
    };
    
    console.log('Voice Command: Showing weather');
    this._visualizeWeather(weatherData);
    
    return {
      success: true,
      message: `It's currently ${weatherData.temperature}° and ${weatherData.condition}`,
      action: {
        type: 'show_weather',
        data: weatherData,
        visualize: true
      }
    };
  }
  
  /**
   * Command handler for help commands
   */
  async _handleHelpCommand() {
    console.log('Voice Command: Showing help');
    this._visualizeHelp();
    
    // Get some example commands
    const exampleCommands = [
      'open [app name]',
      'show my schedule',
      'show notifications',
      'search for [query]',
      'change theme to dark',
      'what time is it',
      'weather'
    ];
    
    return {
      success: true,
      message: 'Here are some commands you can try',
      action: {
        type: 'show_help',
        examples: exampleCommands,
        visualize: true
      }
    };
  }
  
  /**
   * 3D visualization for app opening
   */
  _visualizeAppOpen(appName) {
    // In a real app, this would create a 3D visualization effect
    // For the prototype, we'll just log it
    console.log(`3D Visualization: App opening animation for "${appName}"`);
    
    // Notify listeners about the visualization
    this._notifyListeners('visualization', {
      type: 'app_open',
      appName,
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * 3D visualization for calendar/schedule
   */
  _visualizeCalendar() {
    console.log('3D Visualization: Calendar floating elements');
    
    // Notify listeners about the visualization
    this._notifyListeners('visualization', {
      type: 'calendar',
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * 3D visualization for notifications
   */
  _visualizeNotifications() {
    console.log('3D Visualization: Notifications floating cards');
    
    // Notify listeners about the visualization
    this._notifyListeners('visualization', {
      type: 'notifications',
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * 3D visualization for app drawer
   */
  _visualizeAppDrawer() {
    console.log('3D Visualization: App drawer 3D grid');
    
    // Notify listeners about the visualization
    this._notifyListeners('visualization', {
      type: 'app_drawer',
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * 3D visualization for search
   */
  _visualizeSearch(query) {
    console.log(`3D Visualization: Search animation for "${query}"`);
    
    // Notify listeners about the visualization
    this._notifyListeners('visualization', {
      type: 'search',
      query,
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * 3D visualization for theme change
   */
  _visualizeThemeChange(themeName) {
    console.log(`3D Visualization: Theme transition to "${themeName}"`);
    
    // Notify listeners about the visualization
    this._notifyListeners('visualization', {
      type: 'theme_change',
      themeName,
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * 3D visualization for wallpaper change
   */
  _visualizeWallpaperChange(wallpaperName) {
    console.log(`3D Visualization: Wallpaper transition to "${wallpaperName}"`);
    
    // Notify listeners about the visualization
    this._notifyListeners('visualization', {
      type: 'wallpaper_change',
      wallpaperName,
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * 3D visualization for time
   */
  _visualizeTime(time) {
    console.log(`3D Visualization: Floating 3D clock showing ${time.toLocaleTimeString()}`);
    
    // Notify listeners about the visualization
    this._notifyListeners('visualization', {
      type: 'time',
      time: time.toISOString(),
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * 3D visualization for weather
   */
  _visualizeWeather(weatherData) {
    console.log(`3D Visualization: Weather elements showing ${weatherData.condition}`);
    
    // Notify listeners about the visualization
    this._notifyListeners('visualization', {
      type: 'weather',
      weather: weatherData,
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * 3D visualization for help
   */
  _visualizeHelp() {
    console.log('3D Visualization: Floating help command cards');
    
    // Notify listeners about the visualization
    this._notifyListeners('visualization', {
      type: 'help',
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * Update voice command settings
   */
  updateSettings(settings) {
    this.state.commandSettings = {
      ...this.state.commandSettings,
      ...settings
    };
    
    // Notify listeners
    this._notifyListeners('settingsUpdated', { 
      settings: this.state.commandSettings 
    });
    
    return true;
  }
  
  /**
   * Enable or disable voice commands
   */
  setEnabled(enabled) {
    // If disabling, stop listening
    if (!enabled && this.state.listening) {
      this.stopListening('disabled');
    }
    
    this.state.enabled = enabled;
    
    // Notify listeners
    this._notifyListeners('enabledStateChanged', { enabled });
    
    return true;
  }
  
  /**
   * Get the current voice command settings
   */
  getSettings() {
    return this.state.commandSettings;
  }
  
  /**
   * Get the last recognized command
   */
  getLastCommand() {
    return this.state.lastCommand;
  }
  
  /**
   * Get command history
   */
  getCommandHistory() {
    return this.state.commandHistory;
  }
  
  /**
   * Subscribe to voice command events
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from voice command events
   */
  unsubscribe(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  /**
   * Notify all listeners of an event
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in voice command service listener:', error);
      }
    });
  }
}

// Export as singleton
export const VoiceCommandService = new VoiceCommandServiceClass();