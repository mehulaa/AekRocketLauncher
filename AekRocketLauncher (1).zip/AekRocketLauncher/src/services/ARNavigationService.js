/**
 * Service for Augmented Reality (AR) navigation
 * Provides AR directions, place markers, and real-world integration
 */

class ARNavigationServiceClass {
  constructor() {
    // State
    this.state = {
      enabled: true,
      isNavigating: false,
      navigationSettings: {
        showDistanceMarkers: true,
        showDirectionArrows: true,
        showPointsOfInterest: true,
        useAudio: true,
        visualStyle: 'modern', // 'minimal', 'modern', 'detailed'
        arrowSize: 'medium', // 'small', 'medium', 'large'
        showRealTimeTraffic: true,
        unitSystem: 'metric', // 'imperial', 'metric'
        navMode: 'walk', // 'walk', 'drive', 'bike', 'transit'
        showAltitudeChanges: true,
        autoSwitchDayNight: true
      },
      currentNavigation: null,
      availablePOICategories: [
        'food', 'shopping', 'transport', 'entertainment', 
        'services', 'health', 'education', 'finance'
      ],
      selectedPOICategories: ['food', 'transport', 'health'],
      recentDestinations: [],
      favoriteLocations: [],
      currentLocation: null,
      locationPermissionGranted: false,
      cameraPermissionGranted: false,
      initialized: false
    };
    
    // Listeners
    this.listeners = [];
    
    // Navigation update interval
    this.navigationUpdateInterval = null;
  }
  
  /**
   * Initialize the AR navigation service
   */
  async initialize() {
    if (this.state.initialized) {
      return true;
    }
    
    try {
      // Load saved settings
      await this._loadSettings();
      
      // Request permissions
      await this._requestPermissions();
      
      // Load user data
      await this._loadUserData();
      
      this.state.initialized = true;
      console.log('ARNavigationService initialized');
      
      // Notify listeners
      this._notifyListeners('serviceInitialized', {
        success: true,
        permissionsGranted: {
          location: this.state.locationPermissionGranted,
          camera: this.state.cameraPermissionGranted
        }
      });
      
      return true;
    } catch (error) {
      console.error('Failed to initialize ARNavigationService:', error);
      return false;
    }
  }
  
  /**
   * Load saved settings from storage
   */
  async _loadSettings() {
    // In a real app, this would load from device storage
    console.log('ARNavigationService: Loading settings...');
  }
  
  /**
   * Request necessary permissions for AR navigation
   */
  async _requestPermissions() {
    // In a real app, this would request actual permissions
    // For the prototype, we'll simulate permission grants
    
    // Simulate location permission - 90% chance of success
    this.state.locationPermissionGranted = Math.random() < 0.9;
    
    // Simulate camera permission - 85% chance of success
    this.state.cameraPermissionGranted = Math.random() < 0.85;
    
    return {
      location: this.state.locationPermissionGranted,
      camera: this.state.cameraPermissionGranted
    };
  }
  
  /**
   * Load user data like favorite places and recent destinations
   */
  async _loadUserData() {
    // In a real app, this would load from device storage
    // For the prototype, we'll use some example data
    
    // Example favorite locations
    this.state.favoriteLocations = [
      {
        id: 'home',
        name: 'Home',
        address: '123 Main Street',
        coordinates: { latitude: 37.7749, longitude: -122.4194 },
        icon: 'home',
        category: 'personal'
      },
      {
        id: 'work',
        name: 'Office',
        address: '456 Market Street',
        coordinates: { latitude: 37.7950, longitude: -122.3980 },
        icon: 'work',
        category: 'work'
      },
      {
        id: 'gym',
        name: 'Fitness Center',
        address: '789 Health Blvd',
        coordinates: { latitude: 37.7833, longitude: -122.4167 },
        icon: 'fitness',
        category: 'health'
      }
    ];
    
    // Example recent destinations
    this.state.recentDestinations = [
      {
        id: 'dest_1',
        name: 'Coffee Shop',
        address: '321 Brew Street',
        coordinates: { latitude: 37.7855, longitude: -122.4071 },
        timestamp: '2025-03-09T15:30:00Z',
        category: 'food'
      },
      {
        id: 'dest_2',
        name: 'Shopping Mall',
        address: '555 Retail Road',
        coordinates: { latitude: 37.7835, longitude: -122.4320 },
        timestamp: '2025-03-08T12:15:00Z',
        category: 'shopping'
      },
      {
        id: 'dest_3',
        name: 'City Park',
        address: 'Green Space Avenue',
        coordinates: { latitude: 37.7694, longitude: -122.4862 },
        timestamp: '2025-03-07T10:45:00Z',
        category: 'entertainment'
      }
    ];
  }
  
  /**
   * Get current device location
   */
  async getCurrentLocation() {
    // In a real app, this would use the device's location API
    // For the prototype, we'll use a simulated location
    
    if (!this.state.locationPermissionGranted) {
      return {
        success: false,
        error: 'Location permission not granted'
      };
    }
    
    // Simulate getting current location
    // Use one of the favorite locations with slight variation
    const baseLocation = this.state.favoriteLocations[
      Math.floor(Math.random() * this.state.favoriteLocations.length)
    ];
    
    // Add small random variations to the coordinates
    const location = {
      coordinates: {
        latitude: baseLocation.coordinates.latitude + (Math.random() * 0.01 - 0.005),
        longitude: baseLocation.coordinates.longitude + (Math.random() * 0.01 - 0.005)
      },
      accuracy: 15, // meters
      timestamp: new Date().toISOString()
    };
    
    this.state.currentLocation = location;
    
    return {
      success: true,
      location
    };
  }
  
  /**
   * Start AR navigation to a destination
   */
  async startNavigation(destination) {
    if (!this.state.enabled) {
      return {
        success: false,
        error: 'AR Navigation is disabled'
      };
    }
    
    if (!this.state.locationPermissionGranted || !this.state.cameraPermissionGranted) {
      return {
        success: false,
        error: 'Required permissions not granted'
      };
    }
    
    try {
      console.log(`Starting AR navigation to: ${destination.name}`);
      
      // Get current location
      const locationResult = await this.getCurrentLocation();
      if (!locationResult.success) {
        return locationResult;
      }
      
      // Plan route
      const route = await this._planRoute(locationResult.location, destination);
      
      // Create navigation object
      const navigation = {
        id: `nav_${Date.now()}`,
        destination,
        startLocation: locationResult.location,
        startTime: new Date().toISOString(),
        estimatedDuration: route.duration,
        estimatedDistance: route.distance,
        currentStep: 0,
        route: route,
        status: 'active'
      };
      
      // Set as current navigation
      this.state.currentNavigation = navigation;
      this.state.isNavigating = true;
      
      // Start navigation updates
      this._startNavigationUpdates();
      
      // Add to recent destinations if not already there
      const existingIndex = this.state.recentDestinations.findIndex(
        dest => dest.id === destination.id
      );
      
      if (existingIndex !== -1) {
        // Update timestamp for existing destination
        this.state.recentDestinations[existingIndex].timestamp = new Date().toISOString();
      } else {
        // Add new destination with timestamp
        this.state.recentDestinations.unshift({
          ...destination,
          timestamp: new Date().toISOString()
        });
        
        // Keep only the 10 most recent
        if (this.state.recentDestinations.length > 10) {
          this.state.recentDestinations.pop();
        }
      }
      
      // Notify listeners
      this._notifyListeners('navigationStarted', {
        navigation,
        timestamp: new Date().toISOString()
      });
      
      return {
        success: true,
        navigation
      };
    } catch (error) {
      console.error('Failed to start navigation:', error);
      return {
        success: false,
        error: 'Failed to start navigation'
      };
    }
  }
  
  /**
   * Plan a route between two locations
   */
  async _planRoute(startLocation, destination) {
    // In a real app, this would use a maps/routing API
    // For the prototype, we'll create a simulated route
    
    // Calculate distance (simplified)
    const lat1 = startLocation.coordinates.latitude;
    const lon1 = startLocation.coordinates.longitude;
    const lat2 = destination.coordinates.latitude;
    const lon2 = destination.coordinates.longitude;
    
    // Simple distance calculation (not accurate for real navigation)
    const R = 6371e3; // Earth radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;
    
    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    
    const distanceInMeters = R * c;
    const distanceInKm = distanceInMeters / 1000;
    
    // Calculate duration based on navigation mode
    let speedKmPerHour;
    switch (this.state.navigationSettings.navMode) {
      case 'walk':
        speedKmPerHour = 5;
        break;
      case 'bike':
        speedKmPerHour = 15;
        break;
      case 'drive':
        speedKmPerHour = 40; // Urban average
        break;
      case 'transit':
        speedKmPerHour = 25;
        break;
      default:
        speedKmPerHour = 5;
    }
    
    const durationInHours = distanceInKm / speedKmPerHour;
    const durationInMinutes = Math.ceil(durationInHours * 60);
    
    // Generate steps
    const numSteps = Math.max(3, Math.ceil(distanceInKm * 2));
    const steps = [];
    
    for (let i = 0; i < numSteps; i++) {
      const progress = (i + 1) / numSteps;
      const stepLat = lat1 + progress * (lat2 - lat1);
      const stepLon = lon1 + progress * (lon2 - lon1);
      
      let instruction;
      if (i === 0) {
        instruction = `Start heading ${this._getDirection(lat1, lon1, stepLat, stepLon)}`;
      } else if (i === numSteps - 1) {
        instruction = `Arrive at ${destination.name}`;
      } else {
        // Randomly choose a direction instruction
        const directions = [
          `Continue ${this._getDirection(lat1, lon1, lat2, lon2)}`,
          `Turn ${Math.random() > 0.5 ? 'left' : 'right'} onto the next street`,
          `Keep ${Math.random() > 0.5 ? 'left' : 'right'} at the fork`,
          `Cross the intersection`
        ];
        instruction = directions[Math.floor(Math.random() * directions.length)];
      }
      
      steps.push({
        instruction,
        distanceFromStart: distanceInMeters * progress,
        coordinates: { latitude: stepLat, longitude: stepLon },
        maneuver: i === 0 ? 'start' : i === numSteps - 1 ? 'arrive' : 'continue'
      });
    }
    
    // Generate POIs along the route
    const pointsOfInterest = [];
    
    if (this.state.navigationSettings.showPointsOfInterest) {
      // Generate random POIs along the route
      const numPOIs = Math.floor(Math.random() * 5) + 2; // 2 to 6 POIs
      
      for (let i = 0; i < numPOIs; i++) {
        const progress = Math.random();
        const poiLat = lat1 + progress * (lat2 - lat1) + (Math.random() * 0.01 - 0.005);
        const poiLon = lon1 + progress * (lon2 - lon1) + (Math.random() * 0.01 - 0.005);
        
        // Only include POIs from selected categories
        const categories = this.state.selectedPOICategories;
        const category = categories[Math.floor(Math.random() * categories.length)];
        
        // POI names based on category
        const poiNames = {
          food: ['Café', 'Restaurant', 'Bakery', 'Food Court'],
          transport: ['Bus Stop', 'Metro Station', 'Taxi Stand', 'Bike Sharing'],
          shopping: ['Mall', 'Supermarket', 'Clothing Store', 'Electronics Shop'],
          entertainment: ['Cinema', 'Theater', 'Museum', 'Park'],
          services: ['Post Office', 'Bank', 'Salon', 'Laundry'],
          health: ['Pharmacy', 'Hospital', 'Clinic', 'Dental Care'],
          education: ['School', 'Library', 'University', 'Learning Center'],
          finance: ['ATM', 'Bank Branch', 'Currency Exchange', 'Insurance Office']
        };
        
        const nameOptions = poiNames[category] || ['Point of Interest'];
        const name = nameOptions[Math.floor(Math.random() * nameOptions.length)];
        
        pointsOfInterest.push({
          id: `poi_${Date.now()}_${i}`,
          name,
          category,
          coordinates: { latitude: poiLat, longitude: poiLon },
          distanceFromRoute: Math.floor(Math.random() * 150) + 20 // 20-170 meters
        });
      }
    }
    
    return {
      distance: distanceInKm,
      distanceText: this.state.navigationSettings.unitSystem === 'metric' ?
        `${distanceInKm.toFixed(1)} km` :
        `${(distanceInKm * 0.621371).toFixed(1)} mi`,
      duration: durationInMinutes,
      durationText: durationInMinutes >= 60 ?
        `${Math.floor(durationInMinutes / 60)} hr ${durationInMinutes % 60} min` :
        `${durationInMinutes} min`,
      steps,
      pointsOfInterest,
      overview: {
        startAddress: 'Current Location',
        endAddress: destination.address || 'Destination',
        bounds: {
          southwest: {
            latitude: Math.min(lat1, lat2) - 0.01,
            longitude: Math.min(lon1, lon2) - 0.01
          },
          northeast: {
            latitude: Math.max(lat1, lat2) + 0.01,
            longitude: Math.max(lon1, lon2) + 0.01
          }
        }
      }
    };
  }
  
  /**
   * Get general direction between coordinates
   */
  _getDirection(lat1, lon1, lat2, lon2) {
    const dLat = lat2 - lat1;
    const dLon = lon2 - lon1;
    
    let direction;
    
    if (Math.abs(dLat) > Math.abs(dLon)) {
      // More north-south than east-west
      direction = dLat > 0 ? 'north' : 'south';
    } else {
      // More east-west than north-south
      direction = dLon > 0 ? 'east' : 'west';
    }
    
    return direction;
  }
  
  /**
   * Start periodic navigation updates
   */
  _startNavigationUpdates() {
    // Clear any existing interval
    if (this.navigationUpdateInterval) {
      clearInterval(this.navigationUpdateInterval);
    }
    
    // Update navigation every 5 seconds
    this.navigationUpdateInterval = setInterval(() => {
      this._updateNavigation();
    }, 5000);
    
    // Do an immediate update
    this._updateNavigation();
  }
  
  /**
   * Update current navigation progress
   */
  _updateNavigation() {
    if (!this.state.isNavigating || !this.state.currentNavigation) {
      return;
    }
    
    const navigation = this.state.currentNavigation;
    
    // Get current location
    this.getCurrentLocation().then(locationResult => {
      if (!locationResult.success) {
        return;
      }
      
      const currentLocation = locationResult.location;
      
      // Simulate progress based on time elapsed
      const startTime = new Date(navigation.startTime);
      const now = new Date();
      const elapsedMinutes = (now - startTime) / (1000 * 60);
      const progress = Math.min(1, elapsedMinutes / navigation.estimatedDuration);
      
      // Update current step based on progress
      const totalSteps = navigation.route.steps.length;
      const newStepIndex = Math.min(totalSteps - 1, Math.floor(progress * totalSteps));
      
      // Only update if step changed
      if (newStepIndex !== navigation.currentStep) {
        navigation.currentStep = newStepIndex;
        
        // Get current step
        const currentStep = navigation.route.steps[navigation.currentStep];
        
        // Notify about step change
        this._notifyListeners('navigationStepChanged', {
          navigation,
          currentStep,
          nextStep: navigation.route.steps[Math.min(totalSteps - 1, navigation.currentStep + 1)],
          progress,
          timestamp: new Date().toISOString()
        });
        
        // Check if navigation complete
        if (navigation.currentStep === totalSteps - 1 && progress >= 0.99) {
          this.stopNavigation('completed');
        }
      }
      
      // Update navigation with current location
      navigation.currentLocation = currentLocation;
    });
  }
  
  /**
   * Stop the current navigation
   */
  stopNavigation(reason = 'manual') {
    if (!this.state.isNavigating) {
      return false;
    }
    
    // Stop navigation updates
    if (this.navigationUpdateInterval) {
      clearInterval(this.navigationUpdateInterval);
      this.navigationUpdateInterval = null;
    }
    
    // Update navigation status
    this.state.currentNavigation.status = reason === 'completed' ? 'completed' : 'cancelled';
    this.state.currentNavigation.endTime = new Date().toISOString();
    this.state.isNavigating = false;
    
    // Notify listeners
    this._notifyListeners('navigationStopped', {
      navigation: this.state.currentNavigation,
      reason,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Get points of interest near current location
   */
  async getNearbyPointsOfInterest() {
    if (!this.state.locationPermissionGranted) {
      return {
        success: false,
        error: 'Location permission not granted'
      };
    }
    
    // Get current location
    const locationResult = await this.getCurrentLocation();
    if (!locationResult.success) {
      return locationResult;
    }
    
    // Generate simulated POIs
    const lat = locationResult.location.coordinates.latitude;
    const lon = locationResult.location.coordinates.longitude;
    const pointsOfInterest = [];
    
    // Only include POIs from selected categories
    const categories = this.state.selectedPOICategories;
    
    // POI names based on category
    const poiNames = {
      food: ['Café', 'Restaurant', 'Bakery', 'Food Court'],
      transport: ['Bus Stop', 'Metro Station', 'Taxi Stand', 'Bike Sharing'],
      shopping: ['Mall', 'Supermarket', 'Clothing Store', 'Electronics Shop'],
      entertainment: ['Cinema', 'Theater', 'Museum', 'Park'],
      services: ['Post Office', 'Bank', 'Salon', 'Laundry'],
      health: ['Pharmacy', 'Hospital', 'Clinic', 'Dental Care'],
      education: ['School', 'Library', 'University', 'Learning Center'],
      finance: ['ATM', 'Bank Branch', 'Currency Exchange', 'Insurance Office']
    };
    
    // Generate a random number of POIs per category
    categories.forEach(category => {
      const numPOIs = Math.floor(Math.random() * 3) + 1; // 1-3 POIs per category
      
      for (let i = 0; i < numPOIs; i++) {
        // Random location within ~500m
        const poiLat = lat + (Math.random() * 0.01 - 0.005);
        const poiLon = lon + (Math.random() * 0.01 - 0.005);
        
        // Calculate distance (simplified)
        const R = 6371; // Earth radius in km
        const φ1 = lat * Math.PI / 180;
        const φ2 = poiLat * Math.PI / 180;
        const Δφ = (poiLat - lat) * Math.PI / 180;
        const Δλ = (poiLon - lon) * Math.PI / 180;
        
        const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                  Math.cos(φ1) * Math.cos(φ2) *
                  Math.sin(Δλ/2) * Math.sin(Δλ/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        
        const distance = R * c * 1000; // Distance in meters
        
        const nameOptions = poiNames[category] || ['Point of Interest'];
        const name = nameOptions[Math.floor(Math.random() * nameOptions.length)];
        
        pointsOfInterest.push({
          id: `poi_${Date.now()}_${category}_${i}`,
          name,
          category,
          coordinates: { latitude: poiLat, longitude: poiLon },
          distance: Math.round(distance),
          distanceText: `${Math.round(distance)}m`
        });
      }
    });
    
    // Sort by distance
    pointsOfInterest.sort((a, b) => a.distance - b.distance);
    
    return {
      success: true,
      pointsOfInterest
    };
  }
  
  /**
   * Add a location to favorites
   */
  addFavoriteLocation(location) {
    if (!location.name || !location.coordinates) {
      return {
        success: false,
        error: 'Invalid location data'
      };
    }
    
    // Check if location already exists
    const existingIndex = this.state.favoriteLocations.findIndex(
      loc => loc.name === location.name
    );
    
    if (existingIndex !== -1) {
      return {
        success: false,
        error: 'Location already in favorites'
      };
    }
    
    // Create favorite location object
    const favoriteLocation = {
      id: `fav_${Date.now()}`,
      name: location.name,
      address: location.address || '',
      coordinates: location.coordinates,
      icon: location.icon || 'place',
      category: location.category || 'personal',
      addedAt: new Date().toISOString()
    };
    
    // Add to favorites
    this.state.favoriteLocations.push(favoriteLocation);
    
    // Notify listeners
    this._notifyListeners('favoriteAdded', {
      location: favoriteLocation,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true,
      location: favoriteLocation
    };
  }
  
  /**
   * Remove a location from favorites
   */
  removeFavoriteLocation(locationId) {
    const index = this.state.favoriteLocations.findIndex(loc => loc.id === locationId);
    
    if (index === -1) {
      return {
        success: false,
        error: 'Location not found in favorites'
      };
    }
    
    // Get location data before removing
    const location = this.state.favoriteLocations[index];
    
    // Remove from favorites
    this.state.favoriteLocations.splice(index, 1);
    
    // Notify listeners
    this._notifyListeners('favoriteRemoved', {
      locationId,
      locationName: location.name,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true
    };
  }
  
  /**
   * Update navigation settings
   */
  updateSettings(settings) {
    this.state.navigationSettings = {
      ...this.state.navigationSettings,
      ...settings
    };
    
    // Notify listeners
    this._notifyListeners('settingsUpdated', {
      settings: this.state.navigationSettings,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Update selected POI categories
   */
  updatePOICategories(categories) {
    // Validate categories
    const validCategories = categories.filter(
      category => this.state.availablePOICategories.includes(category)
    );
    
    this.state.selectedPOICategories = validCategories;
    
    // Notify listeners
    this._notifyListeners('poiCategoriesUpdated', {
      categories: validCategories,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Enable or disable AR navigation
   */
  setEnabled(enabled) {
    this.state.enabled = enabled;
    
    // If disabling while navigating, stop navigation
    if (!enabled && this.state.isNavigating) {
      this.stopNavigation('disabled');
    }
    
    // Notify listeners
    this._notifyListeners('enabledStateChanged', {
      enabled,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Get navigation settings
   */
  getSettings() {
    return this.state.navigationSettings;
  }
  
  /**
   * Get favorite locations
   */
  getFavoriteLocations() {
    return this.state.favoriteLocations;
  }
  
  /**
   * Get recent destinations
   */
  getRecentDestinations() {
    return this.state.recentDestinations;
  }
  
  /**
   * Get current navigation status
   */
  getCurrentNavigation() {
    return this.state.isNavigating ? this.state.currentNavigation : null;
  }
  
  /**
   * Get available and selected POI categories
   */
  getPOICategories() {
    return {
      available: this.state.availablePOICategories,
      selected: this.state.selectedPOICategories
    };
  }
  
  /**
   * Subscribe to AR navigation events
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from AR navigation events
   */
  unsubscribe(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  /**
   * Notify all listeners of an event
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in AR navigation service listener:', error);
      }
    });
  }
  
  /**
   * Clean up the service
   */
  cleanup() {
    if (this.navigationUpdateInterval) {
      clearInterval(this.navigationUpdateInterval);
      this.navigationUpdateInterval = null;
    }
    
    this.listeners = [];
  }
}

// Export as singleton
export const ARNavigationService = new ARNavigationServiceClass();