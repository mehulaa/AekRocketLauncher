/**
 * Service for biometric security and privacy features
 * Manages authentication, app locking, and privacy settings
 */

class BiometricSecurityServiceClass {
  constructor() {
    // State
    this.state = {
      enabled: true,
      biometricAvailable: false,
      biometricType: null, // 'fingerprint', 'face', 'iris', null
      authenticationActive: false,
      securedApps: {},
      securedFolders: {},
      privacySettings: {
        autoLock: true,
        autoLockDelay: 5 * 60 * 1000, // 5 minutes
        locationBasedSecurity: false,
        safeLocations: [],
        requireBiometricOnBoot: true,
        hideNotificationContent: true,
        privacyMode: false,
        panicGesture: null,
        failedAttemptsBeforeLockout: 5,
        lockoutDuration: 30 * 60 * 1000 // 30 minutes
      },
      authHistory: [],
      securityStatus: {
        authenticated: false,
        lastAuthenticated: null,
        failedAttempts: 0,
        lockedOut: false,
        lockoutUntil: null
      },
      initialized: false
    };
    
    // Listeners
    this.listeners = [];
    
    // Auto-lock timer
    this.autoLockTimer = null;
    
    // Mock authentication for prototype
    this.mockAuthHandler = null;
  }
  
  /**
   * Initialize the biometric security service
   */
  async initialize() {
    if (this.state.initialized) {
      return true;
    }
    
    try {
      // Load saved settings
      await this._loadSettings();
      
      // Check if biometric authentication is available
      await this._checkBiometricAvailability();
      
      // Load secured apps and folders
      await this._loadSecurityData();
      
      this.state.initialized = true;
      console.log('BiometricSecurityService initialized');
      
      // Start auto-lock timer if enabled
      if (this.state.privacySettings.autoLock) {
        this._startAutoLockTimer();
      }
      
      // Notify listeners
      this._notifyListeners('serviceInitialized', {
        success: true,
        biometricAvailable: this.state.biometricAvailable,
        biometricType: this.state.biometricType
      });
      
      return true;
    } catch (error) {
      console.error('Failed to initialize BiometricSecurityService:', error);
      return false;
    }
  }
  
  /**
   * Load saved settings from storage
   */
  async _loadSettings() {
    // In a real app, this would load from device storage
    // For the prototype, we use default values
    console.log('BiometricSecurityService: Loading settings...');
  }
  
  /**
   * Check if biometric authentication is available on the device
   */
  async _checkBiometricAvailability() {
    // In a real app, this would check the device capabilities
    // For the prototype, we'll simulate biometric availability
    
    this.state.biometricAvailable = true;
    this.state.biometricType = 'fingerprint';
    
    return this.state.biometricAvailable;
  }
  
  /**
   * Load secured apps and folders
   */
  async _loadSecurityData() {
    // In a real app, this would load from device storage
    // For the prototype, we'll use some example data
    
    // Example secured apps
    this.state.securedApps = {
      'com.banking.app': {
        appName: 'Banking App',
        securityLevel: 'high', // 'high', 'medium', 'low'
        requiresAuth: true,
        hideFromRecents: true,
        securedAt: '2025-02-10T15:30:00Z'
      },
      'com.password.manager': {
        appName: 'Password Manager',
        securityLevel: 'high',
        requiresAuth: true,
        hideFromRecents: true,
        securedAt: '2025-02-10T15:35:00Z'
      },
      'com.gallery.app': {
        appName: 'Gallery',
        securityLevel: 'medium',
        requiresAuth: true,
        hideFromRecents: false,
        securedAt: '2025-02-15T09:20:00Z'
      }
    };
    
    // Example secured folders
    this.state.securedFolders = {
      'private_folder': {
        folderName: 'Private',
        securityLevel: 'high',
        requiresAuth: true,
        hideContents: true,
        securedAt: '2025-02-10T16:00:00Z'
      },
      'work_folder': {
        folderName: 'Work',
        securityLevel: 'medium',
        requiresAuth: true,
        hideContents: false,
        securedAt: '2025-02-12T10:15:00Z'
      }
    };
  }
  
  /**
   * Start the auto-lock timer
   */
  _startAutoLockTimer() {
    // Clear any existing timer
    if (this.autoLockTimer) {
      clearTimeout(this.autoLockTimer);
    }
    
    // Set new timer
    this.autoLockTimer = setTimeout(() => {
      this._autoLock();
    }, this.state.privacySettings.autoLockDelay);
  }
  
  /**
   * Reset the auto-lock timer (called when user interacts with the device)
   */
  resetAutoLockTimer() {
    if (this.state.privacySettings.autoLock) {
      this._startAutoLockTimer();
    }
  }
  
  /**
   * Automatically lock the device
   */
  _autoLock() {
    if (this.state.securityStatus.authenticated) {
      // Lock the device
      this.state.securityStatus.authenticated = false;
      
      // Add to auth history
      this.state.authHistory.push({
        type: 'auto_lock',
        success: true,
        timestamp: new Date().toISOString()
      });
      
      // Notify listeners
      this._notifyListeners('locked', {
        reason: 'auto_lock',
        timestamp: new Date().toISOString()
      });
    }
  }
  
  /**
   * Authenticate with biometrics
   */
  async authenticate(options = {}) {
    // Check if biometrics is available
    if (!this.state.biometricAvailable && !options.allowFallback) {
      return {
        success: false,
        error: 'Biometric authentication not available'
      };
    }
    
    // Check if locked out
    if (this.state.securityStatus.lockedOut) {
      const now = new Date();
      const lockoutUntil = new Date(this.state.securityStatus.lockoutUntil);
      
      if (now < lockoutUntil) {
        const remainingMinutes = Math.ceil((lockoutUntil - now) / (60 * 1000));
        
        return {
          success: false,
          error: `Too many failed attempts. Try again in ${remainingMinutes} minutes.`,
          lockout: true,
          lockoutUntil
        };
      } else {
        // Lockout period over
        this.state.securityStatus.lockedOut = false;
        this.state.securityStatus.lockoutUntil = null;
        this.state.securityStatus.failedAttempts = 0;
      }
    }
    
    try {
      // In a real app, this would trigger actual biometric authentication
      // For the prototype, we'll simulate success or failure
      
      // Start authentication process
      this.state.authenticationActive = true;
      
      // Notify listeners of authentication start
      this._notifyListeners('authenticationStarted', {
        type: this.state.biometricType,
        reason: options.reason || 'unlock',
        timestamp: new Date().toISOString()
      });
      
      // For the prototype, use a mock authentication system
      let authenticated = false;
      
      if (this.mockAuthHandler) {
        // Use the mock handler if one is set (for testing)
        authenticated = await this.mockAuthHandler();
      } else {
        // Default mock behavior: always succeed
        authenticated = true;
        
        // Simulate authentication delay
        await new Promise(resolve => setTimeout(resolve, 800));
      }
      
      // Update authentication status
      this.state.authenticationActive = false;
      
      if (authenticated) {
        // Authentication successful
        this.state.securityStatus.authenticated = true;
        this.state.securityStatus.lastAuthenticated = new Date().toISOString();
        this.state.securityStatus.failedAttempts = 0;
        
        // Add to auth history
        this.state.authHistory.push({
          type: 'biometric',
          biometricType: this.state.biometricType,
          success: true,
          reason: options.reason || 'unlock',
          timestamp: new Date().toISOString()
        });
        
        // Reset auto-lock timer
        this.resetAutoLockTimer();
        
        // Notify listeners
        this._notifyListeners('authenticationSuccess', {
          type: this.state.biometricType,
          timestamp: new Date().toISOString()
        });
        
        return {
          success: true
        };
      } else {
        // Authentication failed
        this.state.securityStatus.failedAttempts++;
        
        // Add to auth history
        this.state.authHistory.push({
          type: 'biometric',
          biometricType: this.state.biometricType,
          success: false,
          reason: options.reason || 'unlock',
          timestamp: new Date().toISOString()
        });
        
        // Check if should lockout
        if (this.state.securityStatus.failedAttempts >= this.state.privacySettings.failedAttemptsBeforeLockout) {
          // Lock out
          const lockoutUntil = new Date(Date.now() + this.state.privacySettings.lockoutDuration);
          this.state.securityStatus.lockedOut = true;
          this.state.securityStatus.lockoutUntil = lockoutUntil.toISOString();
          
          // Notify listeners
          this._notifyListeners('accountLockout', {
            failedAttempts: this.state.securityStatus.failedAttempts,
            lockoutUntil: lockoutUntil.toISOString(),
            timestamp: new Date().toISOString()
          });
          
          return {
            success: false,
            error: 'Too many failed attempts. Device locked out.',
            lockout: true,
            lockoutUntil: lockoutUntil.toISOString()
          };
        }
        
        // Notify listeners
        this._notifyListeners('authenticationFailure', {
          type: this.state.biometricType,
          failedAttempts: this.state.securityStatus.failedAttempts,
          timestamp: new Date().toISOString()
        });
        
        return {
          success: false,
          error: 'Biometric authentication failed',
          failedAttempts: this.state.securityStatus.failedAttempts
        };
      }
    } catch (error) {
      console.error('Authentication error:', error);
      
      this.state.authenticationActive = false;
      
      return {
        success: false,
        error: 'An error occurred during authentication'
      };
    }
  }
  
  /**
   * Lock the device manually
   */
  lock() {
    // Only lock if currently authenticated
    if (this.state.securityStatus.authenticated) {
      this.state.securityStatus.authenticated = false;
      
      // Add to auth history
      this.state.authHistory.push({
        type: 'manual_lock',
        success: true,
        timestamp: new Date().toISOString()
      });
      
      // Clear auto-lock timer
      if (this.autoLockTimer) {
        clearTimeout(this.autoLockTimer);
        this.autoLockTimer = null;
      }
      
      // Notify listeners
      this._notifyListeners('locked', {
        reason: 'manual',
        timestamp: new Date().toISOString()
      });
      
      return true;
    }
    
    return false;
  }
  
  /**
   * Check if device is locked
   */
  isLocked() {
    return !this.state.securityStatus.authenticated;
  }
  
  /**
   * Check if authentication is in progress
   */
  isAuthenticating() {
    return this.state.authenticationActive;
  }
  
  /**
   * Check if an app is secured and requires authentication
   */
  isAppSecured(packageName) {
    return !!this.state.securedApps[packageName];
  }
  
  /**
   * Check if a folder is secured and requires authentication
   */
  isFolderSecured(folderId) {
    return !!this.state.securedFolders[folderId];
  }
  
  /**
   * Get security status for an app
   */
  getAppSecurityStatus(packageName) {
    return this.state.securedApps[packageName] || null;
  }
  
  /**
   * Secure an app with biometric authentication
   */
  secureApp(packageName, appName, options = {}) {
    if (!this.state.enabled) {
      return {
        success: false,
        error: 'Biometric security is disabled'
      };
    }
    
    if (!packageName || !appName) {
      return {
        success: false,
        error: 'Package name and app name are required'
      };
    }
    
    // Create security settings for the app
    this.state.securedApps[packageName] = {
      appName,
      securityLevel: options.securityLevel || 'medium',
      requiresAuth: true,
      hideFromRecents: options.hideFromRecents || false,
      securedAt: new Date().toISOString()
    };
    
    // Notify listeners
    this._notifyListeners('appSecured', {
      packageName,
      appName,
      settings: this.state.securedApps[packageName],
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true,
      settings: this.state.securedApps[packageName]
    };
  }
  
  /**
   * Remove security from an app
   */
  unsecureApp(packageName) {
    if (!this.state.securedApps[packageName]) {
      return {
        success: false,
        error: 'App is not secured'
      };
    }
    
    // Get app name before removing
    const appName = this.state.securedApps[packageName].appName;
    
    // Remove security settings
    delete this.state.securedApps[packageName];
    
    // Notify listeners
    this._notifyListeners('appUnsecured', {
      packageName,
      appName,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true
    };
  }
  
  /**
   * Secure a folder with biometric authentication
   */
  secureFolder(folderId, folderName, options = {}) {
    if (!this.state.enabled) {
      return {
        success: false,
        error: 'Biometric security is disabled'
      };
    }
    
    if (!folderId || !folderName) {
      return {
        success: false,
        error: 'Folder ID and folder name are required'
      };
    }
    
    // Create security settings for the folder
    this.state.securedFolders[folderId] = {
      folderName,
      securityLevel: options.securityLevel || 'medium',
      requiresAuth: true,
      hideContents: options.hideContents || false,
      securedAt: new Date().toISOString()
    };
    
    // Notify listeners
    this._notifyListeners('folderSecured', {
      folderId,
      folderName,
      settings: this.state.securedFolders[folderId],
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true,
      settings: this.state.securedFolders[folderId]
    };
  }
  
  /**
   * Remove security from a folder
   */
  unsecureFolder(folderId) {
    if (!this.state.securedFolders[folderId]) {
      return {
        success: false,
        error: 'Folder is not secured'
      };
    }
    
    // Get folder name before removing
    const folderName = this.state.securedFolders[folderId].folderName;
    
    // Remove security settings
    delete this.state.securedFolders[folderId];
    
    // Notify listeners
    this._notifyListeners('folderUnsecured', {
      folderId,
      folderName,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true
    };
  }
  
  /**
   * Enable privacy mode (hides sensitive information)
   */
  enablePrivacyMode() {
    this.state.privacySettings.privacyMode = true;
    
    // Notify listeners
    this._notifyListeners('privacyModeChanged', {
      enabled: true,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Disable privacy mode
   */
  disablePrivacyMode() {
    this.state.privacySettings.privacyMode = false;
    
    // Notify listeners
    this._notifyListeners('privacyModeChanged', {
      enabled: false,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Toggle privacy mode
   */
  togglePrivacyMode() {
    return this.state.privacySettings.privacyMode ? 
      this.disablePrivacyMode() : 
      this.enablePrivacyMode();
  }
  
  /**
   * Check if privacy mode is enabled
   */
  isPrivacyModeEnabled() {
    return this.state.privacySettings.privacyMode;
  }
  
  /**
   * Setup a panic gesture to quickly enable privacy mode
   */
  setPanicGesture(gestureId) {
    this.state.privacySettings.panicGesture = gestureId;
    
    // Notify listeners
    this._notifyListeners('panicGestureSet', {
      gestureId,
      timestamp: new Date().toISOString()
    });
    
    return true;
  }
  
  /**
   * Add a safe location for location-based security
   */
  addSafeLocation(location) {
    if (!location || !location.name || !location.coordinates) {
      return {
        success: false,
        error: 'Invalid location data'
      };
    }
    
    // Add timestamp
    const safeLocation = {
      ...location,
      id: `location_${Date.now()}`,
      addedAt: new Date().toISOString()
    };
    
    // Add to safe locations
    this.state.privacySettings.safeLocations.push(safeLocation);
    
    // Enable location-based security if this is the first location
    if (this.state.privacySettings.safeLocations.length === 1) {
      this.state.privacySettings.locationBasedSecurity = true;
    }
    
    // Notify listeners
    this._notifyListeners('safeLocationAdded', {
      location: safeLocation,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true,
      location: safeLocation
    };
  }
  
  /**
   * Remove a safe location
   */
  removeSafeLocation(locationId) {
    const index = this.state.privacySettings.safeLocations.findIndex(loc => loc.id === locationId);
    
    if (index === -1) {
      return {
        success: false,
        error: 'Location not found'
      };
    }
    
    // Get location data before removing
    const location = this.state.privacySettings.safeLocations[index];
    
    // Remove location
    this.state.privacySettings.safeLocations.splice(index, 1);
    
    // Disable location-based security if no locations left
    if (this.state.privacySettings.safeLocations.length === 0) {
      this.state.privacySettings.locationBasedSecurity = false;
    }
    
    // Notify listeners
    this._notifyListeners('safeLocationRemoved', {
      locationId,
      locationName: location.name,
      timestamp: new Date().toISOString()
    });
    
    return {
      success: true
    };
  }
  
  /**
   * Check if current location is a safe location
   */
  async checkCurrentLocation() {
    // In a real app, this would check against the device's actual location
    // For the prototype, we'll simulate the check
    
    if (!this.state.privacySettings.locationBasedSecurity) {
      // Location-based security disabled
      return {
        locationBased: false
      };
    }
    
    // Simulate location check (50% chance of being in a safe location)
    const inSafeLocation = Math.random() > 0.5;
    
    if (inSafeLocation && this.state.privacySettings.safeLocations.length > 0) {
      // Randomly pick one of the safe locations
      const index = Math.floor(Math.random() * this.state.privacySettings.safeLocations.length);
      const location = this.state.privacySettings.safeLocations[index];
      
      return {
        locationBased: true,
        inSafeLocation: true,
        location
      };
    }
    
    return {
      locationBased: true,
      inSafeLocation: false
    };
  }
  
  /**
   * Update security settings
   */
  updateSettings(settings) {
    // Store old auto lock setting
    const previousAutoLock = this.state.privacySettings.autoLock;
    const previousDelay = this.state.privacySettings.autoLockDelay;
    
    // Update settings
    this.state.privacySettings = {
      ...this.state.privacySettings,
      ...settings
    };
    
    // Handle auto-lock changes
    if (!previousAutoLock && this.state.privacySettings.autoLock) {
      // Auto-lock was enabled, start timer
      this._startAutoLockTimer();
    } else if (previousAutoLock && !this.state.privacySettings.autoLock) {
      // Auto-lock was disabled, clear timer
      if (this.autoLockTimer) {
        clearTimeout(this.autoLockTimer);
        this.autoLockTimer = null;
      }
    } else if (previousDelay !== this.state.privacySettings.autoLockDelay && this.autoLockTimer) {
      // Auto-lock delay changed, restart timer
      this._startAutoLockTimer();
    }
    
    // Notify listeners
    this._notifyListeners('settingsUpdated', { 
      settings: this.state.privacySettings 
    });
    
    return true;
  }
  
  /**
   * Enable or disable biometric security
   */
  setEnabled(enabled) {
    this.state.enabled = enabled;
    
    // Notify listeners
    this._notifyListeners('enabledStateChanged', { enabled });
    
    return true;
  }
  
  /**
   * Get all secured apps
   */
  getSecuredApps() {
    return this.state.securedApps;
  }
  
  /**
   * Get all secured folders
   */
  getSecuredFolders() {
    return this.state.securedFolders;
  }
  
  /**
   * Get the current security settings
   */
  getSettings() {
    return this.state.privacySettings;
  }
  
  /**
   * Get authentication history
   */
  getAuthHistory() {
    return this.state.authHistory;
  }
  
  /**
   * Subscribe to biometric security events
   */
  subscribe(listener) {
    this.listeners.push(listener);
    return () => this.unsubscribe(listener);
  }
  
  /**
   * Unsubscribe from biometric security events
   */
  unsubscribe(listener) {
    this.listeners = this.listeners.filter(l => l !== listener);
  }
  
  /**
   * Notify all listeners of an event
   */
  _notifyListeners(event, data) {
    this.listeners.forEach(listener => {
      try {
        listener(event, data);
      } catch (error) {
        console.error('Error in biometric security service listener:', error);
      }
    });
  }
  
  /**
   * Set a mock authentication handler (for testing)
   */
  setMockAuthHandler(handler) {
    this.mockAuthHandler = handler;
  }
  
  /**
   * Clean up resources
   */
  cleanup() {
    if (this.autoLockTimer) {
      clearTimeout(this.autoLockTimer);
      this.autoLockTimer = null;
    }
    
    this.listeners = [];
  }
}

// Export as singleton
export const BiometricSecurityService = new BiometricSecurityServiceClass();