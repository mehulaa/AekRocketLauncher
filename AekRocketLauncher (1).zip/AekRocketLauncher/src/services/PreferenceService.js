// In-memory preference storage service

class PreferenceServiceClass {
  constructor() {
    this.preferences = {};
    this.listeners = {};
    this.initialized = false;
  }

  /**
   * Initialize the preference service
   */
  async initialize() {
    if (this.initialized) return true;
    
    // Load default preferences
    this.preferences = {
      // Theme preferences
      theme: 'default',
      customThemes: {},
      isDarkMode: false,
      accent: '#2196F3',
      
      // Layout preferences
      gridSize: { columns: 5, rows: 6 },
      iconSize: 'medium', // small, medium, large
      iconSpacing: 'normal', // compact, normal, spacious
      
      // Animation preferences
      animationSpeed: 'normal', // slow, normal, fast
      animationEffects: 'all', // minimal, moderate, all
      
      // Performance preferences
      performanceMode: 'balanced', // performance, balanced, quality
      enableBlur: true,
      enableReflections: true,
      
      // Gesture preferences
      customGestures: {},
      
      // 3D preferences
      depthEffect: 0.5, // 0.0 to 1.0
      rotationSensitivity: 0.5, // 0.0 to 1.0
      
      // Wallpaper preferences
      wallpaperType: 'static', // static, 3d, live
      wallpaperSettings: {},
      
      // Widget preferences
      widgets: [],
      widgetSettings: {},
    };
    
    // In a real app, we would load from storage here
    // For now, we'll just mark as initialized
    this.initialized = true;
    return true;
  }

  /**
   * Get an item from preferences
   */
  async getItem(key, defaultValue = null) {
    if (!this.initialized) await this.initialize();
    
    return this.preferences[key] !== undefined 
      ? this.preferences[key] 
      : defaultValue;
  }

  /**
   * Set an item in preferences
   */
  async setItem(key, value) {
    if (!this.initialized) await this.initialize();
    
    this.preferences[key] = value;
    
    // Notify listeners if any
    if (this.listeners[key]) {
      this.listeners[key].forEach(listener => listener(value));
    }
    
    // In a real app, we would persist to storage here
    return true;
  }

  /**
   * Remove an item from preferences
   */
  async removeItem(key) {
    if (!this.initialized) await this.initialize();
    
    if (this.preferences[key] !== undefined) {
      delete this.preferences[key];
      
      // Notify listeners of removal
      if (this.listeners[key]) {
        this.listeners[key].forEach(listener => listener(null));
      }
    }
    
    // In a real app, we would update storage here
    return true;
  }

  /**
   * Get all preferences
   */
  async getAllPreferences() {
    if (!this.initialized) await this.initialize();
    return { ...this.preferences };
  }

  /**
   * Subscribe to changes in a preference item
   */
  subscribe(key, callback) {
    if (!this.listeners[key]) {
      this.listeners[key] = [];
    }
    
    this.listeners[key].push(callback);
    
    // Return unsubscribe function
    return () => this.unsubscribe(key, callback);
  }

  /**
   * Unsubscribe from preference changes
   */
  unsubscribe(key, callback) {
    if (!this.listeners[key]) return;
    
    const index = this.listeners[key].indexOf(callback);
    if (index !== -1) {
      this.listeners[key].splice(index, 1);
    }
  }

  /**
   * Apply batch updates to preferences
   */
  async batchUpdate(updates) {
    if (!this.initialized) await this.initialize();
    
    for (const [key, value] of Object.entries(updates)) {
      this.preferences[key] = value;
      
      // Notify listeners
      if (this.listeners[key]) {
        this.listeners[key].forEach(listener => listener(value));
      }
    }
    
    // In a real app, we would persist all changes to storage here
    return true;
  }

  /**
   * Reset all preferences to default values
   */
  async resetToDefaults() {
    await this.initialize(); // This will reset to defaults
    
    // Notify all listeners
    for (const key in this.listeners) {
      if (this.listeners[key]) {
        const value = this.preferences[key];
        this.listeners[key].forEach(listener => listener(value));
      }
    }
    
    return true;
  }
}

// Export a singleton instance
export const PreferenceService = new PreferenceServiceClass();
