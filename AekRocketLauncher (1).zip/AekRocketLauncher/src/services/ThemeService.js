import { PreferenceService } from './PreferenceService';
import { SustainabilityService } from './SustainabilityService';

// Color palettes for theme generation
const COLOR_PALETTES = {
  material: {
    primary: ['#F44336', '#E91E63', '#9C27B0', '#673AB7', '#3F51B5', '#2196F3', '#03A9F4', '#00BCD4', '#009688', '#4CAF50', '#8BC34A', '#CDDC39', '#FFEB3B', '#FFC107', '#FF9800', '#FF5722'],
    accent: ['#FF5252', '#FF4081', '#E040FB', '#7C4DFF', '#536DFE', '#448AFF', '#40C4FF', '#18FFFF', '#64FFDA', '#69F0AE', '#B2FF59', '#EEFF41', '#FFFF00', '#FFD740', '#FFAB40', '#FF6E40'],
    neutralLight: ['#FAFAFA', '#F5F5F5', '#EEEEEE', '#E0E0E0', '#BDBDBD', '#9E9E9E'],
    neutralDark: ['#757575', '#616161', '#424242', '#212121', '#1A1A1A', '#121212', '#0A0A0A'],
  },
  retro: {
    primary: ['#DC965A', '#69479E', '#5D98D2', '#7E4BD4', '#BF8ADF', '#DE7254', '#D8573E', '#007F7C', '#B3DEE2', '#FAA275', '#CC3363', '#96C582'],
    accent: ['#F1BB50', '#F78D28', '#F4743B', '#FC5C65', '#D19FE8', '#43B5A0', '#3D5B94', '#FF5E78', '#28CF75', '#FE9000', '#AFD9B3', '#F5A623'],
    background: ['#211F30', '#2C2640', '#645D82', '#192E40', '#3B3075', '#4D3C77', '#3F263C', '#2A2B2A', '#37495C', '#4B2D2D', '#27282D', '#313A3E'],
    text: ['#E6E6E8', '#F5F4F0', '#ECE1DC', '#F0DFD1', '#EBEAEA', '#DED4CB', '#F0EFED', '#E3DDD5', '#F5E9D6', '#EBE8E1', '#F2F2F2', '#DBD7D0'],
  },
  nature: {
    green: ['#A8E890', '#BFDB38', '#9DC08B', '#609966', '#40513B', '#48764A', '#71B340', '#ACE1AF', '#7EB77F', '#C3E5AE', '#8AAE92', '#4F7942'],
    earth: ['#F1DEC9', '#D3C4BE', '#D4A373', '#C8B6A6', '#A4907C', '#8D7B68', '#C8AE7D', '#EFECCA', '#D9CAB3', '#E6BEAE', '#DEC3A5', '#EAD7BB'],
    sky: ['#A0E9FF', '#89CFF0', '#73C2FB', '#5B9BD5', '#0492C2', '#1A5D7A', '#6AB1CF', '#4A9BD6', '#7EB6FF', '#44BBFF', '#0C8DE8', '#51ADCF'],
    sunset: ['#FFB347', '#FF7F50', '#FF6B6B', '#FFDAB9', '#FF8551', '#FDCA40', '#F9A03F', '#F76E11', '#FF5200', '#F4845F', '#F7C5A8', '#FBB454'],
  },
  vibrant: {
    primary: ['#FF2E63', '#08D9D6', '#49FF00', '#FFFC31', '#FC5185', '#3FEEE6', '#55BCC9', '#FC8621', '#3E64FF', '#D82148', '#7DEDFF', '#F6C90E'],
    secondary: ['#252A34', '#272343', '#541690', '#3A015C', '#200E3A', '#341948', '#130B2B', '#201335', '#0C0A3E', '#2B2F77', '#2A1A5E', '#1B1734'],
    accent: ['#7A0BC0', '#FA1E0E', '#00FFAB', '#A8FF3E', '#FF65C3', '#23B2EE', '#F5C7F7', '#67B99A', '#FFF76A', '#FFFAA2', '#D9D7F1', '#FFDB89'],
  },
  monochrome: {
    white: ['#FFFFFF', '#F9F9F9', '#F5F5F5', '#EEEEEE', '#E0E0E0', '#D6D6D6', '#CCCCCC', '#C2C2C2', '#BBBBBB', '#AAAAAA'],
    black: ['#999999', '#888888', '#777777', '#666666', '#555555', '#444444', '#333333', '#222222', '#111111', '#000000'],
  },
  indian: {
    primary: ['#FF9933', '#138808', '#9C27B0', '#673AB7', '#3F51B5', '#2196F3', '#03A9F4', '#00BCD4', '#009688', '#4CAF50', '#8BC34A', '#CDDC39', '#FFEB3B', '#FFC107', '#FF9800', '#FF5722'],
    accent: ['#FF5252', '#FF4081', '#E040FB', '#7C4DFF', '#536DFE', '#448AFF', '#40C4FF', '#18FFFF', '#64FFDA', '#69F0AE', '#B2FF59', '#EEFF41', '#FFFF00', '#FFD740', '#FFAB40', '#FF6E40'],
    neutralLight: ['#FAFAFA', '#F5F5F5', '#EEEEEE', '#E0E0E0', '#BDBDBD', '#9E9E9E'],
    neutralDark: ['#757575', '#616161', '#424242', '#212121', '#1A1A1A', '#121212', '#0A0A0A'],
  }
};

// Font families by category
const FONT_FAMILIES = {
  system: ['System', 'System-UI', 'Roboto', 'San Francisco', 'Segoe UI'],
  serif: ['Times New Roman', 'Georgia', 'Garamond', 'Palatino', 'Baskerville'],
  sansSerif: ['Helvetica', 'Arial', 'Verdana', 'Tahoma', 'Trebuchet MS'],
  monospace: ['Courier New', 'Consolas', 'Monaco', 'Lucida Console', 'Roboto Mono'],
  display: ['Impact', 'Comic Sans MS', 'Bahnschrift', 'Rockwell', 'Gill Sans'],
  handwriting: ['Brush Script MT', 'Lucida Handwriting', 'Segoe Script', 'Bradley Hand', 'Pacifico'],
  indian: ['Devanagari', 'Nirmala UI', 'Mangal', 'Aparajita', 'Utsaah', 'Kokila']
};

// Define default themes
const DEFAULT_THEMES = {
  default: {
    id: 'default',
    name: 'Default Theme',
    isDark: false,
    backgroundColor: '#F5F5F5',
    primaryColor: '#2196F3',
    secondaryColor: '#FFC107',
    textColor: '#212121',
    accentColor: '#FF4081',
    cardColor: '#FFFFFF',
    shadowColor: 'rgba(0, 0, 0, 0.1)',
    iconStyle: 'flat', // flat, realistic, minimal, glowing
    borderRadius: 8,
    fontFamily: 'System',
    animationStyle: 'bounce', // bounce, elastic, smooth, minimal
    iconOpacity: 1.0,
    blurEffects: true,
    textShadows: false,
    glassmorphism: false,
    gradients: false,
    folderStyle: 'rounded', // rounded, square, circular, custom
    iconSize: 'medium', // small, medium, large
    hapticFeedback: true,
    soundEffects: false,
    category: 'material'
  },
  dark: {
    id: 'dark',
    name: 'Dark Theme',
    isDark: true,
    backgroundColor: '#121212',
    primaryColor: '#BB86FC',
    secondaryColor: '#03DAC6',
    textColor: '#E1E1E1',
    accentColor: '#CF6679',
    cardColor: '#1E1E1E',
    shadowColor: 'rgba(0, 0, 0, 0.2)',
    iconStyle: 'flat',
    borderRadius: 8,
    fontFamily: 'System',
    animationStyle: 'smooth',
    iconOpacity: 0.9,
    blurEffects: true,
    textShadows: false,
    glassmorphism: false,
    gradients: false,
    folderStyle: 'rounded',
    iconSize: 'medium',
    hapticFeedback: true,
    soundEffects: false,
    category: 'material'
  },
  neon: {
    id: 'neon',
    name: 'Neon Theme',
    isDark: true,
    backgroundColor: '#0A0A0A',
    primaryColor: '#FF00FF',
    secondaryColor: '#00FFFF',
    textColor: '#FFFFFF',
    accentColor: '#FFFF00',
    cardColor: '#1A1A1A',
    shadowColor: 'rgba(255, 0, 255, 0.5)',
    iconStyle: 'glowing',
    borderRadius: 12,
    fontFamily: 'System',
    animationStyle: 'elastic',
    iconOpacity: 1.0,
    blurEffects: true,
    textShadows: true,
    glassmorphism: false,
    gradients: true,
    folderStyle: 'rounded',
    iconSize: 'large',
    hapticFeedback: true,
    soundEffects: true,
    category: 'vibrant'
  },
  minimalist: {
    id: 'minimalist',
    name: 'Minimalist Theme',
    isDark: false,
    backgroundColor: '#FFFFFF',
    primaryColor: '#000000',
    secondaryColor: '#CCCCCC',
    textColor: '#333333',
    accentColor: '#666666',
    cardColor: '#F9F9F9',
    shadowColor: 'rgba(0, 0, 0, 0.05)',
    iconStyle: 'minimal',
    borderRadius: 4,
    fontFamily: 'System',
    animationStyle: 'minimal',
    iconOpacity: 0.85,
    blurEffects: false,
    textShadows: false,
    glassmorphism: false,
    gradients: false,
    folderStyle: 'square',
    iconSize: 'small',
    hapticFeedback: false,
    soundEffects: false,
    category: 'monochrome'
  },
  nature: {
    id: 'nature',
    name: 'Nature Theme',
    isDark: false,
    backgroundColor: '#F1DEC9',
    primaryColor: '#8D7B68',
    secondaryColor: '#A4907C',
    textColor: '#40513B',
    accentColor: '#609966',
    cardColor: '#C8B6A6',
    shadowColor: 'rgba(64, 81, 59, 0.2)',
    iconStyle: 'flat',
    borderRadius: 12,
    fontFamily: 'Georgia',
    animationStyle: 'smooth',
    iconOpacity: 0.95,
    blurEffects: true,
    textShadows: false,
    glassmorphism: true,
    gradients: true,
    folderStyle: 'circular',
    iconSize: 'medium',
    hapticFeedback: true,
    soundEffects: true,
    category: 'nature'
  },
  retro: {
    id: 'retro',
    name: 'Retro Theme',
    isDark: true,
    backgroundColor: '#2C2640',
    primaryColor: '#F78D28',
    secondaryColor: '#5D98D2',
    textColor: '#F0EFED',
    accentColor: '#F4743B',
    cardColor: '#3B3075',
    shadowColor: 'rgba(42, 38, 64, 0.5)',
    iconStyle: 'realistic',
    borderRadius: 0,
    fontFamily: 'Courier New',
    animationStyle: 'bounce',
    iconOpacity: 1.0,
    blurEffects: false,
    textShadows: true,
    glassmorphism: false,
    gradients: false,
    folderStyle: 'square',
    iconSize: 'large',
    hapticFeedback: true,
    soundEffects: true,
    category: 'retro'
  },
  glass: {
    id: 'glass',
    name: 'Glass Theme',
    isDark: false,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    primaryColor: 'rgba(33, 150, 243, 0.8)',
    secondaryColor: 'rgba(255, 193, 7, 0.8)',
    textColor: '#333333',
    accentColor: 'rgba(255, 64, 129, 0.9)',
    cardColor: 'rgba(255, 255, 255, 0.4)',
    shadowColor: 'rgba(0, 0, 0, 0.05)',
    iconStyle: 'flat',
    borderRadius: 16,
    fontFamily: 'System',
    animationStyle: 'smooth',
    iconOpacity: 0.9,
    blurEffects: true,
    textShadows: false,
    glassmorphism: true,
    gradients: true,
    folderStyle: 'circular',
    iconSize: 'medium',
    hapticFeedback: true,
    soundEffects: false,
    category: 'material'
  },
  indian: {
    id: 'indian',
    name: 'Indian Theme',
    isDark: false,
    backgroundColor: '#FFFFFF',
    primaryColor: '#FF9933', // Saffron
    secondaryColor: '#138808', // Green
    textColor: '#000080', // Navy Blue
    accentColor: '#4B0082', // Indigo
    cardColor: '#F4F4F4',
    shadowColor: 'rgba(0, 0, 0, 0.1)',
    iconStyle: 'flat',
    borderRadius: 10,
    fontFamily: 'Nirmala UI',
    animationStyle: 'bounce',
    iconOpacity: 1.0,
    blurEffects: true,
    textShadows: false,
    glassmorphism: false,
    gradients: true,
    folderStyle: 'rounded',
    iconSize: 'medium',
    hapticFeedback: true,
    soundEffects: false,
    category: 'indian'
  },
  bollywood: {
    id: 'bollywood',
    name: 'Bollywood Theme',
    isDark: false,
    backgroundColor: '#FFF8E1',
    primaryColor: '#D81B60', // Pink
    secondaryColor: '#FFC107', // Gold/Yellow
    textColor: '#311B92', // Deep Purple
    accentColor: '#00BFA5', // Teal
    cardColor: '#FFECB3',
    shadowColor: 'rgba(0, 0, 0, 0.15)',
    iconStyle: 'glowing',
    borderRadius: 15,
    fontFamily: 'Utsaah',
    animationStyle: 'elastic',
    iconOpacity: 1.0,
    blurEffects: true,
    textShadows: true,
    glassmorphism: false,
    gradients: true,
    folderStyle: 'circular',
    iconSize: 'large',
    hapticFeedback: true,
    soundEffects: true,
    category: 'indian'
  },
  ecoFriendly: {
    id: 'ecoFriendly',
    name: 'Eco-Friendly Theme',
    isDark: false,
    backgroundColor: '#F1F8E9',
    primaryColor: '#689F38',
    secondaryColor: '#8BC34A',
    textColor: '#33691E',
    accentColor: '#3E5641',
    cardColor: '#DCEDC8',
    shadowColor: 'rgba(51, 105, 30, 0.1)',
    iconStyle: 'minimal',
    borderRadius: 12,
    fontFamily: 'System',
    animationStyle: 'smooth',
    iconOpacity: 0.9,
    blurEffects: false,
    textShadows: false,
    glassmorphism: false,
    gradients: false,
    folderStyle: 'rounded',
    iconSize: 'medium',
    hapticFeedback: true,
    soundEffects: false,
    category: 'nature',
    powerSaving: true
  }
};

class ThemeServiceClass {
  constructor() {
    this.currentTheme = DEFAULT_THEMES.default;
    this.customThemes = {};
    this.themeListeners = [];
  }

  /**
   * Initialize the theme service
   */
  async initialize() {
    try {
      // Get theme preference
      const themeId = await PreferenceService.getItem('theme', 'default');
      
      // Get custom themes
      const customThemesJson = await PreferenceService.getItem('customThemes', '{}');
      this.customThemes = JSON.parse(customThemesJson);
      
      // Set the current theme
      await this.setTheme(themeId);
      
      return true;
    } catch (error) {
      console.error('Failed to initialize ThemeService:', error);
      this.currentTheme = DEFAULT_THEMES.default;
      return false;
    }
  }

  /**
   * Get all available themes (default + custom)
   */
  getAllThemes() {
    return {
      ...DEFAULT_THEMES,
      ...this.customThemes
    };
  }

  /**
   * Get the current active theme
   */
  async getCurrentTheme() {
    return this.currentTheme;
  }

  /**
   * Set the active theme
   */
  async setTheme(themeId) {
    const allThemes = this.getAllThemes();
    
    if (allThemes[themeId]) {
      this.currentTheme = allThemes[themeId];
      await PreferenceService.setItem('theme', themeId);
      
      // Notify listeners
      this._notifyThemeListeners(this.currentTheme);
      return true;
    }
    
    return false;
  }

  /**
   * Create a new custom theme
   */
  async createCustomTheme(theme) {
    if (!theme.id || !theme.name) {
      throw new Error('Theme must have an id and name');
    }
    
    // Store the custom theme
    this.customThemes[theme.id] = theme;
    
    // Save to preferences
    await PreferenceService.setItem('customThemes', JSON.stringify(this.customThemes));
    
    return theme;
  }

  /**
   * Update an existing custom theme
   */
  async updateCustomTheme(theme) {
    if (!theme.id || !theme.name) {
      throw new Error('Theme must have an id and name');
    }
    
    // Check if theme exists and is a custom theme
    if (!this.customThemes[theme.id] && !DEFAULT_THEMES[theme.id]) {
      throw new Error(`Theme with id ${theme.id} does not exist`);
    }
    
    // Can't modify default themes
    if (DEFAULT_THEMES[theme.id]) {
      throw new Error('Cannot modify default themes');
    }
    
    // Update the theme
    this.customThemes[theme.id] = theme;
    
    // Save to preferences
    await PreferenceService.setItem('customThemes', JSON.stringify(this.customThemes));
    
    // If this is the current theme, update it
    if (this.currentTheme.id === theme.id) {
      this.currentTheme = theme;
      this._notifyThemeListeners(this.currentTheme);
    }
    
    return theme;
  }

  /**
   * Delete a custom theme
   */
  async deleteCustomTheme(themeId) {
    // Check if theme exists and is a custom theme
    if (!this.customThemes[themeId]) {
      throw new Error(`Custom theme with id ${themeId} does not exist`);
    }
    
    // If this is the current theme, switch to default
    if (this.currentTheme.id === themeId) {
      await this.setTheme('default');
    }
    
    // Delete the theme
    delete this.customThemes[themeId];
    
    // Save to preferences
    await PreferenceService.setItem('customThemes', JSON.stringify(this.customThemes));
    
    return true;
  }

  /**
   * Create a copy of an existing theme as a new custom theme
   */
  async cloneTheme(sourceThemeId, newName) {
    const allThemes = this.getAllThemes();
    const sourceTheme = allThemes[sourceThemeId];
    
    if (!sourceTheme) {
      throw new Error(`Theme with id ${sourceThemeId} does not exist`);
    }
    
    const newThemeId = `custom_${Date.now()}`;
    const newTheme = {
      ...sourceTheme,
      id: newThemeId,
      name: newName || `Copy of ${sourceTheme.name}`,
    };
    
    return this.createCustomTheme(newTheme);
  }

  /**
   * Subscribe to theme changes
   */
  subscribeToThemeChanges(callback) {
    this.themeListeners.push(callback);
    
    // Return unsubscribe function
    return () => this.unsubscribeFromThemeChanges(callback);
  }

  /**
   * Unsubscribe from theme changes
   */
  unsubscribeFromThemeChanges(callback) {
    const index = this.themeListeners.indexOf(callback);
    if (index !== -1) {
      this.themeListeners.splice(index, 1);
    }
  }

  /**
   * Notify all theme listeners
   */
  _notifyThemeListeners(theme) {
    this.themeListeners.forEach(listener => listener(theme));
  }
}

// Export a singleton instance
export const ThemeService = new ThemeServiceClass();
