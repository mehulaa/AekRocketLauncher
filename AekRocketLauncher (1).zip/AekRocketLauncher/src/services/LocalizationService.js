/**
 * Localization Service
 * Provides multi-language support with emphasis on Indian languages
 */

import { PreferenceService } from './PreferenceService';

// Supported languages
const SUPPORTED_LANGUAGES = {
  en: {
    code: 'en',
    name: 'English',
    nativeName: 'English',
    direction: 'ltr',
    region: 'global'
  },
  hi: {
    code: 'hi',
    name: 'Hindi',
    nativeName: 'हिन्दी',
    direction: 'ltr',
    region: 'india'
  },
  bn: {
    code: 'bn',
    name: 'Bengali',
    nativeName: 'বাংলা',
    direction: 'ltr',
    region: 'india'
  },
  te: {
    code: 'te',
    name: 'Telugu',
    nativeName: 'తెలుగు',
    direction: 'ltr',
    region: 'india'
  },
  ta: {
    code: 'ta',
    name: 'Tamil',
    nativeName: 'தமிழ்',
    direction: 'ltr',
    region: 'india'
  },
  mr: {
    code: 'mr',
    name: 'Marathi',
    nativeName: 'मराठी',
    direction: 'ltr',
    region: 'india'
  },
  gu: {
    code: 'gu',
    name: 'Gujarati',
    nativeName: 'ગુજરાતી',
    direction: 'ltr',
    region: 'india'
  },
  kn: {
    code: 'kn',
    name: 'Kannada',
    nativeName: 'ಕನ್ನಡ',
    direction: 'ltr',
    region: 'india'
  },
  ml: {
    code: 'ml',
    name: 'Malayalam',
    nativeName: 'മലയാളം',
    direction: 'ltr',
    region: 'india'
  },
  pa: {
    code: 'pa',
    name: 'Punjabi',
    nativeName: 'ਪੰਜਾਬੀ',
    direction: 'ltr',
    region: 'india'
  },
  ur: {
    code: 'ur',
    name: 'Urdu',
    nativeName: 'اردو',
    direction: 'rtl',
    region: 'india'
  },
  or: {
    code: 'or',
    name: 'Odia',
    nativeName: 'ଓଡ଼ିଆ',
    direction: 'ltr',
    region: 'india'
  },
  as: {
    code: 'as',
    name: 'Assamese',
    nativeName: 'অসমীয়া',
    direction: 'ltr',
    region: 'india'
  },
  // Other global languages
  es: {
    code: 'es',
    name: 'Spanish',
    nativeName: 'Español',
    direction: 'ltr',
    region: 'global'
  },
  fr: {
    code: 'fr',
    name: 'French',
    nativeName: 'Français',
    direction: 'ltr',
    region: 'global'
  },
  de: {
    code: 'de',
    name: 'German',
    nativeName: 'Deutsch',
    direction: 'ltr',
    region: 'global'
  },
  ja: {
    code: 'ja',
    name: 'Japanese',
    nativeName: '日本語',
    direction: 'ltr',
    region: 'global'
  },
  zh: {
    code: 'zh',
    name: 'Chinese (Simplified)',
    nativeName: '中文',
    direction: 'ltr',
    region: 'global'
  },
  ar: {
    code: 'ar',
    name: 'Arabic',
    nativeName: 'العربية',
    direction: 'rtl',
    region: 'global'
  },
  ru: {
    code: 'ru',
    name: 'Russian',
    nativeName: 'Русский',
    direction: 'ltr',
    region: 'global'
  },
  // Add more languages as needed
};

// Common phrases used across the app (English as default)
const DEFAULT_TRANSLATIONS = {
  // App drawer and navigation
  'app.drawer.title': 'All Apps',
  'app.search.placeholder': 'Search apps...',
  'app.categories.title': 'Categories',
  'app.favorites.title': 'Favorites',
  'app.recent.title': 'Recent',
  'app.folder.new': 'New Folder',
  'app.folder.edit': 'Edit Folder',
  'app.settings.title': 'Settings',
  
  // Settings sections
  'settings.general': 'General',
  'settings.appearance': 'Appearance',
  'settings.themes': 'Themes',
  'settings.language': 'Language',
  'settings.gestures': 'Gestures',
  'settings.backup': 'Backup & Restore',
  'settings.about': 'About',
  'settings.help': 'Help & Support',
  'settings.advanced': 'Advanced',
  'settings.privacy': 'Privacy & Security',
  'settings.sustainability': 'Sustainability',
  
  // Theme settings
  'themes.select': 'Select Theme',
  'themes.create': 'Create Theme',
  'themes.edit': 'Edit Theme',
  'themes.delete': 'Delete Theme',
  'themes.customize': 'Customize',
  'themes.name': 'Theme Name',
  'themes.colors': 'Colors',
  'themes.fonts': 'Fonts',
  'themes.effects': 'Effects',
  'themes.icons': 'Icons',
  'themes.wallpaper': 'Wallpaper',
  
  // 3D Settings
  '3d.effects': '3D Effects',
  '3d.quality': 'Quality',
  '3d.animations': 'Animations',
  '3d.depth': 'Depth Effect',
  '3d.particle': 'Particle Effects',
  '3d.lighting': 'Lighting',
  '3d.shadows': 'Shadows',
  '3d.reflections': 'Reflections',
  
  // Performance settings
  'performance.level': 'Performance Level',
  'performance.battery': 'Battery Optimization',
  'performance.memory': 'Memory Optimization',
  'performance.graphics': 'Graphics Optimization',
  'performance.auto': 'Auto Adjust',
  'performance.stats': 'Performance Stats',
  
  // Common actions
  'action.save': 'Save',
  'action.cancel': 'Cancel',
  'action.delete': 'Delete',
  'action.edit': 'Edit',
  'action.add': 'Add',
  'action.remove': 'Remove',
  'action.confirm': 'Confirm',
  'action.back': 'Back',
  'action.next': 'Next',
  'action.finish': 'Finish',
  'action.enable': 'Enable',
  'action.disable': 'Disable',
  'action.customize': 'Customize',
  'action.reset': 'Reset',
  'action.update': 'Update',
  'action.share': 'Share',
  
  // Dialog messages
  'dialog.confirm.delete': 'Are you sure you want to delete this?',
  'dialog.confirm.reset': 'Are you sure you want to reset to default settings?',
  'dialog.unsaved': 'You have unsaved changes. Do you want to save them?',
  'dialog.processing': 'Processing...',
  'dialog.success': 'Completed successfully',
  'dialog.error': 'An error occurred',
  
  // Errors and notifications
  'error.unknown': 'Unknown error occurred',
  'error.connection': 'Connection error',
  'error.permission': 'Permission denied',
  'notification.new': 'New notification',
  'notification.clear': 'Clear all notifications',
  
  // Sustainability
  'sustainability.title': 'Sustainability',
  'sustainability.savings': 'Energy Savings',
  'sustainability.battery': 'Battery Impact',
  'sustainability.eco_theme': 'Eco Theme',
  'sustainability.tips': 'Eco Tips',
  'sustainability.metrics': 'Eco Metrics',
  
  // Accessibility
  'accessibility.title': 'Accessibility',
  'accessibility.text_size': 'Text Size',
  'accessibility.contrast': 'High Contrast',
  'accessibility.tts': 'Text to Speech',
  'accessibility.gestures': 'Accessibility Gestures',
  
  // Voice commands
  'voice.commands': 'Voice Commands',
  'voice.listening': 'Listening...',
  'voice.command_list': 'Available Commands',
  'voice.help': 'Say "help" for assistance',
  
  // AR features
  'ar.title': 'AR Features',
  'ar.preview': 'AR Preview',
  'ar.navigation': 'AR Navigation',
  'ar.place_markers': 'Place Markers',
  
  // Community features
  'community.title': 'Community',
  'community.themes': 'Community Themes',
  'community.share': 'Share Your Creation',
  'community.trending': 'Trending',
  'community.downloads': 'My Downloads',
  
  // Gestures
  'gestures.title': 'Gestures',
  'gestures.swipe': 'Swipe',
  'gestures.pinch': 'Pinch',
  'gestures.rotate': 'Rotate',
  'gestures.custom': 'Custom Gestures',
  'gestures.add': 'Add Gesture',
  
  // App-specific
  'app.info': 'App Info',
  'app.uninstall': 'Uninstall',
  'app.hide': 'Hide App',
  'app.lock': 'Lock App',
  'app.shortcut': 'Create Shortcut',
  
  // Time-based greetings
  'greeting.morning': 'Good Morning',
  'greeting.afternoon': 'Good Afternoon',
  'greeting.evening': 'Good Evening',
  'greeting.night': 'Good Night',
  
  // Days of week
  'day.monday': 'Monday',
  'day.tuesday': 'Tuesday',
  'day.wednesday': 'Wednesday',
  'day.thursday': 'Thursday',
  'day.friday': 'Friday',
  'day.saturday': 'Saturday',
  'day.sunday': 'Sunday',
  
  // Months
  'month.january': 'January',
  'month.february': 'February',
  'month.march': 'March',
  'month.april': 'April',
  'month.may': 'May',
  'month.june': 'June',
  'month.july': 'July',
  'month.august': 'August',
  'month.september': 'September',
  'month.october': 'October',
  'month.november': 'November',
  'month.december': 'December',
  
  // Widget related
  'widget.add': 'Add Widget',
  'widget.edit': 'Edit Widget',
  'widget.remove': 'Remove Widget',
  'widget.resize': 'Resize Widget',
  'widget.configure': 'Configure',
  
  // Welcome and onboarding
  'welcome.title': 'Welcome to 3D Launcher',
  'welcome.subtitle': 'Let\'s set up your new launcher',
  'welcome.theme': 'Choose a theme',
  'welcome.layout': 'Select layout',
  'welcome.finish': 'Get Started',
  'welcome.permissions': 'Required Permissions',
  
  // In-app help
  'help.tips': 'Tips & Tricks',
  'help.faq': 'FAQ',
  'help.contact': 'Contact Support',
  'help.tutorial': 'Tutorial',
  'help.shortcuts': 'Keyboard Shortcuts',
};

// Language-specific translations (to be implemented for each language)
const TRANSLATIONS = {
  en: DEFAULT_TRANSLATIONS,
  hi: {
    // Hindi translations
    'app.drawer.title': 'सभी ऐप्स',
    'app.search.placeholder': 'ऐप्स खोजें...',
    'app.categories.title': 'श्रेणियाँ',
    'app.favorites.title': 'पसंदीदा',
    'app.recent.title': 'हाल के',
    'app.folder.new': 'नया फोल्डर',
    'app.folder.edit': 'फोल्डर संपादित करें',
    'app.settings.title': 'सेटिंग्स',
    
    // Settings sections
    'settings.general': 'सामान्य',
    'settings.appearance': 'उपस्थिति',
    'settings.themes': 'थीम्स',
    'settings.language': 'भाषा',
    'settings.gestures': 'जेस्चर',
    'settings.backup': 'बैकअप और रिस्टोर',
    'settings.about': 'जानकारी',
    'settings.help': 'सहायता और समर्थन',
    'settings.advanced': 'उन्नत',
    'settings.privacy': 'गोपनीयता और सुरक्षा',
    'settings.sustainability': 'संपोषणीयता',
    
    // Theme settings
    'themes.select': 'थीम चुनें',
    'themes.create': 'थीम बनाएं',
    'themes.edit': 'थीम संपादित करें',
    'themes.delete': 'थीम हटाएं',
    'themes.customize': 'अनुकूलित करें',
    'themes.name': 'थीम का नाम',
    'themes.colors': 'रंग',
    'themes.fonts': 'फॉन्ट',
    'themes.effects': 'प्रभाव',
    'themes.icons': 'आइकन',
    'themes.wallpaper': 'वॉलपेपर',
    
    // 3D Settings
    '3d.effects': '3D प्रभाव',
    '3d.quality': 'गुणवत्ता',
    '3d.animations': 'एनिमेशन',
    '3d.depth': 'गहराई प्रभाव',
    '3d.particle': 'कण प्रभाव',
    '3d.lighting': 'प्रकाश व्यवस्था',
    '3d.shadows': 'छाया',
    '3d.reflections': 'परावर्तन',
    
    // Performance settings
    'performance.level': 'प्रदर्शन स्तर',
    'performance.battery': 'बैटरी अनुकूलन',
    'performance.memory': 'मेमोरी अनुकूलन',
    'performance.graphics': 'ग्राफिक्स अनुकूलन',
    'performance.auto': 'स्वत: समायोजित करें',
    'performance.stats': 'प्रदर्शन आँकड़े',
    
    // Common actions
    'action.save': 'सहेजें',
    'action.cancel': 'रद्द करें',
    'action.delete': 'हटाएं',
    'action.edit': 'संपादित करें',
    'action.add': 'जोड़ें',
    'action.remove': 'हटाएं',
    'action.confirm': 'पुष्टि करें',
    'action.back': 'पीछे',
    'action.next': 'अगला',
    'action.finish': 'समाप्त',
    'action.enable': 'सक्षम करें',
    'action.disable': 'अक्षम करें',
    'action.customize': 'अनुकूलित करें',
    'action.reset': 'रीसेट',
    'action.update': 'अपडेट',
    'action.share': 'शेयर करें',
    
    // Dialog messages
    'dialog.confirm.delete': 'क्या आप वाकई इसे हटाना चाहते हैं?',
    'dialog.confirm.reset': 'क्या आप वाकई डिफ़ॉल्ट सेटिंग्स पर रीसेट करना चाहते हैं?',
    'dialog.unsaved': 'आपके पास बिना सहेजे हुए परिवर्तन हैं। क्या आप उन्हें सहेजना चाहते हैं?',
    'dialog.processing': 'प्रक्रिया चल रही है...',
    'dialog.success': 'सफलतापूर्वक पूरा हुआ',
    'dialog.error': 'एक त्रुटि हुई',
    
    // Errors and notifications
    'error.unknown': 'अज्ञात त्रुटि हुई',
    'error.connection': 'कनेक्शन त्रुटि',
    'error.permission': 'अनुमति से वंचित',
    'notification.new': 'नई सूचना',
    'notification.clear': 'सभी सूचनाएँ हटाएं',
    
    // Sustainability
    'sustainability.title': 'संपोषणीयता',
    'sustainability.savings': 'ऊर्जा बचत',
    'sustainability.battery': 'बैटरी प्रभाव',
    'sustainability.eco_theme': 'इको थीम',
    'sustainability.tips': 'इको टिप्स',
    'sustainability.metrics': 'इको मेट्रिक्स',
    
    // Accessibility
    'accessibility.title': 'अभिगम्यता',
    'accessibility.text_size': 'टेक्स्ट का आकार',
    'accessibility.contrast': 'उच्च कंट्रास्ट',
    'accessibility.tts': 'टेक्स्ट से स्पीच',
    'accessibility.gestures': 'अभिगम्यता जेस्चर',
    
    // Voice commands
    'voice.commands': 'आवाज कमांड',
    'voice.listening': 'सुन रहा है...',
    'voice.command_list': 'उपलब्ध कमांड',
    'voice.help': 'सहायता के लिए "help" कहें',
    
    // AR features
    'ar.title': 'AR सुविधाएँ',
    'ar.preview': 'AR प्रीव्यू',
    'ar.navigation': 'AR नेविगेशन',
    'ar.place_markers': 'प्लेस मार्कर्स',
    
    // Community features
    'community.title': 'समुदाय',
    'community.themes': 'समुदाय थीम',
    'community.share': 'अपनी रचना साझा करें',
    'community.trending': 'ट्रेंडिंग',
    'community.downloads': 'मेरे डाउनलोड्स',
    
    // Gestures
    'gestures.title': 'जेस्चर',
    'gestures.swipe': 'स्वाइप',
    'gestures.pinch': 'पिंच',
    'gestures.rotate': 'रोटेट',
    'gestures.custom': 'कस्टम जेस्चर',
    'gestures.add': 'जेस्चर जोड़ें',
    
    // App-specific
    'app.info': 'ऐप जानकारी',
    'app.uninstall': 'अनइंस्टॉल',
    'app.hide': 'ऐप छिपाएं',
    'app.lock': 'ऐप लॉक करें',
    'app.shortcut': 'शॉर्टकट बनाएं',
    
    // Time-based greetings
    'greeting.morning': 'सुप्रभात',
    'greeting.afternoon': 'शुभ दोपहर',
    'greeting.evening': 'शुभ संध्या',
    'greeting.night': 'शुभ रात्रि',
    
    // Days of week
    'day.monday': 'सोमवार',
    'day.tuesday': 'मंगलवार',
    'day.wednesday': 'बुधवार',
    'day.thursday': 'गुरुवार',
    'day.friday': 'शुक्रवार',
    'day.saturday': 'शनिवार',
    'day.sunday': 'रविवार',
    
    // Months
    'month.january': 'जनवरी',
    'month.february': 'फरवरी',
    'month.march': 'मार्च',
    'month.april': 'अप्रैल',
    'month.may': 'मई',
    'month.june': 'जून',
    'month.july': 'जुलाई',
    'month.august': 'अगस्त',
    'month.september': 'सितंबर',
    'month.october': 'अक्टूबर',
    'month.november': 'नवंबर',
    'month.december': 'दिसंबर',
    
    // Widget related
    'widget.add': 'विजेट जोड़ें',
    'widget.edit': 'विजेट संपादित करें',
    'widget.remove': 'विजेट हटाएं',
    'widget.resize': 'विजेट का आकार बदलें',
    'widget.configure': 'कॉन्फ़िगर करें',
    
    // Welcome and onboarding
    'welcome.title': '3D लॉन्चर में आपका स्वागत है',
    'welcome.subtitle': 'आइए आपका नया लॉन्चर सेट करें',
    'welcome.theme': 'थीम चुनें',
    'welcome.layout': 'लेआउट चुनें',
    'welcome.finish': 'शुरू करें',
    'welcome.permissions': 'आवश्यक अनुमतियां',
    
    // In-app help
    'help.tips': 'टिप्स और ट्रिक्स',
    'help.faq': 'अक्सर पूछे जाने वाले प्रश्न',
    'help.contact': 'सपोर्ट से संपर्क करें',
    'help.tutorial': 'ट्यूटोरियल',
    'help.shortcuts': 'कीबोर्ड शॉर्टकट',
  },
  bn: {
    // Bengali translations (partial)
    'app.drawer.title': 'সমস্ত অ্যাপস',
    'app.search.placeholder': 'অ্যাপস খুঁজুন...',
    'app.categories.title': 'বিভাগসমূহ',
    'app.favorites.title': 'পছন্দসই',
    'app.settings.title': 'সেটিংস',
    
    // Common actions
    'action.save': 'সংরক্ষণ করুন',
    'action.cancel': 'বাতিল করুন',
    'action.delete': 'মুছুন',
    'action.edit': 'সম্পাদনা করুন',
  },
  // Additional translations for other languages would be implemented here
};

class LocalizationServiceClass {
  constructor() {
    this.currentLanguage = 'en';
    this.fallbackLanguage = 'en';
    this.translations = TRANSLATIONS;
    this.localizationListeners = [];
    this.dateTimeFormat = null;
    this.numberFormat = null;
  }

  /**
   * Initialize the localization service
   */
  async initialize() {
    try {
      // Get language preference or detect from device
      const languageCode = await PreferenceService.getItem('language', 'en');
      await this.setLanguage(languageCode);
      
      return true;
    } catch (error) {
      console.error('Failed to initialize LocalizationService:', error);
      this.currentLanguage = 'en';
      return false;
    }
  }

  /**
   * Get all supported languages
   */
  getSupportedLanguages() {
    return SUPPORTED_LANGUAGES;
  }

  /**
   * Get all Indian languages
   */
  getIndianLanguages() {
    return Object.values(SUPPORTED_LANGUAGES).filter(lang => lang.region === 'india');
  }
  
  /**
   * Get all global languages
   */
  getGlobalLanguages() {
    return Object.values(SUPPORTED_LANGUAGES).filter(lang => lang.region === 'global');
  }

  /**
   * Set the current language
   */
  async setLanguage(languageCode) {
    if (!SUPPORTED_LANGUAGES[languageCode]) {
      console.warn(`Language ${languageCode} not supported, falling back to ${this.fallbackLanguage}`);
      languageCode = this.fallbackLanguage;
    }
    
    this.currentLanguage = languageCode;
    
    // Set date and number formatters based on language
    this.dateTimeFormat = new Intl.DateTimeFormat(languageCode, {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    this.numberFormat = new Intl.NumberFormat(languageCode);
    
    // Save preference
    await PreferenceService.setItem('language', languageCode);
    
    // Notify listeners
    this._notifyLanguageChange();
    
    return true;
  }

  /**
   * Get the current language
   */
  getCurrentLanguage() {
    return {
      code: this.currentLanguage,
      info: SUPPORTED_LANGUAGES[this.currentLanguage] || SUPPORTED_LANGUAGES[this.fallbackLanguage]
    };
  }

  /**
   * Translate a key
   */
  translate(key, replacements = {}) {
    // Get translation from current language or fallback
    const languageTranslations = this.translations[this.currentLanguage] || {};
    const fallbackTranslations = this.translations[this.fallbackLanguage] || {};
    
    // Get translation string or use key as fallback
    let translatedString = languageTranslations[key] || fallbackTranslations[key] || key;
    
    // Apply replacements
    if (replacements && Object.keys(replacements).length > 0) {
      Object.keys(replacements).forEach(placeholder => {
        translatedString = translatedString.replace(
          new RegExp(`{${placeholder}}`, 'g'),
          replacements[placeholder]
        );
      });
    }
    
    return translatedString;
  }

  /**
   * Get a short alias for translate function (for convenience)
   */
  get t() {
    return this.translate.bind(this);
  }

  /**
   * Format a date according to the current language
   */
  formatDate(date, options = {}) {
    try {
      const dateOptions = {
        ...options
      };
      
      if (date instanceof Date) {
        return new Intl.DateTimeFormat(this.currentLanguage, dateOptions).format(date);
      } else {
        return new Intl.DateTimeFormat(this.currentLanguage, dateOptions).format(new Date(date));
      }
    } catch (error) {
      console.error('Error formatting date:', error);
      return String(date);
    }
  }

  /**
   * Format a number according to the current language
   */
  formatNumber(number, options = {}) {
    try {
      return new Intl.NumberFormat(this.currentLanguage, options).format(number);
    } catch (error) {
      console.error('Error formatting number:', error);
      return String(number);
    }
  }

  /**
   * Format currency according to the current language
   */
  formatCurrency(amount, currencyCode = 'INR') {
    try {
      return new Intl.NumberFormat(this.currentLanguage, {
        style: 'currency',
        currency: currencyCode
      }).format(amount);
    } catch (error) {
      console.error('Error formatting currency:', error);
      return String(amount);
    }
  }

  /**
   * Get appropriate greeting based on time of day
   */
  getGreeting() {
    const hour = new Date().getHours();
    
    let greetingKey = 'greeting.morning';
    if (hour >= 12 && hour < 17) {
      greetingKey = 'greeting.afternoon';
    } else if (hour >= 17 && hour < 22) {
      greetingKey = 'greeting.evening';
    } else if (hour >= 22 || hour < 5) {
      greetingKey = 'greeting.night';
    }
    
    return this.translate(greetingKey);
  }

  /**
   * Get localized day of week
   */
  getDayOfWeek(date = new Date()) {
    const day = date.getDay();
    const dayKeys = [
      'day.sunday',
      'day.monday',
      'day.tuesday',
      'day.wednesday',
      'day.thursday',
      'day.friday',
      'day.saturday'
    ];
    
    return this.translate(dayKeys[day]);
  }

  /**
   * Get localized month name
   */
  getMonthName(date = new Date()) {
    const month = date.getMonth();
    const monthKeys = [
      'month.january',
      'month.february',
      'month.march',
      'month.april',
      'month.may',
      'month.june',
      'month.july',
      'month.august',
      'month.september',
      'month.october',
      'month.november',
      'month.december'
    ];
    
    return this.translate(monthKeys[month]);
  }

  /**
   * Check if the current language is RTL
   */
  isRTL() {
    const language = SUPPORTED_LANGUAGES[this.currentLanguage];
    return language && language.direction === 'rtl';
  }

  /**
   * Subscribe to language changes
   */
  subscribe(listener) {
    this.localizationListeners.push(listener);
    
    // Return unsubscribe function
    return () => this.unsubscribe(listener);
  }

  /**
   * Unsubscribe from language changes
   */
  unsubscribe(listener) {
    const index = this.localizationListeners.indexOf(listener);
    if (index !== -1) {
      this.localizationListeners.splice(index, 1);
    }
  }

  /**
   * Notify all listeners of language change
   */
  _notifyLanguageChange() {
    const languageInfo = this.getCurrentLanguage();
    this.localizationListeners.forEach(listener => listener(languageInfo));
  }

  /**
   * Add custom translations for a key
   */
  addTranslation(languageCode, key, translation) {
    if (!TRANSLATIONS[languageCode]) {
      TRANSLATIONS[languageCode] = {};
    }
    
    TRANSLATIONS[languageCode][key] = translation;
  }

  /**
   * Add multiple translations at once
   */
  addTranslations(languageCode, translations) {
    if (!TRANSLATIONS[languageCode]) {
      TRANSLATIONS[languageCode] = {};
    }
    
    Object.assign(TRANSLATIONS[languageCode], translations);
  }

  /**
   * Get all translations for a language
   */
  getTranslations(languageCode = null) {
    if (languageCode && TRANSLATIONS[languageCode]) {
      return TRANSLATIONS[languageCode];
    }
    
    return TRANSLATIONS;
  }
}

// Export a singleton instance
export const LocalizationService = new LocalizationServiceClass();