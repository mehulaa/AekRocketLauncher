import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Slider,
  Dimensions,
  Animated,
  Image,
  Alert,
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import { GLView } from 'expo-gl';
import { ThemeService } from '../services/ThemeService';
import { PreferenceService } from '../services/PreferenceService';
import { performanceUtils } from '../utils/performanceUtils';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const WALLPAPER_PREVIEW_HEIGHT = 200;

const WallpaperEditor = ({ navigation }) => {
  const [theme, setTheme] = useState({});
  const [wallpaperType, setWallpaperType] = useState('static');
  const [wallpaperSettings, setWallpaperSettings] = useState({});
  const [performanceMode, setPerformanceMode] = useState('balanced');
  const [previewReady, setPreviewReady] = useState(false);
  
  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  
  // Load settings
  useEffect(() => {
    const loadSettings = async () => {
      // Load theme
      const currentTheme = await ThemeService.getCurrentTheme();
      setTheme(currentTheme);
      
      // Load wallpaper settings
      const type = await PreferenceService.getItem('wallpaperType', 'static');
      setWallpaperType(type);
      
      const settings = await PreferenceService.getItem('wallpaperSettings', {});
      setWallpaperSettings(settings);
      
      // Load performance mode
      const perfMode = await PreferenceService.getItem('performanceMode', 'balanced');
      setPerformanceMode(perfMode);
      
      // Start animations
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.timing(slideAnim, {
          toValue: 0,
          duration: 500,
          useNativeDriver: true,
        }),
      ]).start();
      
      // Set preview ready after a delay
      setTimeout(() => {
        setPreviewReady(true);
      }, 500);
    };
    
    loadSettings();
  }, []);
  
  // Save wallpaper settings
  const saveWallpaperSettings = async () => {
    try {
      await PreferenceService.setItem('wallpaperType', wallpaperType);
      await PreferenceService.setItem('wallpaperSettings', wallpaperSettings);
      
      Alert.alert(
        'Wallpaper Updated',
        'Your wallpaper settings have been saved.',
        [
          { text: 'OK', onPress: () => navigation.goBack() }
        ]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to save wallpaper settings.');
    }
  };
  
  // Select wallpaper type
  const selectWallpaperType = (type) => {
    setWallpaperType(type);
    
    // Set default settings for this type
    switch (type) {
      case 'particles':
        setWallpaperSettings({
          particleCount: 150,
          particleSize: 1.0,
          particleSpeed: 0.5,
          particleColor: theme.primaryColor,
        });
        break;
      case 'waves':
        setWallpaperSettings({
          amplitude: 0.5,
          frequency: 0.5,
          speed: 0.5,
          color: theme.primaryColor,
        });
        break;
      case 'gradient':
        setWallpaperSettings({
          topColor: theme.primaryColor,
          bottomColor: theme.backgroundColor,
          animated: true,
        });
        break;
      case 'terrain':
        setWallpaperSettings({
          height: 1.5,
          color: theme.primaryColor,
          fog: true,
        });
        break;
      case 'custom':
        setWallpaperSettings({
          color: theme.primaryColor,
        });
        break;
      case 'static':
      default:
        setWallpaperSettings({
          color: theme.backgroundColor,
        });
        break;
    }
  };
  
  // Update wallpaper setting
  const updateWallpaperSetting = (key, value) => {
    setWallpaperSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  // Render wallpaper settings controls based on type
  const renderWallpaperSettings = () => {
    switch (wallpaperType) {
      case 'particles':
        return (
          <View style={styles.settingsContainer}>
            <Text style={[styles.settingLabel, { color: theme.textColor }]}>Particle Count</Text>
            <Slider
              style={styles.slider}
              minimumValue={50}
              maximumValue={300}
              step={10}
              value={wallpaperSettings.particleCount || 150}
              onValueChange={(value) => updateWallpaperSetting('particleCount', value)}
              minimumTrackTintColor={theme.primaryColor}
              maximumTrackTintColor={theme.textColor + '40'}
              thumbTintColor={theme.accentColor}
            />
            <Text style={[styles.settingValue, { color: theme.textColor }]}>
              {wallpaperSettings.particleCount || 150}
            </Text>
            
            <Text style={[styles.settingLabel, { color: theme.textColor }]}>Particle Size</Text>
            <Slider
              style={styles.slider}
              minimumValue={0.5}
              maximumValue={2.0}
              step={0.1}
              value={wallpaperSettings.particleSize || 1.0}
              onValueChange={(value) => updateWallpaperSetting('particleSize', value)}
              minimumTrackTintColor={theme.primaryColor}
              maximumTrackTintColor={theme.textColor + '40'}
              thumbTintColor={theme.accentColor}
            />
            <Text style={[styles.settingValue, { color: theme.textColor }]}>
              {wallpaperSettings.particleSize?.toFixed(1) || '1.0'}
            </Text>
            
            <Text style={[styles.settingLabel, { color: theme.textColor }]}>Animation Speed</Text>
            <Slider
              style={styles.slider}
              minimumValue={0.1}
              maximumValue={1.0}
              step={0.1}
              value={wallpaperSettings.particleSpeed || 0.5}
              onValueChange={(value) => updateWallpaperSetting('particleSpeed', value)}
              minimumTrackTintColor={theme.primaryColor}
              maximumTrackTintColor={theme.textColor + '40'}
              thumbTintColor={theme.accentColor}
            />
            <Text style={[styles.settingValue, { color: theme.textColor }]}>
              {wallpaperSettings.particleSpeed?.toFixed(1) || '0.5'}
            </Text>
            
            <View style={styles.colorPickers}>
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.primaryColor }]}
                onPress={() => updateWallpaperSetting('particleColor', theme.primaryColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.secondaryColor }]}
                onPress={() => updateWallpaperSetting('particleColor', theme.secondaryColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.accentColor }]}
                onPress={() => updateWallpaperSetting('particleColor', theme.accentColor)}
              />
            </View>
          </View>
        );
      
      case 'waves':
        return (
          <View style={styles.settingsContainer}>
            <Text style={[styles.settingLabel, { color: theme.textColor }]}>Wave Height</Text>
            <Slider
              style={styles.slider}
              minimumValue={0.1}
              maximumValue={1.0}
              step={0.1}
              value={wallpaperSettings.amplitude || 0.5}
              onValueChange={(value) => updateWallpaperSetting('amplitude', value)}
              minimumTrackTintColor={theme.primaryColor}
              maximumTrackTintColor={theme.textColor + '40'}
              thumbTintColor={theme.accentColor}
            />
            <Text style={[styles.settingValue, { color: theme.textColor }]}>
              {wallpaperSettings.amplitude?.toFixed(1) || '0.5'}
            </Text>
            
            <Text style={[styles.settingLabel, { color: theme.textColor }]}>Wave Frequency</Text>
            <Slider
              style={styles.slider}
              minimumValue={0.1}
              maximumValue={1.0}
              step={0.1}
              value={wallpaperSettings.frequency || 0.5}
              onValueChange={(value) => updateWallpaperSetting('frequency', value)}
              minimumTrackTintColor={theme.primaryColor}
              maximumTrackTintColor={theme.textColor + '40'}
              thumbTintColor={theme.accentColor}
            />
            <Text style={[styles.settingValue, { color: theme.textColor }]}>
              {wallpaperSettings.frequency?.toFixed(1) || '0.5'}
            </Text>
            
            <Text style={[styles.settingLabel, { color: theme.textColor }]}>Wave Speed</Text>
            <Slider
              style={styles.slider}
              minimumValue={0.1}
              maximumValue={1.0}
              step={0.1}
              value={wallpaperSettings.speed || 0.5}
              onValueChange={(value) => updateWallpaperSetting('speed', value)}
              minimumTrackTintColor={theme.primaryColor}
              maximumTrackTintColor={theme.textColor + '40'}
              thumbTintColor={theme.accentColor}
            />
            <Text style={[styles.settingValue, { color: theme.textColor }]}>
              {wallpaperSettings.speed?.toFixed(1) || '0.5'}
            </Text>
            
            <View style={styles.colorPickers}>
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.primaryColor }]}
                onPress={() => updateWallpaperSetting('color', theme.primaryColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.secondaryColor }]}
                onPress={() => updateWallpaperSetting('color', theme.secondaryColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.accentColor }]}
                onPress={() => updateWallpaperSetting('color', theme.accentColor)}
              />
            </View>
          </View>
        );
        
      case 'gradient':
        return (
          <View style={styles.settingsContainer}>
            <Text style={[styles.settingLabel, { color: theme.textColor }]}>Top Color</Text>
            <View style={styles.colorPickers}>
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.primaryColor }]}
                onPress={() => updateWallpaperSetting('topColor', theme.primaryColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.secondaryColor }]}
                onPress={() => updateWallpaperSetting('topColor', theme.secondaryColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.accentColor }]}
                onPress={() => updateWallpaperSetting('topColor', theme.accentColor)}
              />
            </View>
            
            <Text style={[styles.settingLabel, { color: theme.textColor }]}>Bottom Color</Text>
            <View style={styles.colorPickers}>
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.backgroundColor }]}
                onPress={() => updateWallpaperSetting('bottomColor', theme.backgroundColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.cardColor }]}
                onPress={() => updateWallpaperSetting('bottomColor', theme.cardColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.textColor }]}
                onPress={() => updateWallpaperSetting('bottomColor', theme.textColor)}
              />
            </View>
            
            <View style={styles.switchRow}>
              <Text style={[styles.settingLabel, { color: theme.textColor }]}>Animated</Text>
              <TouchableOpacity
                style={[
                  styles.toggleButton,
                  wallpaperSettings.animated && {
                    backgroundColor: theme.primaryColor
                  }
                ]}
                onPress={() => updateWallpaperSetting('animated', !wallpaperSettings.animated)}
              >
                <Text
                  style={[
                    styles.toggleButtonText,
                    wallpaperSettings.animated && {
                      color: '#FFFFFF'
                    }
                  ]}
                >
                  {wallpaperSettings.animated ? 'ON' : 'OFF'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        );
        
      case 'terrain':
        return (
          <View style={styles.settingsContainer}>
            <Text style={[styles.settingLabel, { color: theme.textColor }]}>Terrain Height</Text>
            <Slider
              style={styles.slider}
              minimumValue={0.5}
              maximumValue={3.0}
              step={0.1}
              value={wallpaperSettings.height || 1.5}
              onValueChange={(value) => updateWallpaperSetting('height', value)}
              minimumTrackTintColor={theme.primaryColor}
              maximumTrackTintColor={theme.textColor + '40'}
              thumbTintColor={theme.accentColor}
            />
            <Text style={[styles.settingValue, { color: theme.textColor }]}>
              {wallpaperSettings.height?.toFixed(1) || '1.5'}
            </Text>
            
            <Text style={[styles.settingLabel, { color: theme.textColor }]}>Terrain Color</Text>
            <View style={styles.colorPickers}>
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.primaryColor }]}
                onPress={() => updateWallpaperSetting('color', theme.primaryColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.secondaryColor }]}
                onPress={() => updateWallpaperSetting('color', theme.secondaryColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.accentColor }]}
                onPress={() => updateWallpaperSetting('color', theme.accentColor)}
              />
            </View>
            
            <View style={styles.switchRow}>
              <Text style={[styles.settingLabel, { color: theme.textColor }]}>Fog Effect</Text>
              <TouchableOpacity
                style={[
                  styles.toggleButton,
                  wallpaperSettings.fog && {
                    backgroundColor: theme.primaryColor
                  }
                ]}
                onPress={() => updateWallpaperSetting('fog', !wallpaperSettings.fog)}
              >
                <Text
                  style={[
                    styles.toggleButtonText,
                    wallpaperSettings.fog && {
                      color: '#FFFFFF'
                    }
                  ]}
                >
                  {wallpaperSettings.fog ? 'ON' : 'OFF'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        );
        
      case 'custom':
      case 'static':
      default:
        return (
          <View style={styles.settingsContainer}>
            <Text style={[styles.settingLabel, { color: theme.textColor }]}>Background Color</Text>
            <View style={styles.colorPickers}>
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.backgroundColor }]}
                onPress={() => updateWallpaperSetting('color', theme.backgroundColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.primaryColor }]}
                onPress={() => updateWallpaperSetting('color', theme.primaryColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.secondaryColor }]}
                onPress={() => updateWallpaperSetting('color', theme.secondaryColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: theme.accentColor }]}
                onPress={() => updateWallpaperSetting('color', theme.accentColor)}
              />
              <TouchableOpacity
                style={[styles.colorPicker, { backgroundColor: '#000000' }]}
                onPress={() => updateWallpaperSetting('color', '#000000')}
              />
            </View>
          </View>
        );
    }
  };
  
  // Create a placeholder preview
  const renderWallpaperPreview = () => {
    let previewStyle = {};
    let previewContent = null;
    
    switch (wallpaperType) {
      case 'particles':
        previewStyle = {
          backgroundColor: theme.backgroundColor,
        };
        previewContent = (
          <View style={styles.particleContainer}>
            {Array(20).fill(0).map((_, i) => (
              <View
                key={`particle-${i}`}
                style={[
                  styles.particle,
                  {
                    backgroundColor: wallpaperSettings.particleColor || theme.primaryColor,
                    width: (wallpaperSettings.particleSize || 1) * 5,
                    height: (wallpaperSettings.particleSize || 1) * 5,
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                    opacity: Math.random() * 0.8 + 0.2,
                  }
                ]}
              />
            ))}
          </View>
        );
        break;
        
      case 'waves':
        previewStyle = {
          backgroundColor: theme.backgroundColor,
        };
        previewContent = (
          <View style={styles.wavesContainer}>
            {Array(5).fill(0).map((_, i) => (
              <View
                key={`wave-${i}`}
                style={[
                  styles.wave,
                  {
                    backgroundColor: wallpaperSettings.color || theme.primaryColor,
                    height: (wallpaperSettings.amplitude || 0.5) * 20 + 5,
                    top: 20 + i * 30,
                    opacity: 0.2 + (i * 0.15),
                  }
                ]}
              />
            ))}
          </View>
        );
        break;
        
      case 'gradient':
        previewStyle = {
          backgroundColor: theme.backgroundColor,
          backgroundGradient: true,
          topColor: wallpaperSettings.topColor || theme.primaryColor,
          bottomColor: wallpaperSettings.bottomColor || theme.backgroundColor,
        };
        break;
        
      case 'terrain':
        previewStyle = {
          backgroundColor: theme.backgroundColor,
        };
        previewContent = (
          <View style={styles.terrainContainer}>
            <View
              style={[
                styles.terrainShape,
                {
                  backgroundColor: wallpaperSettings.color || theme.primaryColor,
                  height: (wallpaperSettings.height || 1.5) * 30,
                }
              ]}
            />
            {wallpaperSettings.fog && (
              <View style={[styles.fogOverlay, { backgroundColor: theme.backgroundColor }]} />
            )}
          </View>
        );
        break;
        
      case 'custom':
        previewStyle = {
          backgroundColor: theme.backgroundColor,
        };
        previewContent = (
          <View style={styles.customContainer}>
            <View
              style={[
                styles.customBackground,
                { backgroundColor: wallpaperSettings.color || theme.primaryColor }
              ]}
            />
            <Feather name="upload" size={32} color="#FFFFFF" />
            <Text style={styles.customText}>Tap to upload image</Text>
          </View>
        );
        break;
        
      case 'static':
      default:
        previewStyle = {
          backgroundColor: wallpaperSettings.color || theme.backgroundColor,
        };
        break;
    }
    
    return (
      <View
        style={[
          styles.previewContainer,
          { borderColor: theme.cardColor },
          previewStyle
        ]}
      >
        {previewStyle.backgroundGradient && (
          <View
            style={[
              styles.gradientPreview,
              {
                backgroundColor: previewStyle.topColor,
                shadowColor: previewStyle.bottomColor,
              }
            ]}
          />
        )}
        {previewContent}
      </View>
    );
  };
  
  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
      <Animated.View
        style={[
          styles.header,
          {
            backgroundColor: theme.cardColor,
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }]
          }
        ]}
      >
        <Text style={[styles.headerTitle, { color: theme.textColor }]}>
          3D Wallpaper Editor
        </Text>
        <Text style={[styles.headerSubtitle, { color: theme.textColor + '99' }]}>
          Customize your launcher background
        </Text>
      </Animated.View>
      
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Wallpaper Preview */}
        <Animated.View
          style={[
            styles.previewWrapper,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }]
            }
          ]}
        >
          <Text style={[styles.sectionTitle, { color: theme.primaryColor }]}>Preview</Text>
          {renderWallpaperPreview()}
        </Animated.View>
        
        {/* Wallpaper Type Selection */}
        <Animated.View
          style={[
            styles.section,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }]
            }
          ]}
        >
          <Text style={[styles.sectionTitle, { color: theme.primaryColor }]}>Wallpaper Type</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.typeOptions}
          >
            <TouchableOpacity
              style={[
                styles.typeOption,
                wallpaperType === 'static' && styles.selectedTypeOption,
                { borderColor: theme.primaryColor }
              ]}
              onPress={() => selectWallpaperType('static')}
            >
              <Feather
                name="square"
                size={24}
                color={wallpaperType === 'static' ? theme.primaryColor : theme.textColor}
              />
              <Text
                style={[
                  styles.typeText,
                  { color: theme.textColor },
                  wallpaperType === 'static' && { color: theme.primaryColor, fontWeight: 'bold' }
                ]}
              >
                Solid Color
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.typeOption,
                wallpaperType === 'particles' && styles.selectedTypeOption,
                { borderColor: theme.primaryColor }
              ]}
              onPress={() => selectWallpaperType('particles')}
            >
              <Feather
                name="star"
                size={24}
                color={wallpaperType === 'particles' ? theme.primaryColor : theme.textColor}
              />
              <Text
                style={[
                  styles.typeText,
                  { color: theme.textColor },
                  wallpaperType === 'particles' && { color: theme.primaryColor, fontWeight: 'bold' }
                ]}
              >
                Particles
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.typeOption,
                wallpaperType === 'waves' && styles.selectedTypeOption,
                { borderColor: theme.primaryColor }
              ]}
              onPress={() => selectWallpaperType('waves')}
            >
              <Feather
                name="activity"
                size={24}
                color={wallpaperType === 'waves' ? theme.primaryColor : theme.textColor}
              />
              <Text
                style={[
                  styles.typeText,
                  { color: theme.textColor },
                  wallpaperType === 'waves' && { color: theme.primaryColor, fontWeight: 'bold' }
                ]}
              >
                Waves
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.typeOption,
                wallpaperType === 'gradient' && styles.selectedTypeOption,
                { borderColor: theme.primaryColor }
              ]}
              onPress={() => selectWallpaperType('gradient')}
            >
              <Feather
                name="droplet"
                size={24}
                color={wallpaperType === 'gradient' ? theme.primaryColor : theme.textColor}
              />
              <Text
                style={[
                  styles.typeText,
                  { color: theme.textColor },
                  wallpaperType === 'gradient' && { color: theme.primaryColor, fontWeight: 'bold' }
                ]}
              >
                Gradient
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.typeOption,
                wallpaperType === 'terrain' && styles.selectedTypeOption,
                { borderColor: theme.primaryColor }
              ]}
              onPress={() => selectWallpaperType('terrain')}
            >
              <Feather
                name="layers"
                size={24}
                color={wallpaperType === 'terrain' ? theme.primaryColor : theme.textColor}
              />
              <Text
                style={[
                  styles.typeText,
                  { color: theme.textColor },
                  wallpaperType === 'terrain' && { color: theme.primaryColor, fontWeight: 'bold' }
                ]}
              >
                Terrain
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.typeOption,
                wallpaperType === 'custom' && styles.selectedTypeOption,
                { borderColor: theme.primaryColor }
              ]}
              onPress={() => selectWallpaperType('custom')}
            >
              <Feather
                name="image"
                size={24}
                color={wallpaperType === 'custom' ? theme.primaryColor : theme.textColor}
              />
              <Text
                style={[
                  styles.typeText,
                  { color: theme.textColor },
                  wallpaperType === 'custom' && { color: theme.primaryColor, fontWeight: 'bold' }
                ]}
              >
                Custom
              </Text>
            </TouchableOpacity>
          </ScrollView>
        </Animated.View>
        
        {/* Wallpaper Settings */}
        <Animated.View
          style={[
            styles.section,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }]
            }
          ]}
        >
          <Text style={[styles.sectionTitle, { color: theme.primaryColor }]}>Settings</Text>
          {renderWallpaperSettings()}
        </Animated.View>
        
        {/* Quality Warning */}
        {performanceMode === 'performance' && (
          <Animated.View
            style={[
              styles.warningContainer,
              {
                backgroundColor: theme.cardColor,
                borderColor: theme.accentColor,
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }]
              }
            ]}
          >
            <Feather name="alert-triangle" size={20} color={theme.accentColor} />
            <Text style={[styles.warningText, { color: theme.textColor }]}>
              Performance mode is enabled. Some visual effects may be limited.
            </Text>
          </Animated.View>
        )}
        
        {/* Action Buttons */}
        <Animated.View
          style={[
            styles.actionButtons,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }]
            }
          ]}
        >
          <TouchableOpacity
            style={[styles.actionButton, styles.cancelButton]}
            onPress={() => navigation.goBack()}
          >
            <Feather name="x" size={20} color="#FFFFFF" />
            <Text style={styles.actionButtonText}>Cancel</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, styles.saveButton, { backgroundColor: theme.primaryColor }]}
            onPress={saveWallpaperSettings}
          >
            <Feather name="check" size={20} color="#FFFFFF" />
            <Text style={styles.actionButtonText}>Apply</Text>
          </TouchableOpacity>
        </Animated.View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0, 0, 0, 0.1)',
    marginTop: 25, // Account for transparent header
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  previewWrapper: {
    marginBottom: 24,
  },
  previewContainer: {
    width: '100%',
    height: WALLPAPER_PREVIEW_HEIGHT,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    marginTop: 12,
    position: 'relative',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  typeOptions: {
    paddingVertical: 8,
  },
  typeOption: {
    width: 100,
    padding: 12,
    borderRadius: 12,
    borderWidth: 2,
    alignItems: 'center',
    marginRight: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  selectedTypeOption: {
    borderWidth: 2,
    backgroundColor: 'rgba(33, 150, 243, 0.1)',
  },
  typeText: {
    marginTop: 8,
    textAlign: 'center',
  },
  settingsContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
  },
  settingLabel: {
    fontSize: 16,
    marginBottom: 8,
  },
  slider: {
    width: '100%',
    height: 40,
  },
  settingValue: {
    textAlign: 'center',
    marginBottom: 16,
  },
  colorPickers: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  colorPicker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.5)',
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  toggleButton: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  toggleButtonText: {
    fontWeight: 'bold',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 24,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    flex: 1,
    marginHorizontal: 8,
  },
  cancelButton: {
    backgroundColor: '#757575',
  },
  saveButton: {
    backgroundColor: '#4CAF50',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
    marginLeft: 8,
  },
  warningContainer: {
    flexDirection: 'row',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
    marginBottom: 24,
  },
  warningText: {
    flex: 1,
    marginLeft: 12,
    fontSize: 14,
  },
  particleContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
  },
  particle: {
    position: 'absolute',
    borderRadius: 50,
  },
  wavesContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
  },
  wave: {
    position: 'absolute',
    width: '100%',
    borderRadius: 10,
    transform: [{ scaleX: 1.2 }],
  },
  gradientPreview: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    shadowOffset: { width: 0, height: 100 },
    shadowOpacity: 1,
    shadowRadius: 50,
  },
  terrainContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    justifyContent: 'flex-end',
  },
  terrainShape: {
    width: '100%',
    borderTopLeftRadius: 50,
    borderTopRightRadius: 50,
  },
  fogOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '60%',
    opacity: 0.5,
  },
  customContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  customBackground: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.7,
  },
  customText: {
    color: '#FFFFFF',
    marginTop: 8,
    fontWeight: 'bold',
  },
});

export default WallpaperEditor;
