import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  StyleSheet, 
  Dimensions, 
  PanResponder,
  Animated,
  BackHandler
} from 'react-native';
import { ThemeService } from '../services/ThemeService';
import { PreferenceService } from '../services/PreferenceService';
import { AppService } from '../services/AppService';
import AppDrawer from './AppDrawer';
import CustomWidget from './CustomWidget';
import World from '../3d/World';
import { gestureUtils } from '../utils/gestureUtils';
import { performanceUtils } from '../utils/performanceUtils';

const HomeScreen = ({ navigation }) => {
  const [theme, setTheme] = useState({});
  const [appDrawerVisible, setAppDrawerVisible] = useState(false);
  const [widgets, setWidgets] = useState([]);
  const [layoutConfig, setLayoutConfig] = useState({ columns: 5, rows: 6 });
  const [performanceMode, setPerformanceMode] = useState('balanced');
  
  // References for animations
  const worldOpacity = useRef(new Animated.Value(1)).current;
  const appDrawerPosition = useRef(new Animated.Value(0)).current;
  
  // 3D world references
  const worldRef = useRef(null);
  
  useEffect(() => {
    // Load theme
    const loadTheme = async () => {
      const currentTheme = await ThemeService.getCurrentTheme();
      setTheme(currentTheme);
    };
    
    // Load widgets
    const loadWidgets = async () => {
      const savedWidgets = await PreferenceService.getItem('widgets', '[]');
      setWidgets(JSON.parse(savedWidgets));
    };
    
    // Load layout config
    const loadLayoutConfig = async () => {
      const config = await PreferenceService.getItem('gridSize', { columns: 5, rows: 6 });
      setLayoutConfig(config);
    };
    
    // Load performance mode
    const loadPerformanceMode = async () => {
      const mode = await PreferenceService.getItem('performanceMode', 'balanced');
      setPerformanceMode(mode);
      
      // Apply performance settings
      performanceUtils.setPerformanceMode(mode);
    };
    
    // Initialize services and load data
    const initializeApp = async () => {
      await AppService.initialize();
      await loadTheme();
      await loadWidgets();
      await loadLayoutConfig();
      await loadPerformanceMode();
    };
    
    initializeApp();
    
    // Subscribe to theme changes
    const themeUnsubscribe = ThemeService.subscribeToThemeChanges(newTheme => {
      setTheme(newTheme);
    });
    
    // Subscribe to widget changes
    const widgetUnsubscribe = PreferenceService.subscribe('widgets', newWidgets => {
      setWidgets(JSON.parse(newWidgets || '[]'));
    });
    
    // Subscribe to layout changes
    const layoutUnsubscribe = PreferenceService.subscribe('gridSize', newLayout => {
      setLayoutConfig(newLayout);
    });
    
    // Subscribe to performance mode changes
    const performanceUnsubscribe = PreferenceService.subscribe('performanceMode', newMode => {
      setPerformanceMode(newMode);
      performanceUtils.setPerformanceMode(newMode);
    });
    
    // Handle back button
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      if (appDrawerVisible) {
        closeAppDrawer();
        return true;
      }
      return false;
    });
    
    // Cleanup
    return () => {
      themeUnsubscribe();
      widgetUnsubscribe();
      layoutUnsubscribe();
      performanceUnsubscribe();
      backHandler.remove();
    };
  }, []);
  
  // Pan responder for gestures
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onStartShouldSetPanResponderCapture: () => false,
      onMoveShouldSetPanResponder: (_, gestureState) => {
        return Math.abs(gestureState.dx) > 10 || Math.abs(gestureState.dy) > 10;
      },
      onPanResponderGrant: () => {
        // Handle gesture start
      },
      onPanResponderMove: (_, gestureState) => {
        // Handle app drawer pull-up gesture
        if (gestureState.dy < -50 && !appDrawerVisible) {
          openAppDrawer();
        }
        
        // Handle app drawer close gesture
        if (gestureState.dy > 50 && appDrawerVisible) {
          closeAppDrawer();
        }
        
        // Handle 3D perspective shift based on movement
        if (worldRef.current) {
          worldRef.current.handlePan(gestureState.dx, gestureState.dy);
        }
      },
      onPanResponderRelease: (_, gestureState) => {
        // Handle swipe gestures
        const { direction, distance } = gestureUtils.getSwipeDirection(gestureState);
        
        if (distance > 120) {
          handleSwipeGesture(direction);
        }
        
        // Reset 3D perspective
        if (worldRef.current) {
          worldRef.current.resetPerspective();
        }
      },
    })
  ).current;
  
  // Handle swipe gestures based on user preferences
  const handleSwipeGesture = async (direction) => {
    const customGestures = await PreferenceService.getItem('customGestures', '{}');
    const gestures = JSON.parse(customGestures);
    
    if (gestures[direction]) {
      const action = gestures[direction];
      
      switch (action.type) {
        case 'openApp':
          AppService.launchApp(action.packageName);
          break;
        case 'openSettings':
          navigation.navigate('Settings');
          break;
        case 'toggleDrawer':
          toggleAppDrawer();
          break;
        case 'notification':
          // Open notification panel (would require native module)
          break;
        default:
          // No action defined
          break;
      }
    }
  };
  
  // Open the app drawer
  const openAppDrawer = () => {
    setAppDrawerVisible(true);
    AppService.setAppDrawerOpen(true);
    
    // Animate the app drawer and world
    Animated.parallel([
      Animated.timing(appDrawerPosition, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.timing(worldOpacity, {
        toValue: 0.7,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start();
  };
  
  // Close the app drawer
  const closeAppDrawer = () => {
    Animated.parallel([
      Animated.timing(appDrawerPosition, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.timing(worldOpacity, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start(() => {
      setAppDrawerVisible(false);
      AppService.setAppDrawerOpen(false);
    });
  };
  
  // Toggle the app drawer
  const toggleAppDrawer = () => {
    if (appDrawerVisible) {
      closeAppDrawer();
    } else {
      openAppDrawer();
    }
  };
  
  // Transform for the app drawer
  const appDrawerTransform = {
    transform: [
      {
        translateY: appDrawerPosition.interpolate({
          inputRange: [0, 1],
          outputRange: [Dimensions.get('window').height, 0],
        }),
      },
    ],
  };
  
  // Handle long press on empty space
  const handleLongPress = () => {
    navigation.navigate('Settings');
  };
  
  // Render widgets
  const renderWidgets = () => {
    return widgets.map((widget, index) => (
      <CustomWidget
        key={`widget-${index}`}
        widget={widget}
        theme={theme}
        onEdit={() => navigation.navigate('WidgetEditor', { widgetId: widget.id })}
      />
    ));
  };
  
  return (
    <View 
      style={[
        styles.container, 
        { backgroundColor: theme.backgroundColor || '#000' }
      ]}
    >
      {/* 3D World Background */}
      <Animated.View style={[styles.worldContainer, { opacity: worldOpacity }]}>
        <World 
          ref={worldRef}
          theme={theme} 
          performanceMode={performanceMode}
        />
      </Animated.View>
      
      {/* Widgets Container */}
      <View 
        style={styles.widgetsContainer}
        {...panResponder.panHandlers}
        onLongPress={handleLongPress}
      >
        {renderWidgets()}
      </View>
      
      {/* App Drawer */}
      <Animated.View style={[styles.appDrawerContainer, appDrawerTransform]}>
        <AppDrawer 
          visible={appDrawerVisible}
          theme={theme}
          onClose={closeAppDrawer}
          navigation={navigation}
        />
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  worldContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  widgetsContainer: {
    flex: 1,
    padding: 16,
  },
  appDrawerContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: '80%',
  },
});

export default HomeScreen;
