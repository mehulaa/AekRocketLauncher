import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  FlatList,
  TouchableOpacity,
  Animated,
  Keyboard,
  StatusBar,
  ActivityIndicator,
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import { AppService } from '../services/AppService';
import { ThemeService } from '../services/ThemeService';
import AppIcon from '../3d/AppIcon';

const AppSearch = ({ navigation }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [apps, setApps] = useState([]);
  const [filteredApps, setFilteredApps] = useState([]);
  const [recentApps, setRecentApps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState({});
  
  // Animation values
  const searchBarAnim = useRef(new Animated.Value(0)).current;
  const listOpacity = useRef(new Animated.Value(0)).current;
  const searchInputRef = useRef(null);
  
  // Load apps and theme
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      
      // Load theme
      const currentTheme = await ThemeService.getCurrentTheme();
      setTheme(currentTheme);
      
      // Load all apps
      const installedApps = AppService.getInstalledApps();
      setApps(installedApps);
      setFilteredApps(installedApps);
      
      // Load recent apps (would normally come from usage stats)
      // For demo, we'll just use the first 5 apps
      setRecentApps(installedApps.slice(0, 5));
      
      setLoading(false);
      
      // Start entrance animations
      Animated.parallel([
        Animated.timing(searchBarAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(listOpacity, {
          toValue: 1,
          duration: 500,
          delay: 100,
          useNativeDriver: true,
        }),
      ]).start(() => {
        // Focus search input after animation
        if (searchInputRef.current) {
          searchInputRef.current.focus();
        }
      });
    };
    
    loadData();
    
    return () => {
      // Clean up
    };
  }, []);
  
  // Handle search query changes
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredApps(apps);
    } else {
      const lowercaseQuery = searchQuery.toLowerCase();
      const filtered = apps.filter(
        app => 
          app.appName.toLowerCase().includes(lowercaseQuery) ||
          app.packageName.toLowerCase().includes(lowercaseQuery)
      );
      setFilteredApps(filtered);
    }
  }, [searchQuery, apps]);
  
  // Launch an app
  const launchApp = (packageName) => {
    AppService.launchApp(packageName);
    navigation.goBack();
  };
  
  // Render an app item
  const renderAppItem = ({ item, index }) => {
    const animationDelay = index * 50; // Stagger animation
    
    return (
      <Animated.View
        style={[
          styles.appItem,
          {
            backgroundColor: theme.cardColor, 
            opacity: listOpacity.interpolate({
              inputRange: [0, 1],
              outputRange: [0, 1],
            }),
            transform: [
              {
                translateY: listOpacity.interpolate({
                  inputRange: [0, 1],
                  outputRange: [20, 0],
                }),
              },
            ],
          },
        ]}
      >
        <TouchableOpacity
          style={styles.appButton}
          onPress={() => launchApp(item.packageName)}
        >
          <View style={styles.appIconContainer}>
            <AppIcon
              packageName={item.packageName}
              size={44}
              style="flat"
              theme={theme}
            />
          </View>
          <View style={styles.appDetails}>
            <Text 
              style={[styles.appName, { color: theme.textColor }]}
              numberOfLines={1}
            >
              {item.appName}
            </Text>
            <Text 
              style={[styles.packageName, { color: theme.textColor + '80' }]}
              numberOfLines={1}
            >
              {item.packageName}
            </Text>
          </View>
        </TouchableOpacity>
      </Animated.View>
    );
  };
  
  // Render section header
  const SectionHeader = ({ title }) => (
    <View style={styles.sectionHeader}>
      <Text style={[styles.sectionTitle, { color: theme.textColor }]}>
        {title}
      </Text>
    </View>
  );
  
  // Search bar animations
  const searchBarTranslation = searchBarAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [-100, 0],
  });
  
  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
      <StatusBar
        backgroundColor="transparent"
        barStyle={theme.isDark ? 'light-content' : 'dark-content'}
        translucent
      />
      
      {/* Search Bar */}
      <Animated.View
        style={[
          styles.searchBarContainer,
          { 
            backgroundColor: theme.cardColor,
            transform: [{ translateY: searchBarTranslation }],
          },
        ]}
      >
        <TouchableOpacity 
          style={styles.backButton} 
          onPress={() => navigation.goBack()}
        >
          <Feather name="arrow-left" size={24} color={theme.textColor} />
        </TouchableOpacity>
        
        <View style={[styles.searchBar, { backgroundColor: theme.backgroundColor + '50' }]}>
          <Feather name="search" size={20} color={theme.textColor + '80'} style={styles.searchIcon} />
          <TextInput
            ref={searchInputRef}
            style={[styles.searchInput, { color: theme.textColor }]}
            placeholder="Search apps..."
            placeholderTextColor={theme.textColor + '60'}
            value={searchQuery}
            onChangeText={setSearchQuery}
            autoCapitalize="none"
            returnKeyType="search"
          />
          {searchQuery !== '' && (
            <TouchableOpacity
              style={styles.clearButton}
              onPress={() => setSearchQuery('')}
            >
              <Feather name="x" size={18} color={theme.textColor + '80'} />
            </TouchableOpacity>
          )}
        </View>
      </Animated.View>
      
      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={theme.primaryColor} />
          <Text style={[styles.loadingText, { color: theme.textColor }]}>
            Loading apps...
          </Text>
        </View>
      ) : (
        <Animated.View
          style={[
            styles.contentContainer,
            { 
              opacity: listOpacity,
              transform: [
                {
                  translateY: listOpacity.interpolate({
                    inputRange: [0, 1],
                    outputRange: [20, 0],
                  }),
                },
              ],
            },
          ]}
        >
          {searchQuery === '' ? (
            <>
              {/* Recent Apps Section */}
              <SectionHeader title="Recent Apps" />
              <FlatList
                data={recentApps}
                renderItem={renderAppItem}
                keyExtractor={(item) => `recent-${item.packageName}`}
                contentContainerStyle={styles.appsList}
                horizontal
                showsHorizontalScrollIndicator={false}
              />
              
              {/* All Apps Section */}
              <SectionHeader title="All Apps" />
              <FlatList
                data={apps}
                renderItem={renderAppItem}
                keyExtractor={(item) => `all-${item.packageName}`}
                contentContainerStyle={styles.appsList}
                numColumns={1}
                showsVerticalScrollIndicator={false}
              />
            </>
          ) : (
            <>
              {/* Search Results */}
              <SectionHeader 
                title={
                  filteredApps.length > 0 
                    ? `Found ${filteredApps.length} app${filteredApps.length === 1 ? '' : 's'}`
                    : 'No apps found'
                } 
              />
              {filteredApps.length > 0 ? (
                <FlatList
                  data={filteredApps}
                  renderItem={renderAppItem}
                  keyExtractor={(item) => `search-${item.packageName}`}
                  contentContainerStyle={styles.appsList}
                  numColumns={1}
                  showsVerticalScrollIndicator={false}
                />
              ) : (
                <View style={styles.noResultsContainer}>
                  <Feather name="search" size={48} color={theme.textColor + '40'} />
                  <Text style={[styles.noResultsText, { color: theme.textColor + '80' }]}>
                    No apps match your search
                  </Text>
                </View>
              )}
            </>
          )}
        </Animated.View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  searchBarContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: StatusBar.currentHeight + 8,
    paddingBottom: 12,
    elevation: 4,
    zIndex: 10,
  },
  backButton: {
    padding: 8,
    marginRight: 8,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    height: 46,
    borderRadius: 23,
    paddingHorizontal: 16,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
  },
  clearButton: {
    padding: 8,
  },
  contentContainer: {
    flex: 1,
    paddingHorizontal: 16,
  },
  sectionHeader: {
    paddingVertical: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  appsList: {
    paddingBottom: 24,
  },
  appItem: {
    borderRadius: 12,
    marginBottom: 8,
    elevation: 1,
    overflow: 'hidden',
  },
  appButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
  },
  appIconContainer: {
    marginRight: 16,
  },
  appDetails: {
    flex: 1,
  },
  appName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  packageName: {
    fontSize: 12,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
  },
  noResultsContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 64,
  },
  noResultsText: {
    marginTop: 16,
    fontSize: 16,
  },
});

export default AppSearch;
