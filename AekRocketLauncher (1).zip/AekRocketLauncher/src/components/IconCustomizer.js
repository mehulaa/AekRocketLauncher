import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Animated,
  Dimensions,
  Switch,
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import { PreferenceService } from '../services/PreferenceService';
import { AppService } from '../services/AppService';
import AppIcon from '../3d/AppIcon';
import { threeJsUtils } from '../utils/threeJsUtils';
import { animationStyles } from '../styles/animations';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const IconCustomizer = ({ route, navigation }) => {
  const { packageName } = route.params || {};
  const [appInfo, setAppInfo] = useState(null);
  const [iconData, setIconData] = useState(null);
  const [iconStyle, setIconStyle] = useState('flat');
  const [iconColor, setIconColor] = useState('#FFFFFF');
  const [iconShape, setIconShape] = useState('rounded-square');
  const [customRotation, setCustomRotation] = useState({ x: 0, y: 0, z: 0 });
  const [customScale, setCustomScale] = useState(1);
  const [is3DEnabled, setIs3DEnabled] = useState(true);
  
  // Animation values
  const rotationValue = React.useRef(new Animated.Value(0)).current;
  const scaleValue = React.useRef(new Animated.Value(1)).current;
  
  // Load app info and icon data
  useEffect(() => {
    const loadData = async () => {
      if (!packageName) {
        navigation.goBack();
        return;
      }
      
      // Get app info
      const apps = AppService.getInstalledApps();
      const app = apps.find(a => a.packageName === packageName);
      if (app) {
        setAppInfo(app);
      }
      
      // Load custom icon data if it exists
      const customIcons = await PreferenceService.getItem('customIcons', '{}');
      const parsedIcons = JSON.parse(customIcons);
      
      if (parsedIcons[packageName]) {
        // Use existing custom icon
        setIconData(parsedIcons[packageName]);
        setIconColor(parsedIcons[packageName].color || '#FFFFFF');
        setIconShape(parsedIcons[packageName].shape || 'rounded-square');
        setIconStyle(parsedIcons[packageName].style || 'flat');
        
        if (parsedIcons[packageName].customizations) {
          const { rotation = { x: 0, y: 0, z: 0 }, scale = 1 } = parsedIcons[packageName].customizations;
          setCustomRotation(rotation);
          setCustomScale(scale);
        }
        
        setIs3DEnabled(parsedIcons[packageName].is3D !== false);
      } else {
        // Create default icon data
        const defaultColor = generateColorFromPackageName(packageName);
        setIconColor(defaultColor);
        
        setIconData({
          color: defaultColor,
          shape: 'rounded-square',
          style: 'flat',
          is3D: true,
          customizations: {
            rotation: { x: 0, y: 0, z: 0 },
            scale: 1
          }
        });
      }
    };
    
    loadData();
  }, [packageName, navigation]);
  
  // Generate a consistent color from package name
  const generateColorFromPackageName = (name) => {
    // Simple hash function to generate a color
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    // Convert to hex color
    let color = '#';
    for (let i = 0; i < 3; i++) {
      const value = (hash >> (i * 8)) & 0xFF;
      color += ('00' + value.toString(16)).substr(-2);
    }
    
    return color;
  };
  
  // Save icon customizations
  const saveIconCustomizations = async () => {
    // Create updated icon data
    const updatedIconData = {
      ...iconData,
      color: iconColor,
      shape: iconShape,
      style: iconStyle,
      is3D: is3DEnabled,
      customizations: {
        rotation: customRotation,
        scale: customScale
      }
    };
    
    // Save to preferences
    const customIcons = await PreferenceService.getItem('customIcons', '{}');
    const parsedIcons = JSON.parse(customIcons);
    
    parsedIcons[packageName] = updatedIconData;
    await PreferenceService.setItem('customIcons', JSON.stringify(parsedIcons));
    
    // Show success animation
    animateSuccess();
  };
  
  // Reset to default icon
  const resetToDefault = async () => {
    // Remove custom icon data
    const customIcons = await PreferenceService.getItem('customIcons', '{}');
    const parsedIcons = JSON.parse(customIcons);
    
    if (parsedIcons[packageName]) {
      delete parsedIcons[packageName];
      await PreferenceService.setItem('customIcons', JSON.stringify(parsedIcons));
    }
    
    // Reset state
    const defaultColor = generateColorFromPackageName(packageName);
    setIconColor(defaultColor);
    setIconShape('rounded-square');
    setIconStyle('flat');
    setCustomRotation({ x: 0, y: 0, z: 0 });
    setCustomScale(1);
    setIs3DEnabled(true);
    
    setIconData({
      color: defaultColor,
      shape: 'rounded-square',
      style: 'flat',
      is3D: true,
      customizations: {
        rotation: { x: 0, y: 0, z: 0 },
        scale: 1
      }
    });
    
    // Show reset animation
    Animated.sequence([
      Animated.timing(scaleValue, {
        toValue: 0.5,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(scaleValue, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start();
  };
  
  // Success animation
  const animateSuccess = () => {
    // Rotate icon 360 degrees
    Animated.sequence([
      Animated.timing(rotationValue, {
        toValue: 360,
        duration: 600,
        useNativeDriver: true,
      })
    ]).start(() => {
      rotationValue.setValue(0);
    });
    
    // Scale up and down
    Animated.sequence([
      Animated.timing(scaleValue, {
        toValue: 1.2,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(scaleValue, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start();
  };
  
  // Handle color picker
  const ColorPicker = () => {
    const predefinedColors = [
      '#F44336', '#E91E63', '#9C27B0', '#673AB7', 
      '#3F51B5', '#2196F3', '#03A9F4', '#00BCD4',
      '#009688', '#4CAF50', '#8BC34A', '#CDDC39',
      '#FFEB3B', '#FFC107', '#FF9800', '#FF5722',
      '#795548', '#9E9E9E', '#607D8B', '#000000'
    ];
    
    return (
      <View style={styles.colorPicker}>
        <Text style={styles.sectionTitle}>Icon Color</Text>
        <View style={styles.colorInputContainer}>
          <View style={[styles.colorPreview, { backgroundColor: iconColor }]} />
          <TextInput
            style={styles.colorInput}
            value={iconColor}
            onChangeText={setIconColor}
            placeholder="#RRGGBB"
            placeholderTextColor="#999"
          />
        </View>
        <View style={styles.colorGrid}>
          {predefinedColors.map((color, index) => (
            <TouchableOpacity
              key={`color-${index}`}
              style={[
                styles.colorOption,
                { backgroundColor: color },
                iconColor === color && styles.selectedColorOption
              ]}
              onPress={() => setIconColor(color)}
            />
          ))}
        </View>
      </View>
    );
  };
  
  // Shape selector
  const ShapeSelector = () => {
    const shapes = [
      { id: 'rounded-square', name: 'Rounded Square', icon: 'square' },
      { id: 'square', name: 'Square', icon: 'square' },
      { id: 'circle', name: 'Circle', icon: 'circle' }
    ];
    
    return (
      <View style={styles.shapeSelector}>
        <Text style={styles.sectionTitle}>Icon Shape</Text>
        <View style={styles.shapeOptions}>
          {shapes.map((shape) => (
            <TouchableOpacity
              key={shape.id}
              style={[
                styles.shapeOption,
                iconShape === shape.id && styles.selectedShapeOption
              ]}
              onPress={() => setIconShape(shape.id)}
            >
              <Feather
                name={shape.icon}
                size={24}
                color={iconShape === shape.id ? '#FFFFFF' : '#000000'}
              />
              <Text
                style={[
                  styles.shapeText,
                  iconShape === shape.id && styles.selectedShapeText
                ]}
              >
                {shape.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    );
  };
  
  // Style selector
  const StyleSelector = () => {
    const styles = [
      { id: 'flat', name: 'Flat' },
      { id: 'realistic', name: 'Realistic' },
      { id: 'glowing', name: 'Glowing' },
      { id: 'minimal', name: 'Minimal' }
    ];
    
    return (
      <View style={stylesObj.styleSelector}>
        <Text style={stylesObj.sectionTitle}>Icon Style</Text>
        <View style={stylesObj.styleOptions}>
          {styles.map((style) => (
            <TouchableOpacity
              key={style.id}
              style={[
                stylesObj.styleOption,
                iconStyle === style.id && stylesObj.selectedStyleOption
              ]}
              onPress={() => setIconStyle(style.id)}
            >
              <Text
                style={[
                  stylesObj.styleText,
                  iconStyle === style.id && stylesObj.selectedStyleText
                ]}
              >
                {style.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    );
  };
  
  // 3D Rotation controls
  const RotationControls = () => {
    return (
      <View style={styles.rotationControls}>
        <Text style={styles.sectionTitle}>3D Rotation</Text>
        <View style={styles.rotationAxes}>
          {/* X Axis */}
          <View style={styles.rotationAxis}>
            <Text style={styles.axisLabel}>X: {customRotation.x}°</Text>
            <View style={styles.sliderContainer}>
              <TouchableOpacity 
                style={styles.sliderButton}
                onPress={() => setCustomRotation({ ...customRotation, x: Math.max(customRotation.x - 15, -180) })}
              >
                <Feather name="minus" size={20} color="#000" />
              </TouchableOpacity>
              <View 
                style={styles.slider}
                onStartShouldSetResponder={() => true}
                onResponderRelease={(e) => {
                  const { locationX, target } = e.nativeEvent;
                  target.measure((x, y, width) => {
                    const percentage = Math.min(Math.max(locationX / width, 0), 1);
                    setCustomRotation({ 
                      ...customRotation, 
                      x: Math.round(percentage * 360 - 180) 
                    });
                  });
                }}
              >
                <View style={[
                  styles.sliderThumb, 
                  { left: `${((customRotation.x + 180) / 360) * 100}%` }
                ]} />
              </View>
              <TouchableOpacity 
                style={styles.sliderButton}
                onPress={() => setCustomRotation({ ...customRotation, x: Math.min(customRotation.x + 15, 180) })}
              >
                <Feather name="plus" size={20} color="#000" />
              </TouchableOpacity>
            </View>
          </View>
          
          {/* Y Axis */}
          <View style={styles.rotationAxis}>
            <Text style={styles.axisLabel}>Y: {customRotation.y}°</Text>
            <View style={styles.sliderContainer}>
              <TouchableOpacity 
                style={styles.sliderButton}
                onPress={() => setCustomRotation({ ...customRotation, y: Math.max(customRotation.y - 15, -180) })}
              >
                <Feather name="minus" size={20} color="#000" />
              </TouchableOpacity>
              <View 
                style={styles.slider}
                onStartShouldSetResponder={() => true}
                onResponderRelease={(e) => {
                  const { locationX, target } = e.nativeEvent;
                  target.measure((x, y, width) => {
                    const percentage = Math.min(Math.max(locationX / width, 0), 1);
                    setCustomRotation({ 
                      ...customRotation, 
                      y: Math.round(percentage * 360 - 180) 
                    });
                  });
                }}
              >
                <View style={[
                  styles.sliderThumb, 
                  { left: `${((customRotation.y + 180) / 360) * 100}%` }
                ]} />
              </View>
              <TouchableOpacity 
                style={styles.sliderButton}
                onPress={() => setCustomRotation({ ...customRotation, y: Math.min(customRotation.y + 15, 180) })}
              >
                <Feather name="plus" size={20} color="#000" />
              </TouchableOpacity>
            </View>
          </View>
          
          {/* Z Axis */}
          <View style={styles.rotationAxis}>
            <Text style={styles.axisLabel}>Z: {customRotation.z}°</Text>
            <View style={styles.sliderContainer}>
              <TouchableOpacity 
                style={styles.sliderButton}
                onPress={() => setCustomRotation({ ...customRotation, z: Math.max(customRotation.z - 15, -180) })}
              >
                <Feather name="minus" size={20} color="#000" />
              </TouchableOpacity>
              <View 
                style={styles.slider}
                onStartShouldSetResponder={() => true}
                onResponderRelease={(e) => {
                  const { locationX, target } = e.nativeEvent;
                  target.measure((x, y, width) => {
                    const percentage = Math.min(Math.max(locationX / width, 0), 1);
                    setCustomRotation({ 
                      ...customRotation, 
                      z: Math.round(percentage * 360 - 180) 
                    });
                  });
                }}
              >
                <View style={[
                  styles.sliderThumb, 
                  { left: `${((customRotation.z + 180) / 360) * 100}%` }
                ]} />
              </View>
              <TouchableOpacity 
                style={styles.sliderButton}
                onPress={() => setCustomRotation({ ...customRotation, z: Math.min(customRotation.z + 15, 180) })}
              >
                <Feather name="plus" size={20} color="#000" />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>
    );
  };
  
  // Scale control
  const ScaleControl = () => {
    return (
      <View style={styles.scaleControl}>
        <Text style={styles.sectionTitle}>Icon Scale: {customScale.toFixed(1)}</Text>
        <View style={styles.sliderContainer}>
          <TouchableOpacity 
            style={styles.sliderButton}
            onPress={() => setCustomScale(Math.max(customScale - 0.1, 0.5))}
          >
            <Feather name="minus" size={20} color="#000" />
          </TouchableOpacity>
          <View 
            style={styles.slider}
            onStartShouldSetResponder={() => true}
            onResponderRelease={(e) => {
              const { locationX, target } = e.nativeEvent;
              target.measure((x, y, width) => {
                const percentage = Math.min(Math.max(locationX / width, 0), 1);
                setCustomScale(0.5 + percentage * 1.5);
              });
            }}
          >
            <View style={[
              styles.sliderThumb, 
              { left: `${((customScale - 0.5) / 1.5) * 100}%` }
            ]} />
          </View>
          <TouchableOpacity 
            style={styles.sliderButton}
            onPress={() => setCustomScale(Math.min(customScale + 0.1, 2.0))}
          >
            <Feather name="plus" size={20} color="#000" />
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  
  if (!appInfo || !iconData) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading app information...</Text>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* App Information */}
        <View style={styles.appInfoContainer}>
          <Text style={styles.appName}>{appInfo.appName}</Text>
          <Text style={styles.packageName}>{appInfo.packageName}</Text>
        </View>
        
        {/* Icon Preview */}
        <View style={styles.previewContainer}>
          <Text style={styles.previewTitle}>Icon Preview</Text>
          <Animated.View
            style={[
              styles.iconPreview,
              {
                transform: [
                  { scale: scaleValue },
                  { rotateZ: rotationValue.interpolate({
                    inputRange: [0, 360],
                    outputRange: ['0deg', '360deg']
                  })}
                ]
              }
            ]}
          >
            <AppIcon
              packageName={packageName}
              size={100}
              style={iconStyle}
              theme={{ primaryColor: iconColor }}
            />
          </Animated.View>
        </View>
        
        {/* 3D Effects Switch */}
        <View style={styles.toggleContainer}>
          <Text style={styles.toggleLabel}>Enable 3D Effects</Text>
          <Switch
            value={is3DEnabled}
            onValueChange={setIs3DEnabled}
            trackColor={{ false: '#767577', true: '#81b0ff' }}
            thumbColor={is3DEnabled ? '#f5dd4b' : '#f4f3f4'}
          />
        </View>
        
        {/* Color Picker */}
        <ColorPicker />
        
        {/* Shape Selector */}
        <ShapeSelector />
        
        {/* Style Selector */}
        <StyleSelector />
        
        {/* 3D Controls (if enabled) */}
        {is3DEnabled && (
          <>
            <RotationControls />
            <ScaleControl />
          </>
        )}
        
        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={[styles.actionButton, styles.resetButton]}
            onPress={resetToDefault}
          >
            <Feather name="refresh-ccw" size={20} color="#FFFFFF" />
            <Text style={styles.actionButtonText}>Reset</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, styles.saveButton]}
            onPress={saveIconCustomizations}
          >
            <Feather name="check" size={20} color="#FFFFFF" />
            <Text style={styles.actionButtonText}>Save</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  scrollContent: {
    padding: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  appInfoContainer: {
    marginBottom: 20,
  },
  appName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  packageName: {
    fontSize: 14,
    color: '#666',
  },
  previewContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  previewTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#333',
  },
  iconPreview: {
    width: 120,
    height: 120,
    justifyContent: 'center',
    alignItems: 'center',
  },
  toggleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingHorizontal: 8,
    paddingVertical: 12,
    backgroundColor: '#FFF',
    borderRadius: 8,
    elevation: 2,
  },
  toggleLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#333',
  },
  colorPicker: {
    marginBottom: 20,
    padding: 16,
    backgroundColor: '#FFF',
    borderRadius: 8,
    elevation: 2,
  },
  colorInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  colorPreview: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#DDD',
  },
  colorInput: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 4,
    paddingHorizontal: 12,
    color: '#333',
  },
  colorGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  colorOption: {
    width: (SCREEN_WIDTH - 64) / 5,
    height: (SCREEN_WIDTH - 64) / 5,
    margin: 4,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#DDD',
  },
  selectedColorOption: {
    borderWidth: 3,
    borderColor: '#2196F3',
  },
  shapeSelector: {
    marginBottom: 20,
    padding: 16,
    backgroundColor: '#FFF',
    borderRadius: 8,
    elevation: 2,
  },
  shapeOptions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  shapeOption: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#DDD',
    width: (SCREEN_WIDTH - 80) / 3,
  },
  selectedShapeOption: {
    backgroundColor: '#2196F3',
    borderColor: '#2196F3',
  },
  shapeText: {
    marginTop: 8,
    fontSize: 12,
    color: '#333',
  },
  selectedShapeText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  rotationControls: {
    marginBottom: 20,
    padding: 16,
    backgroundColor: '#FFF',
    borderRadius: 8,
    elevation: 2,
  },
  rotationAxes: {
    width: '100%',
  },
  rotationAxis: {
    marginBottom: 16,
  },
  axisLabel: {
    fontSize: 14,
    marginBottom: 8,
    color: '#333',
  },
  sliderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 40,
  },
  sliderButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F0F0F0',
    borderRadius: 20,
  },
  slider: {
    flex: 1,
    height: 8,
    backgroundColor: '#E0E0E0',
    borderRadius: 4,
    marginHorizontal: 12,
    position: 'relative',
  },
  sliderThumb: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#2196F3',
    position: 'absolute',
    top: -6,
    marginLeft: -10,
  },
  scaleControl: {
    marginBottom: 20,
    padding: 16,
    backgroundColor: '#FFF',
    borderRadius: 8,
    elevation: 2,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    minWidth: 120,
  },
  resetButton: {
    backgroundColor: '#FF5722',
  },
  saveButton: {
    backgroundColor: '#4CAF50',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
    marginLeft: 8,
  },
});

const stylesObj = StyleSheet.create({
  styleSelector: {
    marginBottom: 20,
    padding: 16,
    backgroundColor: '#FFF',
    borderRadius: 8,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#333',
  },
  styleOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  styleOption: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#DDD',
    marginBottom: 8,
    width: (SCREEN_WIDTH - 80) / 2 - 4,
  },
  selectedStyleOption: {
    backgroundColor: '#2196F3',
    borderColor: '#2196F3',
  },
  styleText: {
    fontSize: 14,
    color: '#333',
  },
  selectedStyleText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});

export default IconCustomizer;
