import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  PanResponder,
  Animated,
  Dimensions
} from 'react-native';
import { PreferenceService } from '../services/PreferenceService';
import Feather from 'react-native-vector-icons/Feather';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const WidgetTypes = {
  CLOCK: 'clock',
  CALENDAR: 'calendar',
  WEATHER: 'weather',
  BATTERY: 'battery',
  SHORTCUTS: 'shortcuts',
  NOTES: 'notes',
  CUSTOM: 'custom'
};

const CustomWidget = ({ widget, theme, onEdit }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [position, setPosition] = useState({
    x: widget.position?.x || 0,
    y: widget.position?.y || 0
  });
  const [dimensions, setDimensions] = useState({
    width: widget.dimensions?.width || 1,
    height: widget.dimensions?.height || 1
  });
  
  // Animation values
  const scale = useRef(new Animated.Value(1)).current;
  const opacity = useRef(new Animated.Value(1)).current;
  const widgetPosition = useRef(new Animated.ValueXY({
    x: widget.position?.x || 0,
    y: widget.position?.y || 0
  })).current;
  
  // Calculate the widget size based on grid and dimensions
  const size = {
    width: (SCREEN_WIDTH - 48) * dimensions.width / 4,
    height: 80 * dimensions.height
  };
  
  // Setup PanResponder for dragging
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => isEditing,
      onMoveShouldSetPanResponder: () => isEditing,
      onPanResponderGrant: () => {
        // Start drag
        Animated.spring(scale, {
          toValue: 1.1,
          friction: 5,
          useNativeDriver: true
        }).start();
      },
      onPanResponderMove: Animated.event(
        [
          null,
          { dx: widgetPosition.x, dy: widgetPosition.y }
        ],
        { useNativeDriver: false }
      ),
      onPanResponderRelease: (_, gestureState) => {
        // End drag
        Animated.spring(scale, {
          toValue: 1,
          friction: 5,
          useNativeDriver: true
        }).start();
        
        // Update position
        const newPosition = {
          x: position.x + gestureState.dx,
          y: position.y + gestureState.dy
        };
        
        setPosition(newPosition);
        updateWidgetPosition(newPosition);
      }
    })
  ).current;
  
  // Set up resize handlers
  const handleResize = (newWidth, newHeight) => {
    const updatedDimensions = {
      width: Math.max(1, Math.min(4, newWidth)),
      height: Math.max(1, Math.min(4, newHeight))
    };
    
    setDimensions(updatedDimensions);
    updateWidgetDimensions(updatedDimensions);
  };
  
  // Update widget position in storage
  const updateWidgetPosition = async (newPosition) => {
    try {
      const widgets = await PreferenceService.getItem('widgets', '[]');
      const widgetList = JSON.parse(widgets);
      
      const updatedWidgets = widgetList.map(w => {
        if (w.id === widget.id) {
          return {
            ...w,
            position: newPosition
          };
        }
        return w;
      });
      
      await PreferenceService.setItem('widgets', JSON.stringify(updatedWidgets));
    } catch (error) {
      console.error('Failed to update widget position:', error);
    }
  };
  
  // Update widget dimensions in storage
  const updateWidgetDimensions = async (newDimensions) => {
    try {
      const widgets = await PreferenceService.getItem('widgets', '[]');
      const widgetList = JSON.parse(widgets);
      
      const updatedWidgets = widgetList.map(w => {
        if (w.id === widget.id) {
          return {
            ...w,
            dimensions: newDimensions
          };
        }
        return w;
      });
      
      await PreferenceService.setItem('widgets', JSON.stringify(updatedWidgets));
    } catch (error) {
      console.error('Failed to update widget dimensions:', error);
    }
  };
  
  // Toggle edit mode
  const toggleEditMode = () => {
    setIsEditing(!isEditing);
    
    // Animate the widget when toggling edit mode
    Animated.sequence([
      Animated.timing(scale, {
        toValue: isEditing ? 1 : 1.05,
        duration: 100,
        useNativeDriver: true
      }),
      Animated.timing(scale, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true
      })
    ]).start();
  };
  
  // Delete the widget
  const deleteWidget = async () => {
    try {
      // Animate the widget out
      Animated.timing(opacity, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true
      }).start(async () => {
        // Remove from storage
        const widgets = await PreferenceService.getItem('widgets', '[]');
        const widgetList = JSON.parse(widgets);
        
        const updatedWidgets = widgetList.filter(w => w.id !== widget.id);
        
        await PreferenceService.setItem('widgets', JSON.stringify(updatedWidgets));
      });
    } catch (error) {
      console.error('Failed to delete widget:', error);
    }
  };
  
  // Render widget content based on type
  const renderWidgetContent = () => {
    switch (widget.type) {
      case WidgetTypes.CLOCK:
        return <ClockWidget widget={widget} theme={theme} />;
      case WidgetTypes.CALENDAR:
        return <CalendarWidget widget={widget} theme={theme} />;
      case WidgetTypes.WEATHER:
        return <WeatherWidget widget={widget} theme={theme} />;
      case WidgetTypes.BATTERY:
        return <BatteryWidget widget={widget} theme={theme} />;
      case WidgetTypes.SHORTCUTS:
        return <ShortcutsWidget widget={widget} theme={theme} />;
      case WidgetTypes.NOTES:
        return <NotesWidget widget={widget} theme={theme} />;
      case WidgetTypes.CUSTOM:
        return <CustomContentWidget widget={widget} theme={theme} />;
      default:
        return (
          <View style={styles.defaultWidget}>
            <Text style={[styles.defaultWidgetText, { color: theme.textColor }]}>
              Widget: {widget.name}
            </Text>
          </View>
        );
    }
  };
  
  return (
    <Animated.View
      style={[
        styles.container,
        {
          width: size.width,
          height: size.height,
          backgroundColor: theme.cardColor,
          borderRadius: theme.borderRadius || 8,
          shadowColor: theme.shadowColor
        },
        {
          transform: [
            { translateX: widgetPosition.x },
            { translateY: widgetPosition.y },
            { scale: scale }
          ],
          opacity: opacity
        }
      ]}
      {...panResponder.panHandlers}
    >
      {isEditing && (
        <View style={styles.controlsContainer}>
          <TouchableOpacity
            style={[styles.controlButton, { backgroundColor: theme.primaryColor }]}
            onPress={toggleEditMode}
          >
            <Feather name="check" size={14} color="#FFF" />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.controlButton, { backgroundColor: theme.accentColor }]}
            onPress={onEdit}
          >
            <Feather name="edit-2" size={14} color="#FFF" />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.controlButton, { backgroundColor: '#FF5252' }]}
            onPress={deleteWidget}
          >
            <Feather name="trash-2" size={14} color="#FFF" />
          </TouchableOpacity>
          
          <View style={styles.resizeControls}>
            <TouchableOpacity
              style={[styles.resizeButton, { backgroundColor: theme.secondaryColor }]}
              onPress={() => handleResize(dimensions.width - 1, dimensions.height)}
            >
              <Feather name="minus" size={14} color="#FFF" />
              <Feather name="arrow-right" size={14} color="#FFF" />
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.resizeButton, { backgroundColor: theme.secondaryColor }]}
              onPress={() => handleResize(dimensions.width + 1, dimensions.height)}
            >
              <Feather name="plus" size={14} color="#FFF" />
              <Feather name="arrow-right" size={14} color="#FFF" />
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.resizeButton, { backgroundColor: theme.secondaryColor }]}
              onPress={() => handleResize(dimensions.width, dimensions.height - 1)}
            >
              <Feather name="minus" size={14} color="#FFF" />
              <Feather name="arrow-down" size={14} color="#FFF" />
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.resizeButton, { backgroundColor: theme.secondaryColor }]}
              onPress={() => handleResize(dimensions.width, dimensions.height + 1)}
            >
              <Feather name="plus" size={14} color="#FFF" />
              <Feather name="arrow-down" size={14} color="#FFF" />
            </TouchableOpacity>
          </View>
        </View>
      )}
      
      <TouchableOpacity
        style={styles.widgetContent}
        onLongPress={toggleEditMode}
        activeOpacity={0.8}
      >
        {renderWidgetContent()}
      </TouchableOpacity>
    </Animated.View>
  );
};

// Clock Widget Component
const ClockWidget = ({ widget, theme }) => {
  const [time, setTime] = useState(new Date());
  
  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);
  
  const formatTime = () => {
    return time.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
      ...(widget.config?.showSeconds ? { second: '2-digit' } : {})
    });
  };
  
  const formatDate = () => {
    return time.toLocaleDateString([], {
      weekday: 'long',
      month: 'long',
      day: 'numeric'
    });
  };
  
  return (
    <View style={styles.clockWidget}>
      <Text style={[styles.clockTime, { color: theme.textColor }]}>
        {formatTime()}
      </Text>
      {widget.config?.showDate && (
        <Text style={[styles.clockDate, { color: theme.textColor + 'CC' }]}>
          {formatDate()}
        </Text>
      )}
    </View>
  );
};

// Calendar Widget Component
const CalendarWidget = ({ widget, theme }) => {
  const [date, setDate] = useState(new Date());
  
  return (
    <View style={styles.calendarWidget}>
      <Text style={[styles.calendarMonth, { color: theme.primaryColor }]}>
        {date.toLocaleString('default', { month: 'long' })}
      </Text>
      <Text style={[styles.calendarDay, { color: theme.textColor }]}>
        {date.getDate()}
      </Text>
      <Text style={[styles.calendarWeekday, { color: theme.textColor + 'CC' }]}>
        {date.toLocaleString('default', { weekday: 'long' })}
      </Text>
    </View>
  );
};

// Weather Widget Component (Simplified)
const WeatherWidget = ({ widget, theme }) => {
  // In a real app, this would fetch weather data from an API
  const weatherData = {
    temperature: 72,
    condition: 'Sunny',
    icon: 'sun'
  };
  
  return (
    <View style={styles.weatherWidget}>
      <Feather name={weatherData.icon} size={32} color={theme.primaryColor} />
      <Text style={[styles.weatherTemp, { color: theme.textColor }]}>
        {weatherData.temperature}°
      </Text>
      <Text style={[styles.weatherCondition, { color: theme.textColor + 'CC' }]}>
        {weatherData.condition}
      </Text>
    </View>
  );
};

// Battery Widget Component
const BatteryWidget = ({ widget, theme }) => {
  // In a real app, this would get actual battery status
  const batteryLevel = 85;
  
  // Determine battery icon and color
  let batteryIcon = 'battery';
  let batteryColor = theme.primaryColor;
  
  if (batteryLevel > 75) {
    batteryIcon = 'battery';
    batteryColor = '#4CAF50'; // Green
  } else if (batteryLevel > 50) {
    batteryIcon = 'battery';
    batteryColor = theme.primaryColor;
  } else if (batteryLevel > 25) {
    batteryIcon = 'battery-charging';
    batteryColor = '#FFC107'; // Amber
  } else {
    batteryIcon = 'battery-charging';
    batteryColor = '#F44336'; // Red
  }
  
  return (
    <View style={styles.batteryWidget}>
      <Feather name={batteryIcon} size={32} color={batteryColor} />
      <Text style={[styles.batteryLevel, { color: theme.textColor }]}>
        {batteryLevel}%
      </Text>
    </View>
  );
};

// Shortcuts Widget Component
const ShortcutsWidget = ({ widget, theme }) => {
  // Sample shortcuts
  const shortcuts = widget.config?.shortcuts || [
    { name: 'Phone', icon: 'phone' },
    { name: 'Messages', icon: 'message-circle' },
    { name: 'Camera', icon: 'camera' },
    { name: 'Browser', icon: 'globe' }
  ];
  
  return (
    <View style={styles.shortcutsWidget}>
      {shortcuts.map((shortcut, index) => (
        <TouchableOpacity 
          key={`shortcut-${index}`}
          style={styles.shortcutItem}
        >
          <View 
            style={[
              styles.shortcutIcon, 
              { backgroundColor: theme.primaryColor + '22' }
            ]}
          >
            <Feather name={shortcut.icon} size={20} color={theme.primaryColor} />
          </View>
          <Text 
            style={[styles.shortcutName, { color: theme.textColor }]}
            numberOfLines={1}
          >
            {shortcut.name}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

// Notes Widget Component
const NotesWidget = ({ widget, theme }) => {
  return (
    <View style={styles.notesWidget}>
      <Text style={[styles.notesTitle, { color: theme.primaryColor }]}>
        {widget.config?.title || 'Notes'}
      </Text>
      <Text 
        style={[styles.notesContent, { color: theme.textColor }]}
        numberOfLines={5}
      >
        {widget.config?.content || 'Tap to edit your notes...'}
      </Text>
    </View>
  );
};

// Custom Content Widget Component
const CustomContentWidget = ({ widget, theme }) => {
  return (
    <View style={styles.customWidget}>
      <Text style={[styles.customWidgetTitle, { color: theme.primaryColor }]}>
        {widget.name}
      </Text>
      <Text style={[styles.customWidgetContent, { color: theme.textColor }]}>
        {widget.config?.content || 'Custom widget content'}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    margin: 8,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 4,
    overflow: 'hidden',
  },
  controlsContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    padding: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    zIndex: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
  },
  controlButton: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 2,
  },
  resizeControls: {
    flexDirection: 'row',
  },
  resizeButton: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 2,
  },
  widgetContent: {
    flex: 1,
    padding: 12,
  },
  defaultWidget: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  defaultWidgetText: {
    fontSize: 14,
    textAlign: 'center',
  },
  // Clock Widget Styles
  clockWidget: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  clockTime: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  clockDate: {
    fontSize: 14,
    marginTop: 4,
  },
  // Calendar Widget Styles
  calendarWidget: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  calendarMonth: {
    fontSize: 16,
    fontWeight: '500',
  },
  calendarDay: {
    fontSize: 28,
    fontWeight: 'bold',
    marginVertical: 4,
  },
  calendarWeekday: {
    fontSize: 14,
  },
  // Weather Widget Styles
  weatherWidget: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  weatherTemp: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 4,
  },
  weatherCondition: {
    fontSize: 14,
  },
  // Battery Widget Styles
  batteryWidget: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  batteryLevel: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 8,
  },
  // Shortcuts Widget Styles
  shortcutsWidget: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  shortcutItem: {
    alignItems: 'center',
    marginHorizontal: 4,
    marginVertical: 8,
  },
  shortcutIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  shortcutName: {
    fontSize: 12,
    maxWidth: 60,
    textAlign: 'center',
  },
  // Notes Widget Styles
  notesWidget: {
    flex: 1,
    padding: 4,
  },
  notesTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  notesContent: {
    fontSize: 14,
    flex: 1,
  },
  // Custom Widget Styles
  customWidget: {
    flex: 1,
    padding: 4,
  },
  customWidgetTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  customWidgetContent: {
    fontSize: 14,
  },
});

export default CustomWidget;
