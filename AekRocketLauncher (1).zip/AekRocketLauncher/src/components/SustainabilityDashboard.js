/**
 * SustainabilityDashboard component
 * Shows eco-stats, energy usage, and sustainable app recommendations
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
  ActivityIndicator
} from 'react-native';
import { MaterialIcons, Ionicons, FontAwesome } from 'react-native-vector-icons';
import { SustainabilityService } from '../services/SustainabilityService';
import { AppService } from '../services/AppService';

// Mock LineChart component - in a real app, use a charting library
const LineChart = ({ data, width, height, chartConfig }) => {
  return (
    <View style={{ width, height, backgroundColor: chartConfig.backgroundColor, borderRadius: 8 }}>
      <Text style={{ color: chartConfig.color, padding: 8, fontSize: 12 }}>Energy Usage Chart (mW)</Text>
      <View style={{ flex: 1, flexDirection: 'row', alignItems: 'flex-end', padding: 8 }}>
        {data.map((value, index) => (
          <View 
            key={index} 
            style={{
              backgroundColor: chartConfig.color,
              width: (width - 32) / data.length - 2,
              height: (value / Math.max(...data)) * (height - 60),
              marginHorizontal: 1
            }}
          />
        ))}
      </View>
    </View>
  );
};

const SustainabilityDashboard = ({ navigation }) => {
  // State
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState(null);
  const [resourceIntensiveApps, setResourceIntensiveApps] = useState([]);
  const [suggestions, setSuggestions] = useState([]);
  const [dailyEnergyData, setDailyEnergyData] = useState([]);
  
  // Screen dimensions for chart
  const screenWidth = Dimensions.get('window').width;
  
  // Load data on component mount
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        // Initialize the sustainability service if needed
        if (!SustainabilityService.getStatus().enabled) {
          await SustainabilityService.initialize();
        }
        
        // Get energy statistics
        const energyStats = SustainabilityService.getEnergyStats();
        setStats(energyStats);
        
        // Extract resource-intensive apps
        setResourceIntensiveApps(energyStats.resourceIntensiveApps || []);
        
        // Get sustainability status with suggestions
        const status = SustainabilityService.getStatus();
        setSuggestions(status.suggestions || []);
        
        // Prepare daily energy data for chart
        prepareDailyEnergyData(energyStats.daily || []);
        
        // Subscribe to sustainability service updates
        SustainabilityService.subscribe(onSustainabilityUpdate);
        
        setLoading(false);
      } catch (error) {
        console.error('Failed to load sustainability dashboard:', error);
        setLoading(false);
      }
    };
    
    loadData();
    
    // Cleanup subscription on unmount
    return () => {
      SustainabilityService.unsubscribe(onSustainabilityUpdate);
    };
  }, []);
  
  // Handle sustainability service updates
  const onSustainabilityUpdate = (event, data) => {
    if (event === 'energyUpdated') {
      setStats(data);
      setResourceIntensiveApps(data.resourceIntensiveApps || []);
      prepareDailyEnergyData(data.dailyEnergyUsage || []);
    } else if (event === 'settingsLoaded' || event === 'settingChanged') {
      setSuggestions(data.state?.suggestions || data?.suggestions || []);
    }
  };
  
  // Prepare data for energy chart
  const prepareDailyEnergyData = (dailyData) => {
    if (!dailyData || dailyData.length === 0) {
      setDailyEnergyData([150, 160, 140, 170, 160, 180, 190, 170, 150, 140, 160, 150]);
      return;
    }
    
    // Take last 12 entries for the chart
    const chartData = dailyData.slice(-12).map(item => item.powerConsumption);
    setDailyEnergyData(chartData);
  };
  
  // Apply a suggestion
  const applySuggestion = async (suggestion) => {
    try {
      switch (suggestion.action) {
        case 'enableDarkModeSchedule':
          await SustainabilityService.applySetting('darkModeSchedule', true);
          break;
        case 'adjustScreenTimeout':
          await SustainabilityService.applySetting('screenTimeoutDuration', 30);
          break;
        case 'reduceAnimations':
          // Apply reduced animations via performance utils
          await SustainabilityService.applySetting('energyMode', 'eco');
          break;
        case 'switchWallpaper':
          // Navigate to wallpaper selection with eco filter
          navigation.navigate('WallpaperEditor', { ecoFilter: true });
          break;
        default:
          console.log('Unknown suggestion action:', suggestion.action);
      }
    } catch (error) {
      console.error('Failed to apply suggestion:', error);
    }
  };
  
  // Format impact label based on level
  const getImpactLabel = (impact) => {
    switch (impact) {
      case 'high':
        return { text: 'High Impact', color: '#CC3300' };
      case 'medium':
        return { text: 'Medium Impact', color: '#FF9900' };
      case 'low':
        return { text: 'Low Impact', color: '#33AA33' };
      default:
        return { text: 'Unknown Impact', color: '#666666' };
    }
  };
  
  // Render loading state
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0A8A0A" />
        <Text style={styles.loadingText}>Loading sustainability data...</Text>
      </View>
    );
  }
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <Ionicons name="leaf" size={32} color="#0A8A0A" />
          <View style={styles.headerTextContainer}>
            <Text style={styles.headerTitle}>Eco Dashboard</Text>
            <Text style={styles.headerSubtitle}>Monitor your device's environmental impact</Text>
          </View>
        </View>
      </View>
      
      {/* Environmental Impact Summary */}
      <View style={styles.impactSummaryContainer}>
        <View style={styles.impactItem}>
          <Ionicons name="battery" size={28} color="#0A8A0A" />
          <Text style={styles.impactValue}>
            {Math.round(stats?.environmentalImpact?.energySaved || 0)} mWh
          </Text>
          <Text style={styles.impactLabel}>Energy Saved</Text>
        </View>
        
        <View style={styles.impactItem}>
          <MaterialIcons name="co2" size={28} color="#0A8A0A" />
          <Text style={styles.impactValue}>
            {Math.round(stats?.environmentalImpact?.co2Saved || 0)}g
          </Text>
          <Text style={styles.impactLabel}>CO₂ Reduced</Text>
        </View>
        
        <View style={styles.impactItem}>
          <Ionicons name="leaf" size={28} color="#0A8A0A" />
          <Text style={styles.impactValue}>
            {parseFloat(stats?.environmentalImpact?.treesEquivalent || 0).toFixed(3)}
          </Text>
          <Text style={styles.impactLabel}>Trees Equivalent</Text>
        </View>
      </View>
      
      {/* Energy Usage Chart */}
      <View style={styles.chartContainer}>
        <Text style={styles.sectionTitle}>Energy Consumption (Last 12 Hours)</Text>
        <LineChart
          data={dailyEnergyData}
          width={screenWidth - 32}
          height={180}
          chartConfig={{
            backgroundColor: '#F0F8F0',
            color: '#0A8A0A',
          }}
        />
      </View>
      
      {/* Resource-Intensive Apps */}
      {resourceIntensiveApps.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Resource-Intensive Apps</Text>
          <Text style={styles.sectionDescription}>
            These apps are consuming significant battery power
          </Text>
          
          {resourceIntensiveApps.map((app, index) => (
            <View key={index} style={styles.resourceAppItem}>
              <View style={styles.resourceAppIcon}>
                <FontAwesome name="android" size={24} color="#0A8A0A" />
              </View>
              
              <View style={styles.resourceAppDetails}>
                <Text style={styles.resourceAppName}>
                  {app.packageName.split('.').pop()}
                </Text>
                <Text style={styles.resourceAppStats}>
                  CPU: {app.cpuTime}s | Network: {app.networkUsage}MB
                </Text>
              </View>
              
              <View style={[styles.resourceAppImpact, { backgroundColor: app.impact === 'high' ? '#FFEEEE' : '#EEFFEE' }]}>
                <Text style={[styles.resourceAppImpactText, { color: app.impact === 'high' ? '#CC3300' : '#33AA33' }]}>
                  {app.impact.toUpperCase()}
                </Text>
              </View>
            </View>
          ))}
        </View>
      )}
      
      {/* Sustainability Suggestions */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Sustainability Suggestions</Text>
        
        {suggestions.length === 0 ? (
          <Text style={styles.noSuggestionsText}>
            No suggestions available at this time. Your device is optimized for eco-friendly use!
          </Text>
        ) : (
          suggestions.map((suggestion, index) => {
            const impactInfo = getImpactLabel(suggestion.impact);
            
            return (
              <View key={index} style={styles.suggestionItem}>
                <View style={styles.suggestionHeader}>
                  <Ionicons name="bulb" size={20} color="#0A8A0A" />
                  <Text style={styles.suggestionTitle}>{suggestion.title}</Text>
                  <View style={[styles.impactBadge, { backgroundColor: impactInfo.color + '20' }]}>
                    <Text style={[styles.impactBadgeText, { color: impactInfo.color }]}>
                      {impactInfo.text}
                    </Text>
                  </View>
                </View>
                
                <Text style={styles.suggestionDescription}>{suggestion.description}</Text>
                
                <TouchableOpacity
                  style={styles.applySuggestionButton}
                  onPress={() => applySuggestion(suggestion)}
                >
                  <Text style={styles.applySuggestionText}>Apply</Text>
                </TouchableOpacity>
              </View>
            );
          })
        )}
      </View>
      
      {/* Open Settings Button */}
      <TouchableOpacity
        style={styles.openSettingsButton}
        onPress={() => navigation.navigate('SustainabilitySettings')}
      >
        <Ionicons name="settings" size={20} color="white" />
        <Text style={styles.openSettingsText}>Sustainability Settings</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#333',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 20,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerTextContainer: {
    marginLeft: 12,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333333',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#666666',
    marginTop: 2,
  },
  impactSummaryContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  impactItem: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  impactValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginTop: 8,
  },
  impactLabel: {
    fontSize: 12,
    color: '#666666',
    marginTop: 4,
  },
  chartContainer: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    marginTop: 0,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  section: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    marginTop: 0,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 12,
  },
  sectionDescription: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 16,
  },
  resourceAppItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  resourceAppIcon: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: '#F0F8F0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  resourceAppDetails: {
    flex: 1,
    marginLeft: 12,
  },
  resourceAppName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  resourceAppStats: {
    fontSize: 12,
    color: '#666666',
    marginTop: 2,
  },
  resourceAppImpact: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    marginLeft: 8,
  },
  resourceAppImpactText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  noSuggestionsText: {
    fontSize: 14,
    color: '#666666',
    fontStyle: 'italic',
    textAlign: 'center',
    marginVertical: 16,
  },
  suggestionItem: {
    backgroundColor: '#F0F8F0',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  suggestionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  suggestionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    flex: 1,
    marginLeft: 8,
  },
  impactBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  impactBadgeText: {
    fontSize: 10,
    fontWeight: 'bold',
  },
  suggestionDescription: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 12,
  },
  applySuggestionButton: {
    backgroundColor: '#0A8A0A',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 4,
    alignSelf: 'flex-end',
  },
  applySuggestionText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  openSettingsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0A8A0A',
    margin: 16,
    marginTop: 0,
    paddingVertical: 16,
    borderRadius: 12,
  },
  openSettingsText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    marginLeft: 8,
  }
});

export default SustainabilityDashboard;