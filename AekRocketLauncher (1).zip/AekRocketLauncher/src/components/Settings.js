import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Dimensions,
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import { PreferenceService } from '../services/PreferenceService';
import { ThemeService } from '../services/ThemeService';
import { performanceUtils } from '../utils/performanceUtils';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const Settings = ({ navigation }) => {
  // State for all settings
  const [theme, setTheme] = useState({});
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [performanceMode, setPerformanceMode] = useState('balanced');
  const [animationSpeed, setAnimationSpeed] = useState('normal');
  const [iconSize, setIconSize] = useState('medium');
  const [iconSpacing, setIconSpacing] = useState('normal');
  const [effectsEnabled, setEffectsEnabled] = useState({
    blur: true,
    reflections: true,
    bloom: true,
  });
  const [gridSize, setGridSize] = useState({
    columns: 5,
    rows: 6,
  });
  const [wallpaperType, setWallpaperType] = useState('static');
  
  // Load settings on component mount
  useEffect(() => {
    const loadSettings = async () => {
      // Load current theme
      const currentTheme = await ThemeService.getCurrentTheme();
      setTheme(currentTheme);
      setIsDarkMode(currentTheme.isDark);
      
      // Load performance mode
      const perfMode = await PreferenceService.getItem('performanceMode', 'balanced');
      setPerformanceMode(perfMode);
      
      // Load animation speed
      const speed = await PreferenceService.getItem('animationSpeed', 'normal');
      setAnimationSpeed(speed);
      
      // Load icon size
      const size = await PreferenceService.getItem('iconSize', 'medium');
      setIconSize(size);
      
      // Load icon spacing
      const spacing = await PreferenceService.getItem('iconSpacing', 'normal');
      setIconSpacing(spacing);
      
      // Load visual effects settings
      const blur = await PreferenceService.getItem('enableBlur', true);
      const reflections = await PreferenceService.getItem('enableReflections', true);
      const bloom = await PreferenceService.getItem('enableBloom', true);
      
      setEffectsEnabled({
        blur,
        reflections,
        bloom,
      });
      
      // Load grid size
      const grid = await PreferenceService.getItem('gridSize', { columns: 5, rows: 6 });
      setGridSize(grid);
      
      // Load wallpaper type
      const wallpaper = await PreferenceService.getItem('wallpaperType', 'static');
      setWallpaperType(wallpaper);
    };
    
    loadSettings();
  }, []);
  
  // Toggle dark mode
  const toggleDarkMode = async () => {
    const newValue = !isDarkMode;
    setIsDarkMode(newValue);
    
    // Apply corresponding theme
    const themeId = newValue ? 'dark' : 'default';
    await ThemeService.setTheme(themeId);
    
    // Update theme state
    const newTheme = await ThemeService.getCurrentTheme();
    setTheme(newTheme);
  };
  
  // Set performance mode
  const setPerformancePreset = async (mode) => {
    setPerformanceMode(mode);
    await PreferenceService.setItem('performanceMode', mode);
    
    // Apply performance settings
    performanceUtils.setPerformanceMode(mode);
    
    // Update visual effects based on performance mode
    const settings = performanceUtils.getCurrentSettings();
    setEffectsEnabled({
      blur: settings.rendering.enableBlur,
      reflections: settings.threejs.reflectionQuality !== 'low',
      bloom: settings.threejs.enableBloom,
    });
    
    // Save to preferences
    await PreferenceService.setItem('enableBlur', settings.rendering.enableBlur);
    await PreferenceService.setItem('enableReflections', settings.threejs.reflectionQuality !== 'low');
    await PreferenceService.setItem('enableBloom', settings.threejs.enableBloom);
  };
  
  // Set animation speed
  const setAnimationPreset = async (speed) => {
    setAnimationSpeed(speed);
    await PreferenceService.setItem('animationSpeed', speed);
  };
  
  // Set icon size
  const setIconSizePreset = async (size) => {
    setIconSize(size);
    await PreferenceService.setItem('iconSize', size);
  };
  
  // Set icon spacing
  const setIconSpacingPreset = async (spacing) => {
    setIconSpacing(spacing);
    await PreferenceService.setItem('iconSpacing', spacing);
  };
  
  // Toggle visual effect
  const toggleEffect = async (effect) => {
    const newValue = !effectsEnabled[effect];
    
    setEffectsEnabled({
      ...effectsEnabled,
      [effect]: newValue,
    });
    
    await PreferenceService.setItem(`enable${effect.charAt(0).toUpperCase() + effect.slice(1)}`, newValue);
  };
  
  // Set grid size
  const updateGridSize = async (property, value) => {
    const newGridSize = {
      ...gridSize,
      [property]: value,
    };
    
    setGridSize(newGridSize);
    await PreferenceService.setItem('gridSize', newGridSize);
  };
  
  // Set wallpaper type
  const setWallpaperPreset = async (type) => {
    setWallpaperType(type);
    await PreferenceService.setItem('wallpaperType', type);
  };
  
  // Reset all settings to default
  const resetAllSettings = () => {
    Alert.alert(
      'Reset Settings',
      'Are you sure you want to reset all settings to default values? This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Reset', 
          style: 'destructive',
          onPress: async () => {
            await PreferenceService.resetToDefaults();
            Alert.alert('Success', 'All settings have been reset to defaults. Please restart the launcher.');
            
            // Navigate back to home
            navigation.goBack();
          }
        },
      ]
    );
  };
  
  // Setting Item Component
  const SettingItem = ({ icon, title, description, children }) => (
    <View style={styles.settingItem}>
      <View style={styles.settingIconContainer}>
        <Feather name={icon} size={24} color={theme.primaryColor} />
      </View>
      <View style={styles.settingContent}>
        <View style={styles.settingTextContainer}>
          <Text style={[styles.settingTitle, { color: theme.textColor }]}>{title}</Text>
          {description && (
            <Text style={[styles.settingDescription, { color: theme.textColor + '99' }]}>
              {description}
            </Text>
          )}
        </View>
        <View style={styles.settingControl}>
          {children}
        </View>
      </View>
    </View>
  );
  
  // Option Button Component
  const OptionButton = ({ title, active, onPress }) => (
    <TouchableOpacity
      style={[
        styles.optionButton,
        { backgroundColor: active ? theme.primaryColor : theme.cardColor }
      ]}
      onPress={onPress}
    >
      <Text
        style={[
          styles.optionButtonText,
          { color: active ? '#FFFFFF' : theme.textColor }
        ]}
      >
        {title}
      </Text>
    </TouchableOpacity>
  );
  
  return (
    <ScrollView 
      style={[styles.container, { backgroundColor: theme.backgroundColor }]}
      contentContainerStyle={styles.contentContainer}
    >
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.primaryColor }]}>
          Appearance
        </Text>
        
        <SettingItem
          icon="moon"
          title="Dark Mode"
          description="Switch between light and dark theme"
        >
          <Switch
            value={isDarkMode}
            onValueChange={toggleDarkMode}
            trackColor={{ false: '#767577', true: theme.primaryColor }}
            thumbColor={isDarkMode ? theme.accentColor : '#f4f3f4'}
          />
        </SettingItem>
        
        <SettingItem
          icon="layout"
          title="Theme Editor"
          description="Customize colors and visual style"
        >
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: theme.primaryColor }]}
            onPress={() => navigation.navigate('ThemeEditor')}
          >
            <Text style={styles.actionButtonText}>Edit</Text>
          </TouchableOpacity>
        </SettingItem>
        
        <SettingItem
          icon="image"
          title="Wallpaper"
          description="Change 3D wallpaper style"
        >
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: theme.primaryColor }]}
            onPress={() => navigation.navigate('WallpaperEditor')}
          >
            <Text style={styles.actionButtonText}>Change</Text>
          </TouchableOpacity>
        </SettingItem>
      </View>
      
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.primaryColor }]}>
          Layout & Icons
        </Text>
        
        <SettingItem
          icon="grid"
          title="Icon Grid"
          description="Set grid columns and rows"
        >
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: theme.primaryColor }]}
            onPress={() => navigation.navigate('LayoutEditor')}
          >
            <Text style={styles.actionButtonText}>Edit</Text>
          </TouchableOpacity>
        </SettingItem>
        
        <SettingItem
          icon="maximize"
          title="Icon Size"
          description="Adjust the size of app icons"
        >
          <View style={styles.optionsRow}>
            <OptionButton
              title="S"
              active={iconSize === 'small'}
              onPress={() => setIconSizePreset('small')}
            />
            <OptionButton
              title="M"
              active={iconSize === 'medium'}
              onPress={() => setIconSizePreset('medium')}
            />
            <OptionButton
              title="L"
              active={iconSize === 'large'}
              onPress={() => setIconSizePreset('large')}
            />
          </View>
        </SettingItem>
        
        <SettingItem
          icon="align-center"
          title="Icon Spacing"
          description="Adjust space between icons"
        >
          <View style={styles.optionsRow}>
            <OptionButton
              title="Compact"
              active={iconSpacing === 'compact'}
              onPress={() => setIconSpacingPreset('compact')}
            />
            <OptionButton
              title="Normal"
              active={iconSpacing === 'normal'}
              onPress={() => setIconSpacingPreset('normal')}
            />
            <OptionButton
              title="Spacious"
              active={iconSpacing === 'spacious'}
              onPress={() => setIconSpacingPreset('spacious')}
            />
          </View>
        </SettingItem>
      </View>
      
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.primaryColor }]}>
          Performance & Animations
        </Text>
        
        <SettingItem
          icon="cpu"
          title="Performance Mode"
          description="Balance between visuals and speed"
        >
          <View style={styles.optionsRow}>
            <OptionButton
              title="Performance"
              active={performanceMode === 'performance'}
              onPress={() => setPerformancePreset('performance')}
            />
            <OptionButton
              title="Balanced"
              active={performanceMode === 'balanced'}
              onPress={() => setPerformancePreset('balanced')}
            />
            <OptionButton
              title="Quality"
              active={performanceMode === 'quality'}
              onPress={() => setPerformancePreset('quality')}
            />
          </View>
        </SettingItem>
        
        <SettingItem
          icon="clock"
          title="Animation Speed"
          description="Adjust animation duration"
        >
          <View style={styles.optionsRow}>
            <OptionButton
              title="Slow"
              active={animationSpeed === 'slow'}
              onPress={() => setAnimationPreset('slow')}
            />
            <OptionButton
              title="Normal"
              active={animationSpeed === 'normal'}
              onPress={() => setAnimationPreset('normal')}
            />
            <OptionButton
              title="Fast"
              active={animationSpeed === 'fast'}
              onPress={() => setAnimationPreset('fast')}
            />
          </View>
        </SettingItem>
        
        <SettingItem
          icon="droplet"
          title="Background Blur"
          description="Enable blur effects"
        >
          <Switch
            value={effectsEnabled.blur}
            onValueChange={() => toggleEffect('blur')}
            trackColor={{ false: '#767577', true: theme.primaryColor }}
            thumbColor={effectsEnabled.blur ? theme.accentColor : '#f4f3f4'}
          />
        </SettingItem>
        
        <SettingItem
          icon="sun"
          title="Bloom Effect"
          description="Glowing highlights"
        >
          <Switch
            value={effectsEnabled.bloom}
            onValueChange={() => toggleEffect('bloom')}
            trackColor={{ false: '#767577', true: theme.primaryColor }}
            thumbColor={effectsEnabled.bloom ? theme.accentColor : '#f4f3f4'}
          />
        </SettingItem>
        
        <SettingItem
          icon="droplet"
          title="Reflections"
          description="3D surface reflections"
        >
          <Switch
            value={effectsEnabled.reflections}
            onValueChange={() => toggleEffect('reflections')}
            trackColor={{ false: '#767577', true: theme.primaryColor }}
            thumbColor={effectsEnabled.reflections ? theme.accentColor : '#f4f3f4'}
          />
        </SettingItem>
      </View>
      
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.primaryColor }]}>
          Controls & Widgets
        </Text>
        
        <SettingItem
          icon="sliders"
          title="Gesture Controls"
          description="Customize swipes and gestures"
        >
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: theme.primaryColor }]}
            onPress={() => navigation.navigate('GestureEditor')}
          >
            <Text style={styles.actionButtonText}>Edit</Text>
          </TouchableOpacity>
        </SettingItem>
        
        <SettingItem
          icon="square"
          title="Widgets"
          description="Add and customize widgets"
        >
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: theme.primaryColor }]}
            onPress={() => navigation.navigate('WidgetEditor')}
          >
            <Text style={styles.actionButtonText}>Edit</Text>
          </TouchableOpacity>
        </SettingItem>

        <SettingItem
          icon="package-variant-plus"
          title="Feature Manager"
          description="Install and manage launcher features"
        >
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: theme.primaryColor }]}
            onPress={() => navigation.navigate('FeatureManager')}
          >
            <Text style={styles.actionButtonText}>Manage</Text>
          </TouchableOpacity>
        </SettingItem>
      </View>
      
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.primaryColor }]}>
          About & Reset
        </Text>
        
        <SettingItem
          icon="info"
          title="About 3D Launcher"
          description="Version 1.0.0"
        >
          <TouchableOpacity style={styles.iconButton}>
            <Feather name="external-link" size={20} color={theme.textColor} />
          </TouchableOpacity>
        </SettingItem>
        
        <SettingItem
          icon="refresh-cw"
          title="Reset All Settings"
          description="Restore default configuration"
        >
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: '#F44336' }]}
            onPress={resetAllSettings}
          >
            <Text style={styles.actionButtonText}>Reset</Text>
          </TouchableOpacity>
        </SettingItem>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    paddingBottom: 32,
  },
  section: {
    marginVertical: 8,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 12,
  },
  settingItem: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginBottom: 12,
    padding: 16,
    elevation: 2,
  },
  settingIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(33, 150, 243, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  settingContent: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  settingTextContainer: {
    flex: 1,
    marginRight: 16,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  settingDescription: {
    fontSize: 14,
    marginTop: 4,
  },
  settingControl: {
    minWidth: 60,
    alignItems: 'flex-end',
  },
  optionsRow: {
    flexDirection: 'row',
  },
  optionButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    marginLeft: 8,
  },
  optionButtonText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  actionButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    minWidth: 70,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
  iconButton: {
    padding: 8,
  },
});

export default Settings;
