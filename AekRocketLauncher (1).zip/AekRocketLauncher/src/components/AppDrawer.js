import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Dimensions,
  TextInput,
  Animated,
  PanResponder,
} from 'react-native';
import { AppService } from '../services/AppService';
import { PreferenceService } from '../services/PreferenceService';
import AppIcon from '../3d/AppIcon';
import { performanceUtils } from '../utils/performanceUtils';
import Feather from 'react-native-vector-icons/Feather';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

const AppDrawer = ({ visible, theme, onClose, navigation }) => {
  const [apps, setApps] = useState([]);
  const [filteredApps, setFilteredApps] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [animationSpeed, setAnimationSpeed] = useState('normal');
  const [iconStyle, setIconStyle] = useState('flat');
  const [drawerHeight] = useState(new Animated.Value(0));
  
  // References for animations
  const appItemScales = useRef({}).current;
  const scrollY = useRef(new Animated.Value(0)).current;
  
  useEffect(() => {
    if (visible) {
      loadApps();
      loadPreferences();
    }
  }, [visible]);
  
  // Load apps and categories
  const loadApps = async () => {
    const installedApps = AppService.getInstalledApps();
    setApps(installedApps);
    setFilteredApps(installedApps);
    
    // Load categories
    const savedCategories = await PreferenceService.getItem('appCategories', '{}');
    const parsedCategories = JSON.parse(savedCategories);
    
    // Create category list including 'All'
    const categoryList = ['All', ...Object.keys(parsedCategories)];
    setCategories(categoryList);
  };
  
  // Load user preferences
  const loadPreferences = async () => {
    const speed = await PreferenceService.getItem('animationSpeed', 'normal');
    setAnimationSpeed(speed);
    
    const style = await PreferenceService.getItem('iconStyle', 'flat');
    setIconStyle(style);
  };
  
  // Handle search input
  const handleSearch = (text) => {
    setSearchQuery(text);
    
    if (text.trim() === '') {
      // If search is cleared, show all apps or filter by category
      filterByCategory(selectedCategory);
    } else {
      // Filter apps by name or package name
      const filtered = apps.filter(app => 
        app.appName.toLowerCase().includes(text.toLowerCase()) ||
        app.packageName.toLowerCase().includes(text.toLowerCase())
      );
      setFilteredApps(filtered);
    }
  };
  
  // Filter apps by category
  const filterByCategory = (category) => {
    setSelectedCategory(category);
    
    if (category === 'All') {
      setFilteredApps(apps);
    } else {
      const appsInCategory = AppService.getAppsByCategory(category);
      setFilteredApps(appsInCategory);
    }
    
    // Clear search when changing category
    setSearchQuery('');
  };
  
  // Launch an app
  const launchApp = (packageName) => {
    AppService.launchApp(packageName);
    onClose();
  };
  
  // Get animation duration based on user preference
  const getAnimationDuration = () => {
    switch (animationSpeed) {
      case 'slow': return 500;
      case 'fast': return 150;
      default: return 300; // normal
    }
  };
  
  // Pan responder for drag gestures
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_, gestureState) => {
        return Math.abs(gestureState.dy) > 10;
      },
      onPanResponderMove: (_, gestureState) => {
        if (gestureState.dy > 0) {
          // Dragging down
          const newHeight = Math.max(0, SCREEN_HEIGHT * 0.8 - gestureState.dy);
          drawerHeight.setValue(newHeight);
        }
      },
      onPanResponderRelease: (_, gestureState) => {
        if (gestureState.dy > 100) {
          // Dragged down enough to close
          onClose();
        } else {
          // Snap back to full height
          Animated.spring(drawerHeight, {
            toValue: SCREEN_HEIGHT * 0.8,
            useNativeDriver: false,
            friction: 8,
          }).start();
        }
      },
    })
  ).current;
  
  // Get app icon animation based on scroll position
  const getAppIconAnimation = (index) => {
    // Create an animated scale value for this item if it doesn't exist
    if (!appItemScales[index]) {
      appItemScales[index] = new Animated.Value(1);
    }
    
    // Determine when this item is in focus based on scroll position
    const isInFocus = scrollY.interpolate({
      inputRange: [
        (index - 2) * 80, // Start fading in
        index * 80,       // Fully visible
        (index + 2) * 80  // Start fading out
      ],
      outputRange: [0.9, 1.1, 0.9],
      extrapolate: 'clamp'
    });
    
    // Apply scale animation
    return {
      transform: [{ scale: isInFocus }]
    };
  };
  
  // Render a category pill
  const renderCategory = ({ item }) => (
    <TouchableOpacity
      style={[
        styles.categoryPill,
        { 
          backgroundColor: selectedCategory === item 
            ? theme.primaryColor 
            : theme.cardColor,
          borderColor: theme.primaryColor,
        }
      ]}
      onPress={() => filterByCategory(item)}
    >
      <Text
        style={[
          styles.categoryText,
          {
            color: selectedCategory === item 
              ? theme.cardColor 
              : theme.textColor
          }
        ]}
      >
        {item}
      </Text>
    </TouchableOpacity>
  );
  
  // Render an app item
  const renderAppItem = ({ item, index }) => {
    const animatedStyle = getAppIconAnimation(index);
    
    return (
      <Animated.View style={[styles.appItem, animatedStyle]}>
        <TouchableOpacity
          style={styles.appButton}
          onPress={() => launchApp(item.packageName)}
          onLongPress={() => navigation.navigate('IconCustomizer', { packageName: item.packageName })}
        >
          <View style={styles.iconContainer}>
            <AppIcon
              packageName={item.packageName}
              size={50}
              style={iconStyle}
              theme={theme}
            />
          </View>
          <Text 
            style={[styles.appName, { color: theme.textColor }]}
            numberOfLines={1}
            ellipsizeMode="tail"
          >
            {item.appName}
          </Text>
        </TouchableOpacity>
      </Animated.View>
    );
  };
  
  // Calculate performance impact and adjust rendering quality
  const performanceSettings = performanceUtils.getDrawerPerformanceSettings();
  
  return (
    <View 
      style={[
        styles.container,
        { 
          backgroundColor: theme.cardColor,
          borderTopLeftRadius: 20,
          borderTopRightRadius: 20,
          shadowColor: theme.shadowColor
        }
      ]}
    >
      {/* Handle/Dragger for drawer */}
      <View 
        style={styles.drawerHandle}
        {...panResponder.panHandlers}
      >
        <View style={[styles.handleBar, { backgroundColor: theme.secondaryColor }]} />
      </View>
      
      {/* Search Bar */}
      <View style={[styles.searchContainer, { backgroundColor: theme.backgroundColor }]}>
        <Feather name="search" size={20} color={theme.textColor} style={styles.searchIcon} />
        <TextInput
          style={[styles.searchInput, { color: theme.textColor }]}
          placeholder="Search apps..."
          placeholderTextColor={theme.textColor + '80'} // 50% opacity
          value={searchQuery}
          onChangeText={handleSearch}
        />
        {searchQuery.length > 0 && (
          <TouchableOpacity onPress={() => handleSearch('')}>
            <Feather name="x" size={20} color={theme.textColor} />
          </TouchableOpacity>
        )}
      </View>
      
      {/* Categories */}
      <View style={styles.categoriesContainer}>
        <FlatList
          data={categories}
          renderItem={renderCategory}
          keyExtractor={(item) => item}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesList}
        />
      </View>
      
      {/* Apps List */}
      <Animated.FlatList
        data={filteredApps}
        renderItem={renderAppItem}
        keyExtractor={(item) => item.packageName}
        numColumns={performanceSettings.columnsCount}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.appsList}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        // Performance optimizations
        removeClippedSubviews={performanceSettings.removeClippedSubviews}
        maxToRenderPerBatch={performanceSettings.maxToRenderPerBatch}
        windowSize={performanceSettings.windowSize}
        initialNumToRender={performanceSettings.initialNumToRender}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 10,
    paddingHorizontal: 16,
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 10,
  },
  drawerHandle: {
    width: '100%',
    height: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  handleBar: {
    width: 40,
    height: 5,
    borderRadius: 3,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 12,
    paddingHorizontal: 12,
    height: 44,
    borderRadius: 22,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    height: 44,
    fontSize: 16,
  },
  categoriesContainer: {
    marginBottom: 16,
  },
  categoriesList: {
    paddingVertical: 8,
    paddingHorizontal: 4,
  },
  categoryPill: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    borderWidth: 1,
  },
  categoryText: {
    fontSize: 14,
    fontWeight: '500',
  },
  appsList: {
    paddingBottom: 20,
  },
  appItem: {
    width: SCREEN_WIDTH / 4 - 16,
    marginBottom: 16,
  },
  appButton: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconContainer: {
    width: 60,
    height: 60,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  appName: {
    fontSize: 12,
    textAlign: 'center',
    width: 80,
  },
});

export default AppDrawer;
