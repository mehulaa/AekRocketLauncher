/**
 * Feature Manager Screen
 * UI for managing and installing new features
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Switch,
  Modal,
  TextInput,
  ActivityIndicator,
  Alert
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { FeatureManagerService } from '../../services/FeatureManagerService';
import { ThemeService } from '../../services/ThemeService';
import { LocalizationService } from '../../services/LocalizationService';

const FeatureManagerScreen = ({ navigation }) => {
  const [currentTheme, setCurrentTheme] = useState(null);
  const [features, setFeatures] = useState([]);
  const [installedFeatures, setInstalledFeatures] = useState([]);
  const [sources, setSources] = useState([]);
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [installing, setInstalling] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [currentTab, setCurrentTab] = useState('available');
  const [addSourceModalVisible, setAddSourceModalVisible] = useState(false);
  const [newSource, setNewSource] = useState({ id: '', name: '', url: '', trusted: false });
  
  // Helper function for translations
  const t = (key, defaultValue) => {
    try {
      if (LocalizationService && LocalizationService.translate) {
        return LocalizationService.translate(key);
      }
      return defaultValue || key;
    } catch (error) {
      return defaultValue || key;
    }
  };
  
  // Load theme
  useEffect(() => {
    const loadTheme = async () => {
      try {
        const theme = await ThemeService.getCurrentTheme();
        setCurrentTheme(theme);
      } catch (error) {
        console.error('Error loading theme:', error);
        // Use default theme values if theme service fails
        setCurrentTheme({
          textColor: '#212121',
          primaryColor: '#2196F3',
          secondaryColor: '#FFC107',
          cardColor: '#FFFFFF',
          backgroundColor: '#F5F5F5',
          borderRadius: 8,
        });
      }
    };
    
    loadTheme();
    
    // Subscribe to theme changes
    try {
      if (ThemeService && ThemeService.subscribeToThemeChanges) {
        const unsubscribe = ThemeService.subscribeToThemeChanges(newTheme => {
          setCurrentTheme(newTheme);
        });
        
        return () => {
          if (unsubscribe) unsubscribe();
        };
      }
    } catch (error) {
      console.error('Error subscribing to theme changes:', error);
    }
  }, []);
  
  // Initialize feature manager and load data
  useEffect(() => {
    const initializeFeatureManager = async () => {
      try {
        await FeatureManagerService.initialize();
        
        loadFeatureData();
        
        // Subscribe to feature manager events
        const unsubscribe = FeatureManagerService.subscribe((event, data) => {
          switch (event) {
            case 'install_completed':
            case 'uninstall_completed':
            case 'source_added':
            case 'source_removed':
            case 'source_updated':
            case 'update_check_completed':
              loadFeatureData();
              break;
          }
        });
        
        return () => {
          if (unsubscribe) unsubscribe();
        };
      } catch (error) {
        console.error('Error initializing feature manager:', error);
        setLoading(false);
      }
    };
    
    initializeFeatureManager();
  }, []);
  
  // Load feature data
  const loadFeatureData = async () => {
    try {
      setLoading(true);
      
      // Get available features
      const availableFeatures = FeatureManagerService.getAvailableFeatures();
      setFeatures(availableFeatures);
      
      // Get installed features
      const installed = FeatureManagerService.getInstalledFeatures();
      setInstalledFeatures(installed);
      
      // Get sources
      const featureSources = FeatureManagerService.getFeatureSources();
      setSources(featureSources);
      
      // Get settings
      const featureSettings = await FeatureManagerService.getSettings();
      setSettings(featureSettings);
      
      setLoading(false);
      setRefreshing(false);
    } catch (error) {
      console.error('Error loading feature data:', error);
      setLoading(false);
      setRefreshing(false);
    }
  };
  
  // Handle refresh
  const handleRefresh = async () => {
    setRefreshing(true);
    await FeatureManagerService.checkForUpdates();
    // loadFeatureData() will be called by the event subscription
  };
  
  // Handle feature installation
  const handleInstallFeature = async (feature) => {
    try {
      setInstalling(true);
      
      const result = await FeatureManagerService.installFeature(feature.featureId);
      
      setInstalling(false);
      
      if (result.success) {
        Alert.alert(
          t('feature_manager.install_success_title', 'Installation Complete'),
          t('feature_manager.install_success_message', `${feature.name} was successfully installed.`)
        );
      } else {
        Alert.alert(
          t('feature_manager.install_error_title', 'Installation Failed'),
          t('feature_manager.install_error_message', `Failed to install ${feature.name}: ${result.message}`)
        );
      }
      
      // Refresh data
      loadFeatureData();
    } catch (error) {
      setInstalling(false);
      
      Alert.alert(
        t('feature_manager.install_error_title', 'Installation Failed'),
        t('feature_manager.install_error_message', `Failed to install ${feature.name}: ${error.message}`)
      );
    }
  };
  
  // Handle feature uninstallation
  const handleUninstallFeature = async (feature) => {
    try {
      setInstalling(true);
      
      const result = await FeatureManagerService.uninstallFeature(feature.featureId);
      
      setInstalling(false);
      
      if (result.success) {
        Alert.alert(
          t('feature_manager.uninstall_success_title', 'Uninstallation Complete'),
          t('feature_manager.uninstall_success_message', `${feature.name} was successfully uninstalled.`)
        );
      } else {
        Alert.alert(
          t('feature_manager.uninstall_error_title', 'Uninstallation Failed'),
          t('feature_manager.uninstall_error_message', `Failed to uninstall ${feature.name}: ${result.message}`)
        );
      }
      
      // Refresh data
      loadFeatureData();
    } catch (error) {
      setInstalling(false);
      
      Alert.alert(
        t('feature_manager.uninstall_error_title', 'Uninstallation Failed'),
        t('feature_manager.uninstall_error_message', `Failed to uninstall ${feature.name}: ${error.message}`)
      );
    }
  };
  
  // Handle setting changes
  const handleSettingChange = async (key, value) => {
    try {
      await FeatureManagerService.updateSettings({ [key]: value });
      
      // Update local settings
      setSettings(prevSettings => ({
        ...prevSettings,
        [key]: value
      }));
    } catch (error) {
      console.error('Error updating settings:', error);
      
      Alert.alert(
        t('feature_manager.settings_error_title', 'Settings Error'),
        t('feature_manager.settings_error_message', `Failed to update settings: ${error.message}`)
      );
    }
  };
  
  // Handle adding a new source
  const handleAddSource = async () => {
    // Validate source
    if (!newSource.id || !newSource.name || !newSource.url) {
      Alert.alert(
        t('feature_manager.source_error_title', 'Invalid Source'),
        t('feature_manager.source_error_message', 'Please provide an ID, name, and URL for the source.')
      );
      return;
    }
    
    try {
      await FeatureManagerService.addFeatureSource(newSource);
      
      // Close modal and reset form
      setAddSourceModalVisible(false);
      setNewSource({ id: '', name: '', url: '', trusted: false });
      
      // Refresh sources
      const featureSources = FeatureManagerService.getFeatureSources();
      setSources(featureSources);
    } catch (error) {
      Alert.alert(
        t('feature_manager.source_error_title', 'Source Error'),
        t('feature_manager.source_error_message', `Failed to add source: ${error.message}`)
      );
    }
  };
  
  // Handle updating a source
  const handleToggleSource = async (source, enabled) => {
    try {
      await FeatureManagerService.updateFeatureSource(source.id, { enabled });
      
      // Refresh sources
      const featureSources = FeatureManagerService.getFeatureSources();
      setSources(featureSources);
    } catch (error) {
      Alert.alert(
        t('feature_manager.source_error_title', 'Source Error'),
        t('feature_manager.source_error_message', `Failed to update source: ${error.message}`)
      );
    }
  };
  
  // Handle removing a source
  const handleRemoveSource = async (source) => {
    try {
      await FeatureManagerService.removeFeatureSource(source.id);
      
      // Refresh sources
      const featureSources = FeatureManagerService.getFeatureSources();
      setSources(featureSources);
    } catch (error) {
      Alert.alert(
        t('feature_manager.source_error_title', 'Source Error'),
        t('feature_manager.source_error_message', `Failed to remove source: ${error.message}`)
      );
    }
  };
  
  // Render feature item
  const renderFeatureItem = ({ item }) => {
    const isInstalled = FeatureManagerService.isFeatureInstalled(item.featureId);
    
    return (
      <View 
        style={[
          styles.featureItem,
          currentTheme && { 
            backgroundColor: currentTheme.cardColor,
            borderRadius: currentTheme.borderRadius,
          }
        ]}
      >
        <View style={styles.featureHeader}>
          <Text 
            style={[
              styles.featureName,
              currentTheme && { color: currentTheme.textColor }
            ]}
          >
            {item.name}
          </Text>
          
          {item.trusted && (
            <View style={styles.trustedBadge}>
              <Icon name="shield-check" size={14} color="#FFFFFF" />
              <Text style={styles.trustedText}>
                {t('feature_manager.trusted', 'Trusted')}
              </Text>
            </View>
          )}
        </View>
        
        <Text 
          style={[
            styles.featureDescription,
            currentTheme && { color: currentTheme.textColor + 'CC' }
          ]}
        >
          {item.description}
        </Text>
        
        <View style={styles.featureFooter}>
          <Text 
            style={[
              styles.featureVersion,
              currentTheme && { color: currentTheme.textColor + '99' }
            ]}
          >
            {t('feature_manager.version', 'Version')}: {item.version}
          </Text>
          
          <TouchableOpacity
            style={[
              styles.featureButton,
              isInstalled ? styles.uninstallButton : styles.installButton,
              currentTheme && { 
                backgroundColor: isInstalled ? '#F44336' : currentTheme.primaryColor
              }
            ]}
            onPress={() => isInstalled ? 
              handleUninstallFeature(item) : 
              handleInstallFeature(item)
            }
            disabled={installing}
          >
            {installing ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <Text style={styles.buttonText}>
                {isInstalled ? 
                  t('feature_manager.uninstall', 'Uninstall') : 
                  t('feature_manager.install', 'Install')
                }
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  
  // Render source item
  const renderSourceItem = ({ item }) => {
    return (
      <View 
        style={[
          styles.sourceItem,
          currentTheme && { 
            backgroundColor: currentTheme.cardColor,
            borderRadius: currentTheme.borderRadius,
          }
        ]}
      >
        <View style={styles.sourceHeader}>
          <View>
            <Text 
              style={[
                styles.sourceName,
                currentTheme && { color: currentTheme.textColor }
              ]}
            >
              {item.name}
            </Text>
            <Text 
              style={[
                styles.sourceUrl,
                currentTheme && { color: currentTheme.textColor + '99' }
              ]}
            >
              {item.url}
            </Text>
          </View>
          
          {item.id !== 'official' && (
            <TouchableOpacity
              style={styles.removeButton}
              onPress={() => handleRemoveSource(item)}
            >
              <Icon 
                name="delete-outline" 
                size={20} 
                color={currentTheme ? currentTheme.textColor + '99' : '#757575'} 
              />
            </TouchableOpacity>
          )}
        </View>
        
        <View style={styles.sourceFooter}>
          {item.trusted && (
            <View style={styles.trustedBadge}>
              <Icon name="shield-check" size={14} color="#FFFFFF" />
              <Text style={styles.trustedText}>
                {t('feature_manager.trusted', 'Trusted')}
              </Text>
            </View>
          )}
          
          <Switch
            value={item.enabled !== false}
            onValueChange={(value) => handleToggleSource(item, value)}
            disabled={item.id === 'official'}
            thumbColor={currentTheme ? currentTheme.primaryColor : '#2196F3'}
            trackColor={{ 
              false: '#E0E0E0', 
              true: currentTheme ? currentTheme.primaryColor + '50' : '#2196F350'
            }}
          />
        </View>
      </View>
    );
  };
  
  // Render settings
  const renderSettings = () => {
    if (!settings) return null;
    
    return (
      <View style={styles.settingsContainer}>
        <View style={styles.settingRow}>
          <Text 
            style={[
              styles.settingLabel,
              currentTheme && { color: currentTheme.textColor }
            ]}
          >
            {t('feature_manager.auto_install', 'Auto-install trusted features')}
          </Text>
          <Switch
            value={settings.autoInstallFeatures}
            onValueChange={(value) => handleSettingChange('autoInstallFeatures', value)}
            thumbColor={currentTheme ? currentTheme.primaryColor : '#2196F3'}
            trackColor={{ 
              false: '#E0E0E0', 
              true: currentTheme ? currentTheme.primaryColor + '50' : '#2196F350'
            }}
          />
        </View>
        
        <View style={styles.settingRow}>
          <Text 
            style={[
              styles.settingLabel,
              currentTheme && { color: currentTheme.textColor }
            ]}
          >
            {t('feature_manager.notify_new', 'Notify on new features')}
          </Text>
          <Switch
            value={settings.notifyOnNewFeatures}
            onValueChange={(value) => handleSettingChange('notifyOnNewFeatures', value)}
            thumbColor={currentTheme ? currentTheme.primaryColor : '#2196F3'}
            trackColor={{ 
              false: '#E0E0E0', 
              true: currentTheme ? currentTheme.primaryColor + '50' : '#2196F350'
            }}
          />
        </View>
        
        <Text 
          style={[
            styles.sectionTitle,
            currentTheme && { color: currentTheme.textColor }
          ]}
        >
          {t('feature_manager.check_frequency', 'Check frequency')}
        </Text>
        
        <View style={styles.frequencyOptions}>
          {['daily', 'weekly', 'monthly', 'never'].map(freq => (
            <TouchableOpacity
              key={freq}
              style={[
                styles.frequencyOption,
                settings.checkFrequency === freq && styles.selectedFrequency,
                currentTheme && { 
                  backgroundColor: settings.checkFrequency === freq ? 
                    currentTheme.primaryColor : 
                    currentTheme.cardColor 
                }
              ]}
              onPress={() => handleSettingChange('checkFrequency', freq)}
            >
              <Text 
                style={[
                  styles.frequencyText,
                  settings.checkFrequency === freq && styles.selectedFrequencyText,
                  currentTheme && { 
                    color: settings.checkFrequency === freq ? 
                      '#FFFFFF' : 
                      currentTheme.textColor 
                  }
                ]}
              >
                {t(`feature_manager.frequency.${freq}`, freq)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    );
  };
  
  // Render add source modal
  const renderAddSourceModal = () => (
    <Modal
      visible={addSourceModalVisible}
      transparent
      animationType="fade"
      onRequestClose={() => setAddSourceModalVisible(false)}
    >
      <View style={styles.modalOverlay}>
        <View 
          style={[
            styles.modalContent,
            currentTheme && { 
              backgroundColor: currentTheme.cardColor,
              borderRadius: currentTheme.borderRadius,
            }
          ]}
        >
          <Text 
            style={[
              styles.modalTitle,
              currentTheme && { color: currentTheme.textColor }
            ]}
          >
            {t('feature_manager.add_source', 'Add Feature Source')}
          </Text>
          
          <TextInput
            style={[
              styles.input,
              currentTheme && { 
                borderColor: currentTheme.textColor + '33',
                color: currentTheme.textColor
              }
            ]}
            placeholder={t('feature_manager.source_id', 'Source ID')}
            placeholderTextColor={currentTheme ? currentTheme.textColor + '66' : '#75757566'}
            value={newSource.id}
            onChangeText={(text) => setNewSource(prev => ({ ...prev, id: text }))}
          />
          
          <TextInput
            style={[
              styles.input,
              currentTheme && { 
                borderColor: currentTheme.textColor + '33',
                color: currentTheme.textColor
              }
            ]}
            placeholder={t('feature_manager.source_name', 'Source Name')}
            placeholderTextColor={currentTheme ? currentTheme.textColor + '66' : '#75757566'}
            value={newSource.name}
            onChangeText={(text) => setNewSource(prev => ({ ...prev, name: text }))}
          />
          
          <TextInput
            style={[
              styles.input,
              currentTheme && { 
                borderColor: currentTheme.textColor + '33',
                color: currentTheme.textColor
              }
            ]}
            placeholder={t('feature_manager.source_url', 'Source URL')}
            placeholderTextColor={currentTheme ? currentTheme.textColor + '66' : '#75757566'}
            value={newSource.url}
            onChangeText={(text) => setNewSource(prev => ({ ...prev, url: text }))}
          />
          
          <View style={styles.trustRow}>
            <Text 
              style={[
                styles.trustLabel,
                currentTheme && { color: currentTheme.textColor }
              ]}
            >
              {t('feature_manager.mark_trusted', 'Mark as trusted source')}
            </Text>
            <Switch
              value={newSource.trusted}
              onValueChange={(value) => setNewSource(prev => ({ ...prev, trusted: value }))}
              thumbColor={currentTheme ? currentTheme.primaryColor : '#2196F3'}
              trackColor={{ 
                false: '#E0E0E0', 
                true: currentTheme ? currentTheme.primaryColor + '50' : '#2196F350'
              }}
            />
          </View>
          
          <View style={styles.modalButtons}>
            <TouchableOpacity
              style={[
                styles.modalButton,
                styles.cancelButton,
                currentTheme && { backgroundColor: currentTheme.textColor + '20' }
              ]}
              onPress={() => setAddSourceModalVisible(false)}
            >
              <Text 
                style={[
                  styles.cancelButtonText,
                  currentTheme && { color: currentTheme.textColor }
                ]}
              >
                {t('feature_manager.cancel', 'Cancel')}
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.modalButton,
                styles.addButton,
                currentTheme && { backgroundColor: currentTheme.primaryColor }
              ]}
              onPress={handleAddSource}
            >
              <Text style={styles.addButtonText}>
                {t('feature_manager.add', 'Add')}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
  
  // Render tabs
  const renderTabs = () => {
    const tabs = [
      { id: 'available', label: t('feature_manager.available', 'Available'), icon: 'package-variant-closed' },
      { id: 'installed', label: t('feature_manager.installed', 'Installed'), icon: 'package-variant' },
      { id: 'sources', label: t('feature_manager.sources', 'Sources'), icon: 'database' },
      { id: 'settings', label: t('feature_manager.settings', 'Settings'), icon: 'cog-outline' }
    ];
    
    return (
      <View style={styles.tabsContainer}>
        {tabs.map(tab => (
          <TouchableOpacity
            key={tab.id}
            style={[
              styles.tab,
              currentTab === tab.id && styles.activeTab,
              currentTheme && { 
                borderBottomColor: currentTab === tab.id ? 
                  currentTheme.primaryColor : 
                  'transparent'
              }
            ]}
            onPress={() => setCurrentTab(tab.id)}
          >
            <Icon 
              name={tab.icon} 
              size={20} 
              color={currentTheme ? 
                (currentTab === tab.id ? 
                  currentTheme.primaryColor : 
                  currentTheme.textColor + '99') : 
                (currentTab === tab.id ? '#2196F3' : '#757575')
              } 
            />
            <Text 
              style={[
                styles.tabText,
                currentTab === tab.id && styles.activeTabText,
                currentTheme && { 
                  color: currentTab === tab.id ? 
                    currentTheme.primaryColor : 
                    currentTheme.textColor + '99' 
                }
              ]}
            >
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    );
  };
  
  // Render content based on current tab
  const renderContent = () => {
    if (loading) {
      return (
        <View style={styles.loadingContainer}>
          <ActivityIndicator 
            size="large" 
            color={currentTheme ? currentTheme.primaryColor : '#2196F3'} 
          />
          <Text 
            style={[
              styles.loadingText,
              currentTheme && { color: currentTheme.textColor }
            ]}
          >
            {t('feature_manager.loading', 'Loading feature data...')}
          </Text>
        </View>
      );
    }
    
    switch (currentTab) {
      case 'available':
        // Filter out installed features
        const availableFeatures = features.filter(
          feature => !FeatureManagerService.isFeatureInstalled(feature.featureId)
        );
        
        return (
          <FlatList
            data={availableFeatures}
            renderItem={renderFeatureItem}
            keyExtractor={item => item.featureId}
            contentContainerStyle={styles.listContent}
            refreshing={refreshing}
            onRefresh={handleRefresh}
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <Icon 
                  name="package-variant-closed" 
                  size={48} 
                  color={currentTheme ? currentTheme.textColor + '33' : '#75757533'} 
                />
                <Text 
                  style={[
                    styles.emptyText,
                    currentTheme && { color: currentTheme.textColor + '99' }
                  ]}
                >
                  {t('feature_manager.no_features', 'No available features found')}
                </Text>
                <TouchableOpacity
                  style={[
                    styles.refreshButton,
                    currentTheme && { backgroundColor: currentTheme.primaryColor }
                  ]}
                  onPress={handleRefresh}
                >
                  <Text style={styles.refreshButtonText}>
                    {t('feature_manager.check_updates', 'Check for Updates')}
                  </Text>
                </TouchableOpacity>
              </View>
            }
          />
        );
        
      case 'installed':
        return (
          <FlatList
            data={Object.values(installedFeatures)}
            renderItem={renderFeatureItem}
            keyExtractor={item => item.featureId}
            contentContainerStyle={styles.listContent}
            refreshing={refreshing}
            onRefresh={handleRefresh}
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <Icon 
                  name="package-variant" 
                  size={48} 
                  color={currentTheme ? currentTheme.textColor + '33' : '#75757533'} 
                />
                <Text 
                  style={[
                    styles.emptyText,
                    currentTheme && { color: currentTheme.textColor + '99' }
                  ]}
                >
                  {t('feature_manager.no_installed', 'No installed features')}
                </Text>
              </View>
            }
          />
        );
        
      case 'sources':
        return (
          <View style={styles.sourcesContainer}>
            <FlatList
              data={sources}
              renderItem={renderSourceItem}
              keyExtractor={item => item.id}
              contentContainerStyle={styles.listContent}
              ListEmptyComponent={
                <View style={styles.emptyContainer}>
                  <Icon 
                    name="database" 
                    size={48} 
                    color={currentTheme ? currentTheme.textColor + '33' : '#75757533'} 
                  />
                  <Text 
                    style={[
                      styles.emptyText,
                      currentTheme && { color: currentTheme.textColor + '99' }
                    ]}
                  >
                    {t('feature_manager.no_sources', 'No feature sources available')}
                  </Text>
                </View>
              }
            />
            
            <TouchableOpacity
              style={[
                styles.addSourceButton,
                currentTheme && { backgroundColor: currentTheme.primaryColor }
              ]}
              onPress={() => setAddSourceModalVisible(true)}
            >
              <Icon name="plus" size={24} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        );
        
      case 'settings':
        return renderSettings();
        
      default:
        return null;
    }
  };
  
  return (
    <View 
      style={[
        styles.container,
        currentTheme && { backgroundColor: currentTheme.backgroundColor }
      ]}
    >
      <View style={styles.header}>
        <Text 
          style={[
            styles.headerTitle,
            currentTheme && { color: currentTheme.textColor }
          ]}
        >
          {t('feature_manager.title', 'Feature Manager')}
        </Text>
        <TouchableOpacity
          style={styles.closeButton}
          onPress={() => navigation.goBack()}
        >
          <Icon 
            name="close" 
            size={24} 
            color={currentTheme ? currentTheme.textColor : '#212121'} 
          />
        </TouchableOpacity>
      </View>
      
      {renderTabs()}
      
      <View style={styles.content}>
        {renderContent()}
      </View>
      
      {renderAddSourceModal()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  closeButton: {
    padding: 8,
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomColor: '#2196F3',
  },
  tabText: {
    fontSize: 14,
    marginLeft: 4,
    color: '#757575',
  },
  activeTabText: {
    color: '#2196F3',
  },
  content: {
    flex: 1,
  },
  listContent: {
    padding: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
  },
  emptyContainer: {
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#757575',
    marginTop: 8,
    textAlign: 'center',
  },
  refreshButton: {
    marginTop: 16,
    backgroundColor: '#2196F3',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
  },
  refreshButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  featureItem: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
  },
  featureHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  featureName: {
    fontSize: 16,
    fontWeight: 'bold',
    flex: 1,
  },
  trustedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#4CAF50',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  trustedText: {
    color: '#FFFFFF',
    fontSize: 12,
    marginLeft: 4,
  },
  featureDescription: {
    fontSize: 14,
    marginBottom: 12,
  },
  featureFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  featureVersion: {
    fontSize: 12,
    color: '#757575',
  },
  featureButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  installButton: {
    backgroundColor: '#2196F3',
  },
  uninstallButton: {
    backgroundColor: '#F44336',
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 12,
  },
  settingsContainer: {
    padding: 16,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  settingLabel: {
    fontSize: 16,
    flex: 1,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 8,
    marginBottom: 12,
  },
  frequencyOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  frequencyOption: {
    backgroundColor: '#FFFFFF',
    borderRadius: 4,
    padding: 10,
    marginRight: 8,
    marginBottom: 8,
  },
  selectedFrequency: {
    backgroundColor: '#2196F3',
  },
  frequencyText: {
    color: '#212121',
  },
  selectedFrequencyText: {
    color: '#FFFFFF',
  },
  sourcesContainer: {
    flex: 1,
  },
  sourceItem: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
  },
  sourceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  sourceName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  sourceUrl: {
    fontSize: 12,
    color: '#757575',
    marginTop: 4,
  },
  removeButton: {
    padding: 4,
  },
  sourceFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  addSourceButton: {
    position: 'absolute',
    right: 16,
    bottom: 16,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#2196F3',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 16,
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 16,
    width: '100%',
    maxWidth: 400,
    elevation: 4,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 4,
    padding: 10,
    marginBottom: 12,
    fontSize: 16,
  },
  trustRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  trustLabel: {
    fontSize: 16,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  modalButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 4,
    marginLeft: 8,
  },
  cancelButton: {
    backgroundColor: '#E0E0E0',
  },
  cancelButtonText: {
    color: '#212121',
  },
  addButton: {
    backgroundColor: '#2196F3',
  },
  addButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});

export default FeatureManagerScreen;