/**
 * Component for sustainability settings and features
 * Displays and manages eco-friendly options and battery optimizations
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  ScrollView,
  TouchableOpacity,
  Slider,
  Image,
  ActivityIndicator
} from 'react-native';
import { MaterialIcons, Ionicons } from 'react-native-vector-icons';
import { SustainabilityService } from '../services/SustainabilityService';
import { ThemeService } from '../services/ThemeService';
import { performanceUtils } from '../utils/performanceUtils';
import { animations } from '../utils/animations';

const SustainabilitySettings = ({ navigation }) => {
  // State
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState(null);
  const [stats, setStats] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [ecoThemes, setEcoThemes] = useState([]);
  const [ecoWallpapers, setEcoWallpapers] = useState([]);
  const [theme, setTheme] = useState(null);
  const [applyingOptimizations, setApplyingOptimizations] = useState(false);
  
  // Load data on component mount
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        // Initialize the sustainability service
        await SustainabilityService.initialize();
        
        // Get current settings
        const sustainabilityStatus = SustainabilityService.getStatus();
        setSettings(sustainabilityStatus);
        
        // Get energy stats
        const energyStats = SustainabilityService.getEnergyStats();
        setStats(energyStats);
        
        // Get eco-friendly theme recommendations
        const themes = SustainabilityService.getEcoFriendlyThemeRecommendations();
        setEcoThemes(themes);
        
        // Get eco-friendly wallpaper recommendations
        const wallpapers = SustainabilityService.getEcoFriendlyWallpaperRecommendations();
        setEcoWallpapers(wallpapers);
        
        // Get current theme
        const currentTheme = await ThemeService.getCurrentTheme();
        setTheme(currentTheme);
        
        // Subscribe to theme changes
        ThemeService.subscribeToThemeChanges(onThemeChange);
        
        // Subscribe to sustainability service updates
        SustainabilityService.subscribe(onSustainabilityUpdate);
        
        setLoading(false);
      } catch (error) {
        console.error('Failed to load sustainability settings:', error);
        setLoading(false);
      }
    };
    
    loadData();
    
    // Cleanup subscriptions on unmount
    return () => {
      ThemeService.unsubscribeFromThemeChanges(onThemeChange);
      SustainabilityService.unsubscribe(onSustainabilityUpdate);
    };
  }, []);
  
  // Handle theme changes
  const onThemeChange = (newTheme) => {
    setTheme(newTheme);
  };
  
  // Handle sustainability service updates
  const onSustainabilityUpdate = (event, data) => {
    if (event === 'settingsLoaded' || event === 'settingChanged') {
      setSettings(data.state || data);
    } else if (event === 'energyUpdated') {
      setStats(data);
    }
  };
  
  // Toggle sustainability features
  const toggleSustainabilityFeatures = async (value) => {
    await SustainabilityService.setEnabled(value);
  };
  
  // Change energy mode
  const changeEnergyMode = async (mode) => {
    await SustainabilityService.applySetting('energyMode', mode);
  };
  
  // Toggle dark mode schedule
  const toggleDarkModeSchedule = async (value) => {
    await SustainabilityService.applySetting('darkModeSchedule', value);
  };
  
  // Change screen timeout
  const changeScreenTimeout = async (value) => {
    await SustainabilityService.applySetting('screenTimeoutDuration', value);
  };
  
  // Apply all recommended optimizations
  const applyAllOptimizations = async () => {
    setApplyingOptimizations(true);
    try {
      await SustainabilityService.applyBatteryOptimizations();
      // Update performance mode to match the eco settings
      performanceUtils.setPerformanceMode(performanceUtils.PERFORMANCE_MODES.PERFORMANCE);
      setApplyingOptimizations(false);
    } catch (error) {
      console.error('Failed to apply optimizations:', error);
      setApplyingOptimizations(false);
    }
  };
  
  // Apply an eco-friendly theme
  const applyEcoTheme = async (themeId) => {
    try {
      await ThemeService.setTheme(themeId);
    } catch (error) {
      console.error('Failed to apply eco theme:', error);
    }
  };
  
  // Render loading state
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0A8A0A" />
        <Text style={styles.loadingText}>Loading sustainability features...</Text>
      </View>
    );
  }
  
  // Format environmental impact numbers
  const formatImpact = (value, unit) => {
    if (value < 1) {
      return parseFloat(value).toFixed(3) + ' ' + unit;
    }
    return Math.round(value) + ' ' + unit;
  };
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="leaf" size={24} color="#0A8A0A" />
        <Text style={styles.headerTitle}>Sustainability Settings</Text>
      </View>
      
      {/* Main toggle */}
      <View style={styles.settingRow}>
        <View style={styles.settingInfo}>
          <Text style={styles.settingTitle}>Sustainability Features</Text>
          <Text style={styles.settingDescription}>
            Enable eco-friendly optimizations to reduce battery usage and environmental impact
          </Text>
        </View>
        <Switch
          value={settings?.enabled}
          onValueChange={toggleSustainabilityFeatures}
          trackColor={{ false: '#767577', true: '#81b0ff' }}
          thumbColor={settings?.enabled ? '#0A8A0A' : '#f4f3f4'}
        />
      </View>
      
      {settings?.enabled && (
        <>
          {/* Environmental Impact Section */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Environmental Impact</Text>
            
            <View style={styles.impactContainer}>
              <View style={styles.impactItem}>
                <Ionicons name="battery-charging" size={32} color="#0A8A0A" />
                <Text style={styles.impactValue}>
                  {formatImpact(settings?.environmentalImpact?.energySaved || 0, 'mWh')}
                </Text>
                <Text style={styles.impactLabel}>Energy Saved</Text>
              </View>
              
              <View style={styles.impactItem}>
                <MaterialIcons name="co2" size={32} color="#0A8A0A" />
                <Text style={styles.impactValue}>
                  {formatImpact(settings?.environmentalImpact?.co2Saved || 0, 'g')}
                </Text>
                <Text style={styles.impactLabel}>CO₂ Reduction</Text>
              </View>
              
              <View style={styles.impactItem}>
                <Ionicons name="leaf" size={32} color="#0A8A0A" />
                <Text style={styles.impactValue}>
                  {formatImpact(settings?.environmentalImpact?.treesEquivalent || 0, 'trees')}
                </Text>
                <Text style={styles.impactLabel}>Tree Equivalent</Text>
              </View>
            </View>
          </View>
          
          {/* Energy Mode Section */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Energy Mode</Text>
            
            <View style={styles.energyModeContainer}>
              <TouchableOpacity
                style={[
                  styles.energyModeButton,
                  settings?.energyMode === 'eco' && styles.selectedEnergyMode
                ]}
                onPress={() => changeEnergyMode('eco')}
              >
                <Ionicons 
                  name="leaf" 
                  size={24} 
                  color={settings?.energyMode === 'eco' ? 'white' : '#0A8A0A'} 
                />
                <Text style={[
                  styles.energyModeLabel,
                  settings?.energyMode === 'eco' && styles.selectedEnergyModeText
                ]}>
                  Eco
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.energyModeButton,
                  settings?.energyMode === 'balanced' && styles.selectedEnergyMode
                ]}
                onPress={() => changeEnergyMode('balanced')}
              >
                <Ionicons 
                  name="speedometer" 
                  size={24} 
                  color={settings?.energyMode === 'balanced' ? 'white' : '#0A8A0A'} 
                />
                <Text style={[
                  styles.energyModeLabel,
                  settings?.energyMode === 'balanced' && styles.selectedEnergyModeText
                ]}>
                  Balanced
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.energyModeButton,
                  settings?.energyMode === 'performance' && styles.selectedEnergyMode
                ]}
                onPress={() => changeEnergyMode('performance')}
              >
                <Ionicons 
                  name="flash" 
                  size={24} 
                  color={settings?.energyMode === 'performance' ? 'white' : '#0A8A0A'} 
                />
                <Text style={[
                  styles.energyModeLabel,
                  settings?.energyMode === 'performance' && styles.selectedEnergyModeText
                ]}>
                  Performance
                </Text>
              </TouchableOpacity>
            </View>
          </View>
          
          {/* Display Settings */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Display Settings</Text>
            
            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingTitle}>Dark Mode Schedule</Text>
                <Text style={styles.settingDescription}>
                  Automatically switch to dark mode during set hours to save battery
                </Text>
              </View>
              <Switch
                value={settings?.darkModeSchedule?.enabled}
                onValueChange={toggleDarkModeSchedule}
                trackColor={{ false: '#767577', true: '#81b0ff' }}
                thumbColor={settings?.darkModeSchedule?.enabled ? '#0A8A0A' : '#f4f3f4'}
              />
            </View>
            
            {settings?.darkModeSchedule?.enabled && (
              <View style={styles.scheduleContainer}>
                <Text style={styles.scheduleLabel}>Dark Mode Active:</Text>
                <Text style={styles.scheduleTime}>
                  {settings?.darkModeSchedule?.startTime} - {settings?.darkModeSchedule?.endTime}
                </Text>
              </View>
            )}
            
            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingTitle}>Screen Timeout</Text>
                <Text style={styles.settingDescription}>
                  {settings?.screenTimeout?.duration} seconds
                </Text>
              </View>
            </View>
            
            <Slider
              style={styles.slider}
              minimumValue={15}
              maximumValue={120}
              step={15}
              value={settings?.screenTimeout?.duration || 30}
              onValueChange={changeScreenTimeout}
              minimumTrackTintColor="#0A8A0A"
              maximumTrackTintColor="#d3d3d3"
              thumbTintColor="#0A8A0A"
            />
          </View>
          
          {/* Eco-Friendly Themes */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Eco-Friendly Themes</Text>
            <Text style={styles.sectionDescription}>
              These themes are optimized for OLED screens to save battery
            </Text>
            
            <ScrollView horizontal={true} showsHorizontalScrollIndicator={false} style={styles.themesContainer}>
              {ecoThemes.map((themeItem) => (
                <TouchableOpacity
                  key={themeItem.id}
                  style={[styles.themeCard, { backgroundColor: themeItem.primaryColor }]}
                  onPress={() => applyEcoTheme(themeItem.id)}
                >
                  <View style={[styles.themeColorPreview, { backgroundColor: themeItem.accentColor }]} />
                  <Text style={styles.themeTitle}>{themeItem.name}</Text>
                  <Text style={styles.themeImpact}>
                    {themeItem.energyImpact === 'very_low' ? 'Maximum Savings' : 'Efficient'}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
          
          {/* Optimizations Button */}
          <TouchableOpacity
            style={styles.optimizeButton}
            onPress={applyAllOptimizations}
            disabled={applyingOptimizations}
          >
            {applyingOptimizations ? (
              <ActivityIndicator size="small" color="white" />
            ) : (
              <Ionicons name="flash" size={24} color="white" />
            )}
            <Text style={styles.optimizeButtonText}>
              {applyingOptimizations ? 'Applying Optimizations...' : 'Apply All Optimizations'}
            </Text>
          </TouchableOpacity>
        </>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#333',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
    color: '#333333',
  },
  section: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
    color: '#333333',
  },
  sectionDescription: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 16,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  settingInfo: {
    flex: 1,
    paddingRight: 16,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 14,
    color: '#666666',
  },
  impactContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  impactItem: {
    alignItems: 'center',
    flex: 1,
  },
  impactValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginTop: 8,
  },
  impactLabel: {
    fontSize: 12,
    color: '#666666',
    marginTop: 4,
  },
  energyModeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  energyModeButton: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    marginHorizontal: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#0A8A0A',
  },
  selectedEnergyMode: {
    backgroundColor: '#0A8A0A',
  },
  energyModeLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0A8A0A',
    marginTop: 4,
  },
  selectedEnergyModeText: {
    color: 'white',
  },
  scheduleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 16,
  },
  scheduleLabel: {
    fontSize: 14,
    color: '#666666',
  },
  scheduleTime: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333333',
    marginLeft: 8,
  },
  slider: {
    height: 40,
    marginTop: 8,
  },
  themesContainer: {
    flexDirection: 'row',
    marginTop: 12,
  },
  themeCard: {
    width: 140,
    height: 120,
    marginRight: 12,
    borderRadius: 8,
    padding: 12,
    justifyContent: 'space-between',
  },
  themeColorPreview: {
    width: 24,
    height: 24,
    borderRadius: 12,
  },
  themeTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 8,
  },
  themeImpact: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  optimizeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0A8A0A',
    marginHorizontal: 16,
    marginVertical: 24,
    paddingVertical: 16,
    borderRadius: 12,
  },
  optimizeButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    marginLeft: 8,
  },
});

export default SustainabilitySettings;