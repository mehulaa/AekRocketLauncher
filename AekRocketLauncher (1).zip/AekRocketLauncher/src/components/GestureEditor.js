import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  FlatList,
  TextInput,
  Alert,
  Dimensions,
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import { PreferenceService } from '../services/PreferenceService';
import { AppService } from '../services/AppService';
import { gestureUtils } from '../utils/gestureUtils';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const GestureEditor = ({ navigation }) => {
  const [gestures, setGestures] = useState({});
  const [editingGesture, setEditingGesture] = useState(null);
  const [actionType, setActionType] = useState('openApp');
  const [actionValue, setActionValue] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [apps, setApps] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Define gesture directions
  const gestureDirections = [
    { id: 'up', name: 'Swipe Up', icon: 'arrow-up' },
    { id: 'down', name: 'Swipe Down', icon: 'arrow-down' },
    { id: 'left', name: 'Swipe Left', icon: 'arrow-left' },
    { id: 'right', name: 'Swipe Right', icon: 'arrow-right' },
    { id: 'double_tap', name: 'Double Tap', icon: 'target' },
    { id: 'long_press', name: 'Long Press', icon: 'clock' },
    { id: 'pinch_in', name: 'Pinch In', icon: 'minimize' },
    { id: 'pinch_out', name: 'Pinch Out', icon: 'maximize' },
  ];
  
  // Define action types
  const actionTypes = [
    { id: 'openApp', name: 'Open App', icon: 'grid' },
    { id: 'openSettings', name: 'Open Settings', icon: 'settings' },
    { id: 'toggleDrawer', name: 'Toggle App Drawer', icon: 'layers' },
    { id: 'notification', name: 'Show Notifications', icon: 'bell' },
    { id: 'screenshot', name: 'Take Screenshot', icon: 'camera' },
    { id: 'recentApps', name: 'Recent Apps', icon: 'list' },
    { id: 'home', name: 'Go Home', icon: 'home' },
    { id: 'custom', name: 'Custom Action', icon: 'code' },
  ];
  
  // Load gestures and apps on component mount
  useEffect(() => {
    const loadData = async () => {
      // Load custom gestures
      const savedGestures = await PreferenceService.getItem('customGestures', '{}');
      setGestures(JSON.parse(savedGestures));
      
      // Load installed apps
      const installedApps = AppService.getInstalledApps();
      setApps(installedApps);
    };
    
    loadData();
  }, []);
  
  // Save gestures to preferences
  const saveGestures = async () => {
    try {
      await PreferenceService.setItem('customGestures', JSON.stringify(gestures));
      Alert.alert('Success', 'Gesture settings saved successfully!');
    } catch (error) {
      Alert.alert('Error', 'Failed to save gesture settings.');
    }
  };
  
  // Open the edit gesture modal
  const openEditModal = (gestureId) => {
    const existingGesture = gestures[gestureId];
    
    setEditingGesture(gestureId);
    if (existingGesture) {
      setActionType(existingGesture.type);
      setActionValue(existingGesture.packageName || existingGesture.value || '');
    } else {
      setActionType('openApp');
      setActionValue('');
    }
    
    setModalVisible(true);
  };
  
  // Handle saving the gesture action
  const saveGestureAction = () => {
    const newGestures = { ...gestures };
    
    // Create gesture action based on type
    let gestureAction = {
      type: actionType,
    };
    
    // Add action-specific properties
    switch (actionType) {
      case 'openApp':
        gestureAction.packageName = actionValue;
        break;
      case 'custom':
        gestureAction.value = actionValue;
        break;
      default:
        // No additional properties needed
        break;
    }
    
    // Save gesture
    newGestures[editingGesture] = gestureAction;
    setGestures(newGestures);
    
    // Close modal
    setModalVisible(false);
  };
  
  // Clear a gesture
  const clearGesture = (gestureId) => {
    Alert.alert(
      'Clear Gesture',
      'Are you sure you want to remove this gesture action?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear', 
          style: 'destructive',
          onPress: () => {
            const newGestures = { ...gestures };
            delete newGestures[gestureId];
            setGestures(newGestures);
          }
        },
      ]
    );
  };
  
  // Get app name from package name
  const getAppName = (packageName) => {
    const app = apps.find(app => app.packageName === packageName);
    return app ? app.appName : packageName;
  };
  
  // Get action name for display
  const getActionName = (gesture) => {
    if (!gesture) return 'Not Set';
    
    switch (gesture.type) {
      case 'openApp':
        return `Open: ${getAppName(gesture.packageName)}`;
      case 'openSettings':
        return 'Open Settings';
      case 'toggleDrawer':
        return 'Toggle App Drawer';
      case 'notification':
        return 'Show Notifications';
      case 'screenshot':
        return 'Take Screenshot';
      case 'recentApps':
        return 'Recent Apps';
      case 'home':
        return 'Go Home';
      case 'custom':
        return `Custom: ${gesture.value}`;
      default:
        return 'Unknown Action';
    }
  };
  
  // Filter apps based on search query
  const filteredApps = searchQuery
    ? apps.filter(app => 
        app.appName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        app.packageName.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : apps;
  
  // Render a gesture item
  const renderGestureItem = ({ item }) => {
    const gestureAction = gestures[item.id];
    
    return (
      <View style={styles.gestureItem}>
        <View style={styles.gestureInfo}>
          <View style={styles.gestureIconContainer}>
            <Feather name={item.icon} size={24} color="#2196F3" />
          </View>
          <View style={styles.gestureDetails}>
            <Text style={styles.gestureName}>{item.name}</Text>
            <Text style={styles.gestureAction}>{getActionName(gestureAction)}</Text>
          </View>
        </View>
        
        <View style={styles.gestureActions}>
          <TouchableOpacity 
            style={styles.gestureActionButton}
            onPress={() => openEditModal(item.id)}
          >
            <Feather name="edit-2" size={20} color="#4CAF50" />
          </TouchableOpacity>
          
          {gestureAction && (
            <TouchableOpacity 
              style={styles.gestureActionButton}
              onPress={() => clearGesture(item.id)}
            >
              <Feather name="trash-2" size={20} color="#F44336" />
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  };
  
  // Render an app item in the selection modal
  const renderAppItem = ({ item }) => (
    <TouchableOpacity
      style={styles.appItem}
      onPress={() => {
        setActionValue(item.packageName);
        setModalVisible(false);
        saveGestureAction();
      }}
    >
      <View style={styles.appIcon}>
        <Text style={styles.appIconText}>{item.appName.charAt(0)}</Text>
      </View>
      <View style={styles.appInfo}>
        <Text style={styles.appName}>{item.appName}</Text>
        <Text style={styles.packageName}>{item.packageName}</Text>
      </View>
    </TouchableOpacity>
  );
  
  // Render action type selection
  const renderActionTypeSelection = () => (
    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
      <View style={styles.actionTypeContainer}>
        {actionTypes.map((type) => (
          <TouchableOpacity
            key={type.id}
            style={[
              styles.actionTypeButton,
              actionType === type.id && styles.selectedActionType
            ]}
            onPress={() => setActionType(type.id)}
          >
            <Feather 
              name={type.icon} 
              size={20} 
              color={actionType === type.id ? '#FFFFFF' : '#333333'} 
            />
            <Text 
              style={[
                styles.actionTypeText,
                actionType === type.id && styles.selectedActionTypeText
              ]}
            >
              {type.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
  
  return (
    <View style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Customize Gesture Controls</Text>
          <Text style={styles.headerSubtitle}>
            Assign actions to gestures to control your launcher
          </Text>
        </View>
        
        <View style={styles.gestureList}>
          {gestureDirections.map((gesture) => (
            <React.Fragment key={gesture.id}>
              {renderGestureItem({ item: gesture })}
            </React.Fragment>
          ))}
        </View>
        
        <TouchableOpacity
          style={styles.saveButton}
          onPress={saveGestures}
        >
          <Feather name="check" size={20} color="#FFFFFF" />
          <Text style={styles.saveButtonText}>Save Gesture Settings</Text>
        </TouchableOpacity>
        
        <View style={styles.tipsContainer}>
          <Text style={styles.tipsTitle}>
            <Feather name="info" size={16} color="#2196F3" /> Tips
          </Text>
          <Text style={styles.tipText}>• Swipe gestures work anywhere on the home screen</Text>
          <Text style={styles.tipText}>• Double tap requires tapping the same spot twice</Text>
          <Text style={styles.tipText}>• Some gestures may conflict with app drawer behavior</Text>
        </View>
      </ScrollView>
      
      {/* Edit Gesture Modal */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                Edit {gestureDirections.find(g => g.id === editingGesture)?.name || 'Gesture'}
              </Text>
              <TouchableOpacity 
                style={styles.closeButton}
                onPress={() => setModalVisible(false)}
              >
                <Feather name="x" size={24} color="#333" />
              </TouchableOpacity>
            </View>
            
            <Text style={styles.sectionTitle}>Action Type</Text>
            {renderActionTypeSelection()}
            
            {/* Show different UI based on action type */}
            {actionType === 'openApp' ? (
              <View style={styles.appSelector}>
                <Text style={styles.sectionTitle}>Select App</Text>
                <View style={styles.searchContainer}>
                  <Feather name="search" size={20} color="#999" style={styles.searchIcon} />
                  <TextInput
                    style={styles.searchInput}
                    placeholder="Search apps..."
                    value={searchQuery}
                    onChangeText={setSearchQuery}
                  />
                </View>
                <FlatList
                  data={filteredApps}
                  renderItem={renderAppItem}
                  keyExtractor={(item) => item.packageName}
                  contentContainerStyle={styles.appList}
                />
              </View>
            ) : actionType === 'custom' ? (
              <View style={styles.customActionContainer}>
                <Text style={styles.sectionTitle}>Custom Action Value</Text>
                <TextInput
                  style={styles.customActionInput}
                  placeholder="Enter custom action identifier"
                  value={actionValue}
                  onChangeText={setActionValue}
                />
                <TouchableOpacity
                  style={styles.saveActionButton}
                  onPress={saveGestureAction}
                >
                  <Text style={styles.saveActionButtonText}>Save Action</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.simpleActionContainer}>
                <Text style={styles.actionDescription}>
                  {actionTypes.find(t => t.id === actionType)?.name} requires no additional configuration.
                </Text>
                <TouchableOpacity
                  style={styles.saveActionButton}
                  onPress={saveGestureAction}
                >
                  <Text style={styles.saveActionButtonText}>Save Action</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#757575',
  },
  gestureList: {
    padding: 16,
  },
  gestureItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    marginBottom: 12,
    padding: 16,
    elevation: 2,
  },
  gestureInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  gestureIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(33, 150, 243, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  gestureDetails: {
    flex: 1,
  },
  gestureName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 4,
  },
  gestureAction: {
    fontSize: 14,
    color: '#757575',
  },
  gestureActions: {
    flexDirection: 'row',
  },
  gestureActionButton: {
    padding: 8,
    marginLeft: 8,
  },
  saveButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    padding: 16,
    margin: 16,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  tipsContainer: {
    margin: 16,
    padding: 16,
    backgroundColor: '#E3F2FD',
    borderRadius: 8,
  },
  tipsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2196F3',
    marginBottom: 8,
  },
  tipText: {
    fontSize: 14,
    color: '#333333',
    marginBottom: 4,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
  closeButton: {
    padding: 4,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    margin: 16,
    marginBottom: 8,
  },
  actionTypeContainer: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingBottom: 16,
  },
  actionTypeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginHorizontal: 4,
    borderRadius: 20,
    backgroundColor: '#F0F0F0',
  },
  selectedActionType: {
    backgroundColor: '#2196F3',
  },
  actionTypeText: {
    fontSize: 14,
    color: '#333333',
    marginLeft: 4,
  },
  selectedActionTypeText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  appSelector: {
    flex: 1,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0F0F0',
    borderRadius: 8,
    margin: 16,
    paddingHorizontal: 12,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    height: 40,
    fontSize: 16,
  },
  appList: {
    paddingHorizontal: 16,
  },
  appItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  appIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#E0E0E0',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  appIconText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#757575',
  },
  appInfo: {
    flex: 1,
  },
  appName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 4,
  },
  packageName: {
    fontSize: 12,
    color: '#757575',
  },
  customActionContainer: {
    padding: 16,
  },
  customActionInput: {
    height: 48,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    paddingHorizontal: 12,
    fontSize: 16,
    marginBottom: 16,
  },
  simpleActionContainer: {
    padding: 16,
  },
  actionDescription: {
    fontSize: 14,
    color: '#757575',
    marginBottom: 16,
  },
  saveActionButton: {
    backgroundColor: '#2196F3',
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
  saveActionButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default GestureEditor;
