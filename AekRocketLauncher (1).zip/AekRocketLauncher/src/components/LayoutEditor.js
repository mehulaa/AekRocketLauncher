import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  Animated,
  Alert,
  PanResponder
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import { PreferenceService } from '../services/PreferenceService';
import { ThemeService } from '../services/ThemeService';
import { dimensions } from '../styles/dimensions';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const LayoutEditor = ({ navigation }) => {
  const [theme, setTheme] = useState({});
  const [gridSize, setGridSize] = useState({ columns: 5, rows: 6 });
  const [iconSize, setIconSize] = useState('medium');
  const [iconSpacing, setIconSpacing] = useState('normal');
  const [iconAlignment, setIconAlignment] = useState('center');
  const [showLabels, setShowLabels] = useState(true);
  const [previewScale] = useState(new Animated.Value(1));
  
  // Load settings
  useEffect(() => {
    const loadSettings = async () => {
      // Load theme
      const currentTheme = await ThemeService.getCurrentTheme();
      setTheme(currentTheme);
      
      // Load grid size
      const savedGrid = await PreferenceService.getItem('gridSize', { columns: 5, rows: 6 });
      setGridSize(savedGrid);
      
      // Load icon size
      const savedIconSize = await PreferenceService.getItem('iconSize', 'medium');
      setIconSize(savedIconSize);
      
      // Load icon spacing
      const savedIconSpacing = await PreferenceService.getItem('iconSpacing', 'normal');
      setIconSpacing(savedIconSpacing);
      
      // Load icon alignment
      const savedIconAlignment = await PreferenceService.getItem('iconAlignment', 'center');
      setIconAlignment(savedIconAlignment);
      
      // Load label visibility
      const savedShowLabels = await PreferenceService.getItem('showLabels', true);
      setShowLabels(savedShowLabels);
    };
    
    loadSettings();
    
    // Preview scale animation
    Animated.sequence([
      Animated.timing(previewScale, {
        toValue: 0.95,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.timing(previewScale, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      })
    ]).start();
  }, []);
  
  // Update grid size
  const updateGridSize = (property, value) => {
    const newGridSize = {
      ...gridSize,
      [property]: value
    };
    setGridSize(newGridSize);
  };
  
  // Apply and save changes
  const saveChanges = async () => {
    try {
      // Validate grid size
      if (gridSize.columns < 3 || gridSize.columns > 8) {
        Alert.alert('Invalid Grid Size', 'Columns must be between 3 and 8.');
        return;
      }
      
      if (gridSize.rows < 4 || gridSize.rows > 10) {
        Alert.alert('Invalid Grid Size', 'Rows must be between 4 and 10.');
        return;
      }
      
      // Save settings
      await PreferenceService.setItem('gridSize', gridSize);
      await PreferenceService.setItem('iconSize', iconSize);
      await PreferenceService.setItem('iconSpacing', iconSpacing);
      await PreferenceService.setItem('iconAlignment', iconAlignment);
      await PreferenceService.setItem('showLabels', showLabels);
      
      // Show success message
      Alert.alert(
        'Layout Saved',
        'Your layout changes have been saved successfully.',
        [
          { text: 'OK', onPress: () => navigation.goBack() }
        ]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to save layout settings.');
    }
  };
  
  // Reset to default layout
  const resetToDefault = () => {
    Alert.alert(
      'Reset Layout',
      'Are you sure you want to reset to the default layout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Reset', 
          style: 'destructive',
          onPress: () => {
            setGridSize({ columns: 5, rows: 6 });
            setIconSize('medium');
            setIconSpacing('normal');
            setIconAlignment('center');
            setShowLabels(true);
            
            // Preview animation
            Animated.sequence([
              Animated.timing(previewScale, {
                toValue: 0.9,
                duration: 150,
                useNativeDriver: true,
              }),
              Animated.timing(previewScale, {
                toValue: 1.05,
                duration: 200,
                useNativeDriver: true,
              }),
              Animated.timing(previewScale, {
                toValue: 1,
                duration: 150,
                useNativeDriver: true,
              })
            ]).start();
          }
        }
      ]
    );
  };
  
  // Calculate icon size in pixels
  const getIconPixelSize = () => {
    switch (iconSize) {
      case 'small': return 40;
      case 'large': return 70;
      case 'medium':
      default: return 55;
    }
  };
  
  // Calculate spacing in pixels
  const getSpacingPixels = () => {
    switch (iconSpacing) {
      case 'compact': return 4;
      case 'spacious': return 16;
      case 'normal':
      default: return 8;
    }
  };
  
  // Render a grid of mock icons
  const renderGridPreview = () => {
    const iconSizePx = getIconPixelSize();
    const spacingPx = getSpacingPixels();
    
    // Scale the preview to fit the screen
    const previewWidth = SCREEN_WIDTH - 60;
    const cellWidth = previewWidth / gridSize.columns;
    
    // Calculate how many rows to show in preview (max 6)
    const visibleRows = Math.min(gridSize.rows, 6);
    
    // Create grid cells
    const cells = [];
    for (let row = 0; row < visibleRows; row++) {
      for (let col = 0; col < gridSize.columns; col++) {
        // Calculate position
        const cellStyle = {
          width: cellWidth,
          height: cellWidth,
          padding: spacingPx,
        };
        
        // Calculate icon alignment
        const alignmentStyle = {};
        switch (iconAlignment) {
          case 'left':
            alignmentStyle.alignItems = 'flex-start';
            break;
          case 'right':
            alignmentStyle.alignItems = 'flex-end';
            break;
          case 'center':
          default:
            alignmentStyle.alignItems = 'center';
            break;
        }
        
        cells.push(
          <View key={`cell-${row}-${col}`} style={[styles.cell, cellStyle]}>
            <View style={[styles.cellContent, alignmentStyle]}>
              <View 
                style={[
                  styles.mockIcon, 
                  { 
                    width: iconSizePx * 0.6, 
                    height: iconSizePx * 0.6,
                    backgroundColor: theme.primaryColor 
                  }
                ]} 
              />
              
              {showLabels && (
                <View style={styles.mockLabel}>
                  <View style={[styles.labelBar, { backgroundColor: theme.textColor + '80' }]} />
                </View>
              )}
            </View>
          </View>
        );
      }
    }
    
    return (
      <View style={[styles.gridPreview, { borderColor: theme.primaryColor + '40' }]}>
        <View style={styles.gridContainer}>
          {cells}
        </View>
        
        {gridSize.rows > 6 && (
          <View style={styles.moreLabelContainer}>
            <Text style={[styles.moreLabel, { color: theme.textColor }]}>
              +{gridSize.rows - 6} more rows
            </Text>
          </View>
        )}
      </View>
    );
  };
  
  // Option Selector Component
  const OptionSelector = ({ title, options, value, onChange }) => {
    return (
      <View style={styles.optionSelector}>
        <Text style={[styles.optionTitle, { color: theme.textColor }]}>{title}</Text>
        <View style={styles.optionsRow}>
          {options.map((option) => (
            <TouchableOpacity
              key={option.value}
              style={[
                styles.optionButton,
                value === option.value && { backgroundColor: theme.primaryColor }
              ]}
              onPress={() => onChange(option.value)}
            >
              <Text 
                style={[
                  styles.optionButtonText,
                  { color: value === option.value ? '#FFFFFF' : theme.textColor }
                ]}
              >
                {option.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    );
  };
  
  // Number Stepper Component
  const NumberStepper = ({ title, value, onIncrement, onDecrement, min, max }) => {
    return (
      <View style={styles.numberStepper}>
        <Text style={[styles.stepperTitle, { color: theme.textColor }]}>{title}</Text>
        <View style={styles.stepperControls}>
          <TouchableOpacity
            style={[
              styles.stepperButton,
              { borderColor: theme.primaryColor },
              value <= min && { opacity: 0.5 }
            ]}
            onPress={onDecrement}
            disabled={value <= min}
          >
            <Feather name="minus" size={20} color={theme.primaryColor} />
          </TouchableOpacity>
          
          <View style={[styles.stepperValue, { backgroundColor: theme.cardColor }]}>
            <Text style={[styles.stepperValueText, { color: theme.textColor }]}>{value}</Text>
          </View>
          
          <TouchableOpacity
            style={[
              styles.stepperButton,
              { borderColor: theme.primaryColor },
              value >= max && { opacity: 0.5 }
            ]}
            onPress={onIncrement}
            disabled={value >= max}
          >
            <Feather name="plus" size={20} color={theme.primaryColor} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  
  // Toggle Button Component
  const ToggleButton = ({ title, value, onToggle }) => {
    return (
      <View style={styles.toggleContainer}>
        <Text style={[styles.toggleTitle, { color: theme.textColor }]}>{title}</Text>
        <TouchableOpacity
          style={[
            styles.toggleButton,
            { backgroundColor: value ? theme.primaryColor : theme.cardColor }
          ]}
          onPress={onToggle}
        >
          <View 
            style={[
              styles.toggleThumb,
              { 
                backgroundColor: '#FFFFFF',
                transform: [{ translateX: value ? 20 : 0 }]
              }
            ]} 
          />
        </TouchableOpacity>
      </View>
    );
  };
  
  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={[styles.headerTitle, { color: theme.textColor }]}>Layout Editor</Text>
          <Text style={[styles.headerSubtitle, { color: theme.textColor + '99' }]}>
            Customize your home screen grid and icon layout
          </Text>
        </View>
        
        {/* Grid Preview */}
        <View style={styles.previewSection}>
          <Text style={[styles.sectionTitle, { color: theme.primaryColor }]}>Preview</Text>
          <Animated.View 
            style={[
              styles.previewContainer,
              { transform: [{ scale: previewScale }] }
            ]}
          >
            {renderGridPreview()}
          </Animated.View>
        </View>
        
        <View style={[styles.section, { backgroundColor: theme.cardColor }]}>
          <Text style={[styles.sectionTitle, { color: theme.primaryColor }]}>Grid Size</Text>
          
          <NumberStepper
            title="Columns"
            value={gridSize.columns}
            onIncrement={() => updateGridSize('columns', Math.min(gridSize.columns + 1, 8))}
            onDecrement={() => updateGridSize('columns', Math.max(gridSize.columns - 1, 3))}
            min={3}
            max={8}
          />
          
          <NumberStepper
            title="Rows"
            value={gridSize.rows}
            onIncrement={() => updateGridSize('rows', Math.min(gridSize.rows + 1, 10))}
            onDecrement={() => updateGridSize('rows', Math.max(gridSize.rows - 1, 4))}
            min={4}
            max={10}
          />
        </View>
        
        <View style={[styles.section, { backgroundColor: theme.cardColor }]}>
          <Text style={[styles.sectionTitle, { color: theme.primaryColor }]}>Icon Settings</Text>
          
          <OptionSelector
            title="Icon Size"
            options={[
              { label: 'Small', value: 'small' },
              { label: 'Medium', value: 'medium' },
              { label: 'Large', value: 'large' }
            ]}
            value={iconSize}
            onChange={setIconSize}
          />
          
          <OptionSelector
            title="Icon Spacing"
            options={[
              { label: 'Compact', value: 'compact' },
              { label: 'Normal', value: 'normal' },
              { label: 'Spacious', value: 'spacious' }
            ]}
            value={iconSpacing}
            onChange={setIconSpacing}
          />
          
          <OptionSelector
            title="Icon Alignment"
            options={[
              { label: 'Left', value: 'left' },
              { label: 'Center', value: 'center' },
              { label: 'Right', value: 'right' }
            ]}
            value={iconAlignment}
            onChange={setIconAlignment}
          />
          
          <ToggleButton
            title="Show Icon Labels"
            value={showLabels}
            onToggle={() => setShowLabels(!showLabels)}
          />
        </View>
        
        <View style={styles.infoContainer}>
          <Feather name="info" size={20} color={theme.primaryColor} style={styles.infoIcon} />
          <Text style={[styles.infoText, { color: theme.textColor }]}>
            Widgets can span multiple grid cells. Adjust grid size to accommodate your widgets.
          </Text>
        </View>
        
        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={[styles.actionButton, styles.resetButton]}
            onPress={resetToDefault}
          >
            <Feather name="refresh-cw" size={20} color="#FFFFFF" />
            <Text style={styles.actionButtonText}>Reset</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, styles.saveButton, { backgroundColor: theme.primaryColor }]}
            onPress={saveChanges}
          >
            <Feather name="check" size={20} color="#FFFFFF" />
            <Text style={styles.actionButtonText}>Apply</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  header: {
    marginBottom: 24,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
  },
  previewSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  previewContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  gridPreview: {
    borderWidth: 2,
    borderRadius: 16,
    padding: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    overflow: 'hidden',
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  cell: {
    justifyContent: 'center',
  },
  cellContent: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  mockIcon: {
    borderRadius: 12,
  },
  mockLabel: {
    marginTop: 4,
    alignItems: 'center',
  },
  labelBar: {
    width: 24,
    height: 4,
    borderRadius: 2,
  },
  moreLabelContainer: {
    marginTop: 12,
    alignItems: 'center',
  },
  moreLabel: {
    fontSize: 14,
    fontStyle: 'italic',
  },
  section: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
  },
  numberStepper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  stepperTitle: {
    fontSize: 16,
    fontWeight: '500',
  },
  stepperControls: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepperButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  stepperValue: {
    width: 50,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    marginHorizontal: 8,
  },
  stepperValueText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  optionSelector: {
    marginBottom: 16,
  },
  optionTitle: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 8,
  },
  optionsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  optionButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  optionButtonText: {
    fontWeight: '500',
  },
  toggleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  toggleTitle: {
    fontSize: 16,
    fontWeight: '500',
  },
  toggleButton: {
    width: 50,
    height: 30,
    borderRadius: 15,
    justifyContent: 'center',
    padding: 2,
  },
  toggleThumb: {
    width: 26,
    height: 26,
    borderRadius: 13,
  },
  infoContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 24,
  },
  infoIcon: {
    marginRight: 8,
  },
  infoText: {
    flex: 1,
    fontSize: 14,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    flex: 1,
    marginHorizontal: 8,
  },
  resetButton: {
    backgroundColor: '#757575',
  },
  saveButton: {
    backgroundColor: '#4CAF50',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
    marginLeft: 8,
  },
});

export default LayoutEditor;
