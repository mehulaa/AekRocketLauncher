/**
 * Advanced Widget Component
 * A fully customizable widget with multiple layout options, themes, and data sources
 */

import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Animated } from 'react-native';
import { ThemeService } from '../../services/ThemeService';
import { LocalizationService } from '../../services/LocalizationService';
import { PreferenceService } from '../../services/PreferenceService';
import { PerformanceMonitoringService } from '../../services/PerformanceMonitoringService';
import { SustainabilityService } from '../../services/SustainabilityService';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

// Define widget types and sizes
const widgetTypes = {
  INFO: 'info',
  STATS: 'stats',
  CONTROLS: 'controls',
  CALENDAR: 'calendar',
  MEDIA: 'media',
  SUSTAINABILITY: 'sustainability',
  CUSTOM: 'custom',
};

const widgetSizes = {
  SMALL: 'small', // 1x1
  MEDIUM: 'medium', // 2x1
  LARGE: 'large', // 2x2
  XLARGE: 'xlarge', // 4x2
  CUSTOM: 'custom', // Custom dimensions
};

const AdvancedWidget = ({
  type = widgetTypes.INFO,
  size = widgetSizes.MEDIUM,
  title = 'Widget',
  data = {},
  customStyle = {},
  customLayout = null,
  onPress = null,
  onLongPress = null,
  refreshInterval = 0,
  animationStyle = 'default',
  chartType = 'line',
  icon = null,
  theme = null,
  customDimensions = { width: 2, height: 1 },
  enableInteractions = true,
  useGlass = false,
}) => {
  const [widgetData, setWidgetData] = useState(data);
  const [currentTheme, setCurrentTheme] = useState(null);
  const [expanded, setExpanded] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  
  // Animation values
  const [scale] = useState(new Animated.Value(1));
  const [rotate] = useState(new Animated.Value(0));
  const [opacity] = useState(new Animated.Value(1));
  const [translateY] = useState(new Animated.Value(0));
  
  // Helper function to get translation function if available
  const t = (key, defaultValue) => {
    try {
      // Check if LocalizationService is available
      if (LocalizationService && LocalizationService.translate) {
        return LocalizationService.translate(key);
      }
      return defaultValue || key;
    } catch (error) {
      return defaultValue || key;
    }
  };
  
  // Load theme
  useEffect(() => {
    const loadTheme = async () => {
      try {
        const activeTheme = theme || await ThemeService.getCurrentTheme();
        setCurrentTheme(activeTheme);
      } catch (error) {
        console.error('Error loading theme:', error);
        // Use default values if theme service fails
        setCurrentTheme({
          textColor: '#212121',
          primaryColor: '#2196F3',
          secondaryColor: '#FFC107',
          cardColor: '#FFFFFF',
          borderRadius: 8,
          shadowColor: 'rgba(0, 0, 0, 0.1)',
        });
      }
    };
    
    loadTheme();
    
    // Subscribe to theme changes if ThemeService is available
    try {
      if (ThemeService && ThemeService.subscribeToThemeChanges) {
        const unsubscribe = ThemeService.subscribeToThemeChanges(newTheme => {
          if (!theme) { // Only update if not using a custom theme
            setCurrentTheme(newTheme);
          }
        });
        
        return () => {
          if (unsubscribe) unsubscribe();
        };
      }
    } catch (error) {
      console.error('Error subscribing to theme changes:', error);
    }
  }, [theme]);
  
  // Refresh data at interval if specified
  useEffect(() => {
    let intervalId = null;
    
    if (refreshInterval > 0) {
      intervalId = setInterval(() => {
        refreshWidgetData();
      }, refreshInterval * 1000);
    }
    
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [refreshInterval]);
  
  // Initialize widget data
  useEffect(() => {
    setWidgetData(data);
  }, [data]);
  
  // Helper function to trigger animations
  const triggerAnimation = (animValue, toValue, config = {}) => {
    const defaultConfig = {
      duration: 300,
      useNativeDriver: true,
    };
    
    const mergedConfig = { ...defaultConfig, ...config };
    
    let animationValue;
    switch (animValue) {
      case 'scale':
        animationValue = scale;
        break;
      case 'rotate':
        animationValue = rotate;
        break;
      case 'opacity':
        animationValue = opacity;
        break;
      case 'translateY':
        animationValue = translateY;
        break;
      default:
        animationValue = scale;
    }
    
    return new Promise(resolve => {
      Animated.timing(animationValue, {
        toValue,
        ...mergedConfig,
      }).start(() => resolve());
    });
  };
  
  // Refresh widget data
  const refreshWidgetData = useCallback(async () => {
    if (refreshing) return;
    
    setRefreshing(true);
    triggerAnimation('rotate', 1, { duration: 500, useNativeDriver: true });
    
    try {
      // For dynamic data, this would fetch from a service
      // For now, just simulate a refresh
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Update with new data if available
      // This is where you'd typically update with fresh data
      setWidgetData(currentData => ({ ...currentData, lastUpdated: new Date() }));
    } catch (error) {
      console.error('Error refreshing widget data:', error);
    } finally {
      setRefreshing(false);
      // Reset rotation
      rotate.setValue(0);
    }
  }, [refreshing, rotate]);
  
  // Handle widget press
  const handlePress = useCallback(() => {
    triggerAnimation('scale', 0.95, { duration: 100, useNativeDriver: true })
      .then(() => triggerAnimation('scale', 1, { duration: 100, useNativeDriver: true }));
    
    if (onPress) {
      onPress(widgetData);
    }
  }, [onPress, widgetData, scale]);
  
  // Handle widget long press
  const handleLongPress = useCallback(() => {
    if (onLongPress) {
      onLongPress(widgetData);
    }
  }, [onLongPress, widgetData]);
  
  // Handle expand/collapse
  const toggleExpand = useCallback(() => {
    if (!expanded) {
      triggerAnimation('translateY', 20, { duration: 200, useNativeDriver: true })
        .then(() => {
          setExpanded(true);
          return triggerAnimation('translateY', 0, { duration: 200, useNativeDriver: true });
        });
    } else {
      triggerAnimation('translateY', 20, { duration: 200, useNativeDriver: true })
        .then(() => {
          setExpanded(false);
          return triggerAnimation('translateY', 0, { duration: 200, useNativeDriver: true });
        });
    }
  }, [expanded, translateY]);
  
  // Render widget content based on type
  const renderWidgetContent = () => {
    if (!currentTheme) return null;
    
    switch (type) {
      case widgetTypes.INFO:
        return renderInfoWidget();
      case widgetTypes.STATS:
        return renderStatsWidget();
      case widgetTypes.CONTROLS:
        return renderControlsWidget();
      case widgetTypes.CALENDAR:
        return renderCalendarWidget();
      case widgetTypes.MEDIA:
        return renderMediaWidget();
      case widgetTypes.SUSTAINABILITY:
        return renderSustainabilityWidget();
      case widgetTypes.CUSTOM:
        return customLayout ? customLayout(widgetData, currentTheme) : renderDefaultWidget();
      default:
        return renderDefaultWidget();
    }
  };
  
  // Render default widget
  const renderDefaultWidget = () => (
    <View style={styles.defaultContent}>
      {icon && <Icon name={icon} size={24} color={currentTheme.primaryColor} style={styles.icon} />}
      <Text style={[styles.title, { color: currentTheme.textColor }]}>{title}</Text>
      <Text style={[styles.subtitle, { color: currentTheme.textColor }]}>
        {widgetData.description || t('widget.no_data', 'No data available')}
      </Text>
    </View>
  );
  
  // Render info widget
  const renderInfoWidget = () => (
    <View style={styles.infoContent}>
      <View style={styles.infoHeader}>
        {icon && <Icon name={icon} size={24} color={currentTheme.primaryColor} style={styles.icon} />}
        <Text style={[styles.title, { color: currentTheme.textColor }]}>{title}</Text>
      </View>
      
      <View style={styles.infoBody}>
        {widgetData.items && widgetData.items.map((item, index) => (
          <View key={index} style={styles.infoItem}>
            <Text style={[styles.infoLabel, { color: currentTheme.textColor }]}>{item.label}</Text>
            <Text style={[styles.infoValue, { color: currentTheme.primaryColor }]}>{item.value}</Text>
          </View>
        ))}
      </View>
      
      {widgetData.footer && (
        <Text style={[styles.infoFooter, { color: currentTheme.secondaryColor }]}>
          {widgetData.footer}
        </Text>
      )}
    </View>
  );
  
  // Render stats widget
  const renderStatsWidget = () => (
    <View style={styles.statsContent}>
      <View style={styles.statsHeader}>
        {icon && <Icon name={icon} size={24} color={currentTheme.primaryColor} style={styles.icon} />}
        <Text style={[styles.title, { color: currentTheme.textColor }]}>{title}</Text>
      </View>
      
      <View style={styles.statsBody}>
        {/* This would be replaced with a real chart component */}
        <View style={[styles.chartPlaceholder, { backgroundColor: currentTheme.primaryColor + '40' }]}>
          <Text style={[styles.chartText, { color: currentTheme.primaryColor }]}>
            {chartType} Chart
          </Text>
        </View>
      </View>
      
      <View style={styles.statsFooter}>
        {widgetData.stats && widgetData.stats.map((stat, index) => (
          <View key={index} style={styles.statItem}>
            <Text style={[styles.statValue, { color: currentTheme.primaryColor }]}>{stat.value}</Text>
            <Text style={[styles.statLabel, { color: currentTheme.textColor }]}>{stat.label}</Text>
          </View>
        ))}
      </View>
    </View>
  );
  
  // Render controls widget
  const renderControlsWidget = () => (
    <View style={styles.controlsContent}>
      <View style={styles.controlsHeader}>
        {icon && <Icon name={icon} size={24} color={currentTheme.primaryColor} style={styles.icon} />}
        <Text style={[styles.title, { color: currentTheme.textColor }]}>{title}</Text>
      </View>
      
      <View style={styles.controlsBody}>
        {widgetData.controls && widgetData.controls.map((control, index) => (
          <TouchableOpacity 
            key={index} 
            style={[
              styles.controlButton, 
              { backgroundColor: control.active ? currentTheme.primaryColor : currentTheme.cardColor }
            ]}
            onPress={() => control.onPress && control.onPress()}
          >
            <Icon 
              name={control.icon} 
              size={24} 
              color={control.active ? '#FFFFFF' : currentTheme.primaryColor} 
            />
            <Text 
              style={[
                styles.controlLabel, 
                { color: control.active ? '#FFFFFF' : currentTheme.textColor }
              ]}
            >
              {control.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
  
  // Render calendar widget
  const renderCalendarWidget = () => (
    <View style={styles.calendarContent}>
      <View style={styles.calendarHeader}>
        {icon && <Icon name={icon} size={24} color={currentTheme.primaryColor} style={styles.icon} />}
        <Text style={[styles.title, { color: currentTheme.textColor }]}>{title}</Text>
      </View>
      
      <View style={styles.calendarBody}>
        {widgetData.events && widgetData.events.slice(0, 3).map((event, index) => (
          <View 
            key={index} 
            style={[
              styles.eventItem, 
              { borderLeftColor: event.color || currentTheme.primaryColor }
            ]}
          >
            <Text style={[styles.eventTime, { color: currentTheme.secondaryColor }]}>
              {event.time}
            </Text>
            <Text style={[styles.eventTitle, { color: currentTheme.textColor }]}>
              {event.title}
            </Text>
          </View>
        ))}
      </View>
      
      {widgetData.events && widgetData.events.length > 3 && (
        <TouchableOpacity style={styles.viewMoreButton} onPress={handlePress}>
          <Text style={[styles.viewMoreText, { color: currentTheme.primaryColor }]}>
            {t('widget.view_more', 'View more')} ({widgetData.events.length - 3})
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
  
  // Render media widget
  const renderMediaWidget = () => (
    <View style={styles.mediaContent}>
      {widgetData.coverImage && (
        <Image 
          source={{ uri: widgetData.coverImage }} 
          style={styles.mediaCover} 
          resizeMode="cover"
        />
      )}
      
      <View style={styles.mediaInfo}>
        <Text style={[styles.mediaTitle, { color: currentTheme.textColor }]}>
          {widgetData.title || title}
        </Text>
        <Text style={[styles.mediaSubtitle, { color: currentTheme.secondaryColor }]}>
          {widgetData.artist || widgetData.album || ''}
        </Text>
      </View>
      
      <View style={styles.mediaControls}>
        <TouchableOpacity style={styles.mediaButton}>
          <Icon name="skip-previous" size={24} color={currentTheme.primaryColor} />
        </TouchableOpacity>
        <TouchableOpacity style={[styles.mediaPlayButton, { backgroundColor: currentTheme.primaryColor }]}>
          <Icon name={widgetData.isPlaying ? "pause" : "play"} size={24} color="#FFFFFF" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.mediaButton}>
          <Icon name="skip-next" size={24} color={currentTheme.primaryColor} />
        </TouchableOpacity>
      </View>
    </View>
  );
  
  // Render sustainability widget
  const renderSustainabilityWidget = () => (
    <View style={styles.sustainabilityContent}>
      <View style={styles.sustainabilityHeader}>
        <Icon name={icon || "leaf"} size={24} color={currentTheme.primaryColor} style={styles.icon} />
        <Text style={[styles.title, { color: currentTheme.textColor }]}>
          {title || t('sustainability.title', 'Sustainability')}
        </Text>
      </View>
      
      <View style={styles.sustainabilityBody}>
        <View style={styles.ecoMetric}>
          <View style={[styles.ecoCircle, { borderColor: '#4CAF50' }]}>
            <Text style={[styles.ecoValue, { color: '#4CAF50' }]}>
              {widgetData.batterySavings || '10%'}
            </Text>
          </View>
          <Text style={[styles.ecoLabel, { color: currentTheme.textColor }]}>
            {t('sustainability.battery', 'Battery')}
          </Text>
        </View>
        
        <View style={styles.ecoMetric}>
          <View style={[styles.ecoCircle, { borderColor: '#2196F3' }]}>
            <Text style={[styles.ecoValue, { color: '#2196F3' }]}>
              {widgetData.memorySavings || '15%'}
            </Text>
          </View>
          <Text style={[styles.ecoLabel, { color: currentTheme.textColor }]}>
            {t('sustainability.memory', 'Memory')}
          </Text>
        </View>
        
        <View style={styles.ecoMetric}>
          <View style={[styles.ecoCircle, { borderColor: '#FF9800' }]}>
            <Text style={[styles.ecoValue, { color: '#FF9800' }]}>
              {widgetData.cpuSavings || '8%'}
            </Text>
          </View>
          <Text style={[styles.ecoLabel, { color: currentTheme.textColor }]}>
            {t('sustainability.cpu', 'CPU')}
          </Text>
        </View>
      </View>
      
      <TouchableOpacity
        style={[styles.ecoTipButton, { backgroundColor: currentTheme.primaryColor + '20' }]}
        onPress={handlePress}
      >
        <Icon name="lightbulb-outline" size={16} color={currentTheme.primaryColor} />
        <Text style={[styles.ecoTipText, { color: currentTheme.primaryColor }]}>
          {widgetData.ecoTip || t('sustainability.tip_preview', 'Tap for eco-friendly tips')}
        </Text>
      </TouchableOpacity>
    </View>
  );
  
  // Get dynamic styles based on widget size
  const getDynamicStyles = () => {
    const baseStyles = {
      width: 160,
      height: 80,
      margin: 8,
    };
    
    switch (size) {
      case widgetSizes.SMALL:
        return { width: 80, height: 80, margin: 8 };
      case widgetSizes.MEDIUM:
        return { width: 160, height: 80, margin: 8 };
      case widgetSizes.LARGE:
        return { width: 160, height: 160, margin: 8 };
      case widgetSizes.XLARGE:
        return { width: 328, height: 160, margin: 8 };
      case widgetSizes.CUSTOM:
        return {
          width: (customDimensions.width * 80) - 8,
          height: (customDimensions.height * 80) - 8,
          margin: 8,
        };
      default:
        return baseStyles;
    }
  };
  
  // Get glass effect styles
  const getGlassStyles = () => {
    if (!useGlass || !currentTheme) return {};
    
    return {
      backgroundColor: `${currentTheme.cardColor}99`, // Semi-transparent
      borderColor: `${currentTheme.cardColor}60`,
      shadowColor: currentTheme.primaryColor,
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.2,
      shadowRadius: 8,
    };
  };
  
  // Combine all styles
  const combinedStyles = [
    styles.container,
    getDynamicStyles(),
    getGlassStyles(),
    {
      borderRadius: currentTheme?.borderRadius || 8,
      backgroundColor: currentTheme?.cardColor || '#FFFFFF',
      borderColor: currentTheme?.shadowColor || 'rgba(0, 0, 0, 0.1)',
    },
    customStyle,
  ];
  
  // Widget wrapper with animations and interactions
  return (
    <Animated.View
      style={[
        combinedStyles,
        {
          transform: [
            { scale },
            { translateY },
            { 
              rotateZ: rotate.interpolate({
                inputRange: [0, 1],
                outputRange: ['0deg', '360deg'],
              })
            },
          ],
          opacity,
        },
      ]}
    >
      <TouchableOpacity
        style={styles.touchable}
        onPress={enableInteractions ? handlePress : null}
        onLongPress={enableInteractions ? handleLongPress : null}
        activeOpacity={enableInteractions ? 0.8 : 1}
      >
        {renderWidgetContent()}
      </TouchableOpacity>
      
      {refreshInterval > 0 && (
        <TouchableOpacity
          style={[styles.refreshButton, { backgroundColor: currentTheme?.primaryColor || '#2196F3' }]}
          onPress={refreshWidgetData}
          disabled={refreshing}
        >
          <Icon name="refresh" size={12} color="#FFFFFF" />
        </TouchableOpacity>
      )}
      
      {type !== widgetTypes.CUSTOM && size !== widgetSizes.SMALL && (
        <TouchableOpacity
          style={[styles.expandButton, { backgroundColor: currentTheme?.cardColor || '#FFFFFF' }]}
          onPress={toggleExpand}
        >
          <Icon
            name={expanded ? "chevron-up" : "chevron-down"}
            size={16}
            color={currentTheme?.textColor || '#000000'}
          />
        </TouchableOpacity>
      )}
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderWidth: 1,
    overflow: 'hidden',
    elevation: 2,
  },
  touchable: {
    flex: 1,
    padding: 8,
  },
  defaultContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 12,
    opacity: 0.7,
  },
  icon: {
    marginRight: 4,
  },
  refreshButton: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 18,
    height: 18,
    borderRadius: 9,
    justifyContent: 'center',
    alignItems: 'center',
  },
  expandButton: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: 'rgba(0, 0, 0, 0.05)',
  },
  
  // Info widget styles
  infoContent: {
    flex: 1,
  },
  infoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  infoBody: {
    flex: 1,
  },
  infoItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  infoLabel: {
    fontSize: 12,
  },
  infoValue: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  infoFooter: {
    fontSize: 10,
    textAlign: 'right',
    marginTop: 4,
  },
  
  // Stats widget styles
  statsContent: {
    flex: 1,
  },
  statsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  statsBody: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  chartPlaceholder: {
    width: '100%',
    height: 60,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  chartText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  statsFooter: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 8,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  statLabel: {
    fontSize: 10,
  },
  
  // Controls widget styles
  controlsContent: {
    flex: 1,
  },
  controlsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  controlsBody: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  controlButton: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    margin: 4,
  },
  controlLabel: {
    fontSize: 10,
    marginTop: 2,
  },
  
  // Calendar widget styles
  calendarContent: {
    flex: 1,
  },
  calendarHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  calendarBody: {
    flex: 1,
  },
  eventItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
    borderLeftWidth: 3,
    paddingLeft: 8,
  },
  eventTime: {
    fontSize: 10,
    marginRight: 8,
    minWidth: 40,
  },
  eventTitle: {
    fontSize: 12,
    flex: 1,
  },
  viewMoreButton: {
    alignSelf: 'flex-end',
    marginTop: 4,
  },
  viewMoreText: {
    fontSize: 10,
  },
  
  // Media widget styles
  mediaContent: {
    flex: 1,
  },
  mediaCover: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    opacity: 0.3,
  },
  mediaInfo: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 8,
  },
  mediaTitle: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  mediaSubtitle: {
    fontSize: 12,
  },
  mediaControls: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
  },
  mediaButton: {
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mediaPlayButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 8,
  },
  
  // Sustainability widget styles
  sustainabilityContent: {
    flex: 1,
  },
  sustainabilityHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  sustainabilityBody: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  ecoMetric: {
    alignItems: 'center',
  },
  ecoCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  ecoValue: {
    fontSize: 10,
    fontWeight: 'bold',
  },
  ecoLabel: {
    fontSize: 9,
    marginTop: 2,
  },
  ecoTipButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 4,
    borderRadius: 4,
    marginTop: 4,
  },
  ecoTipText: {
    fontSize: 10,
    marginLeft: 4,
    flex: 1,
  },
});

export default AdvancedWidget;
export { widgetTypes, widgetSizes };