/**
 * Widget Library Component
 * A collection of pre-configured widgets for easy use in the launcher
 */

import React from 'react';
import { View, StyleSheet, ScrollView, Text, TouchableOpacity } from 'react-native';
import AdvancedWidget, { widgetTypes, widgetSizes } from './AdvancedWidget';
import { LocalizationService } from '../../services/LocalizationService';
import { ThemeService } from '../../services/ThemeService';
import { SustainabilityService } from '../../services/SustainabilityService';
import { PerformanceMonitoringService } from '../../services/PerformanceMonitoringService';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const WidgetLibrary = ({ onSelectWidget, theme }) => {
  // Helper function to get translation function if available
  const t = (key, defaultValue) => {
    try {
      if (LocalizationService && LocalizationService.translate) {
        return LocalizationService.translate(key);
      }
      return defaultValue || key;
    } catch (error) {
      return defaultValue || key;
    }
  };

  // Sample widget data
  const sampleWidgets = [
    // Clock widget
    {
      type: widgetTypes.INFO,
      size: widgetSizes.MEDIUM,
      title: t('widget.clock', 'Clock'),
      icon: 'clock-outline',
      data: {
        items: [
          { label: t('widget.clock.time', 'Time'), value: '12:30 PM' },
          { label: t('widget.clock.date', 'Date'), value: 'Mar 11, 2025' },
        ],
        footer: t('widget.clock.timezone', 'Timezone: IST')
      }
    },
    
    // Weather widget
    {
      type: widgetTypes.INFO,
      size: widgetSizes.MEDIUM,
      title: t('widget.weather', 'Weather'),
      icon: 'weather-partly-cloudy',
      data: {
        items: [
          { label: t('widget.weather.temp', 'Temp'), value: '28°C' },
          { label: t('widget.weather.condition', 'Condition'), value: t('widget.weather.sunny', 'Sunny') },
        ],
        footer: t('widget.weather.location', 'Location: Delhi')
      }
    },
    
    // Battery widget
    {
      type: widgetTypes.STATS,
      size: widgetSizes.SMALL,
      title: t('widget.battery', 'Battery'),
      icon: 'battery-high',
      chartType: 'bar',
      data: {
        stats: [
          { label: t('widget.battery.remaining', 'Remaining'), value: '85%' },
        ]
      }
    },
    
    // Performance widget
    {
      type: widgetTypes.STATS,
      size: widgetSizes.LARGE,
      title: t('widget.performance', 'Performance'),
      icon: 'speedometer',
      chartType: 'line',
      data: {
        stats: [
          { label: 'CPU', value: '15%' },
          { label: 'RAM', value: '42%' },
          { label: 'Storage', value: '68%' }
        ]
      }
    },
    
    // Music widget
    {
      type: widgetTypes.MEDIA,
      size: widgetSizes.MEDIUM,
      title: t('widget.music', 'Music'),
      data: {
        title: 'Imagine',
        artist: 'John Lennon',
        album: 'Imagine',
        isPlaying: false,
        coverImage: 'https://upload.wikimedia.org/wikipedia/en/8/8f/Imagine_John_Lennon_Single.jpg'
      }
    },
    
    // Quick settings widget
    {
      type: widgetTypes.CONTROLS,
      size: widgetSizes.MEDIUM,
      title: t('widget.quick_settings', 'Quick Settings'),
      data: {
        controls: [
          { icon: 'wifi', label: 'Wi-Fi', active: true, onPress: () => console.log('Toggled WiFi') },
          { icon: 'bluetooth', label: 'BT', active: false, onPress: () => console.log('Toggled Bluetooth') },
          { icon: 'flashlight', label: 'Flash', active: false, onPress: () => console.log('Toggled Flashlight') },
          { icon: 'do-not-disturb', label: 'DnD', active: true, onPress: () => console.log('Toggled DnD') }
        ]
      }
    },
    
    // Calendar widget
    {
      type: widgetTypes.CALENDAR,
      size: widgetSizes.LARGE,
      title: t('widget.calendar', 'Calendar'),
      icon: 'calendar',
      data: {
        events: [
          { time: '09:00', title: 'Morning Meeting', color: '#4CAF50' },
          { time: '12:30', title: 'Lunch with Team', color: '#2196F3' },
          { time: '15:00', title: 'Project Review', color: '#FF9800' },
          { time: '17:30', title: 'Gym Session', color: '#9C27B0' },
          { time: '20:00', title: 'Dinner with Family', color: '#E91E63' }
        ]
      }
    },
    
    // Sustainability widget
    {
      type: widgetTypes.SUSTAINABILITY,
      size: widgetSizes.MEDIUM,
      title: t('widget.sustainability', 'Eco Stats'),
      icon: 'leaf',
      data: {
        batterySavings: '12%',
        memorySavings: '8%',
        cpuSavings: '15%',
        ecoTip: t('widget.sustainability.tip', 'Dark theme saves battery life!')
      }
    }
  ];
  
  // Widget category sections
  const widgetCategories = [
    {
      id: 'essentials',
      title: t('widget.category.essentials', 'Essentials'),
      widgets: [sampleWidgets[0], sampleWidgets[1], sampleWidgets[2]]
    },
    {
      id: 'productivity',
      title: t('widget.category.productivity', 'Productivity'),
      widgets: [sampleWidgets[6], sampleWidgets[3]]
    },
    {
      id: 'media',
      title: t('widget.category.media', 'Media & Controls'),
      widgets: [sampleWidgets[4], sampleWidgets[5]]
    },
    {
      id: 'eco',
      title: t('widget.category.eco', 'Eco & Sustainability'),
      widgets: [sampleWidgets[7]]
    }
  ];
  
  // Handle widget selection
  const handleWidgetSelect = (widget) => {
    if (onSelectWidget) {
      onSelectWidget(widget);
    }
  };
  
  // Render a widget category section
  const renderWidgetCategory = (category) => (
    <View key={category.id} style={styles.categoryContainer}>
      <Text style={styles.categoryTitle}>{category.title}</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.widgetsRow}>
        {category.widgets.map((widget, index) => (
          <TouchableOpacity 
            key={index}
            style={styles.widgetContainer}
            onPress={() => handleWidgetSelect(widget)}
          >
            <AdvancedWidget
              {...widget}
              theme={theme}
              enableInteractions={false}
            />
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
  
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>{t('widget.library.title', 'Widget Library')}</Text>
      <Text style={styles.subtitle}>{t('widget.library.subtitle', 'Choose widgets to add to your launcher')}</Text>
      
      {widgetCategories.map(category => renderWidgetCategory(category))}
      
      <View style={styles.customWidgetContainer}>
        <TouchableOpacity 
          style={styles.createCustomWidget}
          onPress={() => handleWidgetSelect({ type: 'custom' })}
        >
          <Icon name="plus-circle-outline" size={32} color="#2196F3" />
          <Text style={styles.customWidgetText}>{t('widget.create_custom', 'Create Custom Widget')}</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    opacity: 0.7,
    marginBottom: 24,
  },
  categoryContainer: {
    marginBottom: 24,
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  widgetsRow: {
    flexDirection: 'row',
  },
  widgetContainer: {
    marginRight: 8,
  },
  customWidgetContainer: {
    marginTop: 16,
    marginBottom: 32,
    alignItems: 'center',
  },
  createCustomWidget: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderWidth: 2,
    borderColor: '#E0E0E0',
    borderRadius: 12,
    borderStyle: 'dashed',
  },
  customWidgetText: {
    marginLeft: 12,
    fontSize: 16,
    color: '#2196F3',
    fontWeight: 'bold',
  },
});

export default WidgetLibrary;