import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  TextInput,
  Alert,
  Switch
} from 'react-native';
import { ThemeService } from '../services/ThemeService';
import { PreferenceService } from '../services/PreferenceService';
import Feather from 'react-native-vector-icons/Feather';

// Helper component for color picker
const ColorPicker = ({ color, onColorChange, label }) => {
  const [isPickerOpen, setIsPickerOpen] = useState(false);
  
  // Predefined colors
  const predefinedColors = [
    '#FF5252', '#FF4081', '#E040FB', '#7C4DFF', 
    '#536DFE', '#448AFF', '#40C4FF', '#18FFFF',
    '#64FFDA', '#69F0AE', '#B2FF59', '#EEFF41',
    '#FFFF00', '#FFD740', '#FFAB40', '#FF6E40',
    '#F5F5F5', '#E0E0E0', '#9E9E9E', '#212121'
  ];
  
  return (
    <View style={styles.colorPickerContainer}>
      <Text style={styles.colorPickerLabel}>{label}</Text>
      <TouchableOpacity 
        style={[styles.colorPreview, { backgroundColor: color }]}
        onPress={() => setIsPickerOpen(!isPickerOpen)}
      />
      
      {isPickerOpen && (
        <View style={styles.colorPalette}>
          {predefinedColors.map((presetColor, index) => (
            <TouchableOpacity
              key={`color-${index}`}
              style={[
                styles.colorOption,
                { backgroundColor: presetColor },
                color === presetColor && styles.selectedColorOption
              ]}
              onPress={() => {
                onColorChange(presetColor);
                setIsPickerOpen(false);
              }}
            />
          ))}
          
          <TextInput
            style={styles.colorInput}
            value={color}
            onChangeText={onColorChange}
            onBlur={() => setIsPickerOpen(false)}
            autoCapitalize="none"
            placeholder="#RRGGBB"
          />
        </View>
      )}
    </View>
  );
};

const ThemeEditor = ({ route, navigation }) => {
  const [availableThemes, setAvailableThemes] = useState({});
  const [selectedTheme, setSelectedTheme] = useState(null);
  const [editingTheme, setEditingTheme] = useState(null);
  const [isNewTheme, setIsNewTheme] = useState(false);
  const [themeEdited, setThemeEdited] = useState(false);
  
  // Load themes on component mount
  useEffect(() => {
    const loadThemes = async () => {
      const allThemes = ThemeService.getAllThemes();
      setAvailableThemes(allThemes);
      
      // If a theme ID was passed in route params, load that theme
      if (route.params?.themeId) {
        const theme = allThemes[route.params.themeId];
        if (theme) {
          setSelectedTheme(theme);
          setEditingTheme({ ...theme });
        }
      } else {
        // Load the current theme
        const currentTheme = await ThemeService.getCurrentTheme();
        setSelectedTheme(currentTheme);
        setEditingTheme({ ...currentTheme });
      }
    };
    
    loadThemes();
  }, [route.params]);
  
  // Create a new theme
  const createNewTheme = () => {
    // Create a copy of the selected theme as starting point
    const newTheme = {
      ...selectedTheme,
      id: `custom_${Date.now()}`,
      name: 'New Custom Theme',
    };
    
    setEditingTheme(newTheme);
    setIsNewTheme(true);
    setThemeEdited(true);
  };
  
  // Save theme changes
  const saveTheme = async () => {
    try {
      if (isNewTheme) {
        // Create new theme
        await ThemeService.createCustomTheme(editingTheme);
        Alert.alert('Success', 'New theme created successfully!');
      } else if (!availableThemes[editingTheme.id]?.isDefault) {
        // Update existing custom theme
        await ThemeService.updateCustomTheme(editingTheme);
        Alert.alert('Success', 'Theme updated successfully!');
      } else {
        // Can't modify default theme, create a copy instead
        Alert.alert(
          'Cannot Modify Default Theme',
          'Default themes cannot be modified. Would you like to create a copy of this theme instead?',
          [
            { text: 'Cancel', style: 'cancel' },
            { 
              text: 'Create Copy', 
              onPress: createNewTheme
            }
          ]
        );
        return;
      }
      
      // Refresh available themes
      const allThemes = ThemeService.getAllThemes();
      setAvailableThemes(allThemes);
      setSelectedTheme(editingTheme);
      setIsNewTheme(false);
      setThemeEdited(false);
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };
  
  // Apply the selected theme
  const applyTheme = async () => {
    try {
      if (themeEdited) {
        // If theme was edited but not saved, prompt to save first
        Alert.alert(
          'Save Changes?',
          'You have unsaved changes. Would you like to save before applying this theme?',
          [
            { text: 'Apply Without Saving', onPress: () => ThemeService.setTheme(selectedTheme.id) },
            { text: 'Cancel', style: 'cancel' },
            { 
              text: 'Save and Apply', 
              onPress: async () => {
                await saveTheme();
                await ThemeService.setTheme(editingTheme.id);
              }
            }
          ]
        );
      } else {
        // Apply the theme directly
        await ThemeService.setTheme(selectedTheme.id);
        Alert.alert('Success', 'Theme applied successfully!');
      }
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };
  
  // Delete a custom theme
  const deleteTheme = async () => {
    try {
      if (!selectedTheme) return;
      
      // Cannot delete default themes
      if (availableThemes[selectedTheme.id]?.isDefault) {
        Alert.alert('Error', 'Default themes cannot be deleted.');
        return;
      }
      
      Alert.alert(
        'Confirm Delete',
        `Are you sure you want to delete the theme "${selectedTheme.name}"? This cannot be undone.`,
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Delete', 
            style: 'destructive',
            onPress: async () => {
              await ThemeService.deleteCustomTheme(selectedTheme.id);
              
              // Refresh available themes
              const allThemes = ThemeService.getAllThemes();
              setAvailableThemes(allThemes);
              
              // Select default theme
              const defaultTheme = allThemes.default;
              setSelectedTheme(defaultTheme);
              setEditingTheme({ ...defaultTheme });
              
              Alert.alert('Success', 'Theme deleted successfully!');
            }
          }
        ]
      );
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };
  
  // Handle theme property change
  const handlePropertyChange = (property, value) => {
    setEditingTheme(prev => ({
      ...prev,
      [property]: value
    }));
    setThemeEdited(true);
  };
  
  // Select a theme to edit
  const selectTheme = (themeId) => {
    const theme = availableThemes[themeId];
    if (theme) {
      // If there are unsaved changes, prompt to save
      if (themeEdited) {
        Alert.alert(
          'Unsaved Changes',
          'You have unsaved changes. Would you like to save before switching themes?',
          [
            { text: 'Discard Changes', onPress: () => {
              setSelectedTheme(theme);
              setEditingTheme({ ...theme });
              setIsNewTheme(false);
              setThemeEdited(false);
            }},
            { text: 'Cancel', style: 'cancel' },
            { 
              text: 'Save', 
              onPress: async () => {
                await saveTheme();
                setSelectedTheme(theme);
                setEditingTheme({ ...theme });
                setIsNewTheme(false);
                setThemeEdited(false);
              }
            }
          ]
        );
      } else {
        setSelectedTheme(theme);
        setEditingTheme({ ...theme });
        setIsNewTheme(false);
        setThemeEdited(false);
      }
    }
  };
  
  // If no theme is selected or being edited, show loading
  if (!selectedTheme || !editingTheme) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading themes...</Text>
      </View>
    );
  }
  
  // Render the theme editor
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Theme Editor</Text>
        <TouchableOpacity 
          onPress={() => navigation.goBack()}
          style={styles.backButton}
        >
          <Feather name="x" size={24} color="#000" />
        </TouchableOpacity>
      </View>
      
      {/* Theme Selection */}
      <View style={styles.themeSelector}>
        <Text style={styles.sectionTitle}>Select Theme</Text>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.themeSelectorContent}
        >
          {Object.values(availableThemes).map(theme => (
            <TouchableOpacity
              key={theme.id}
              style={[
                styles.themeThumbnail,
                { 
                  backgroundColor: theme.backgroundColor,
                  borderColor: selectedTheme.id === theme.id ? '#000' : 'transparent',
                }
              ]}
              onPress={() => selectTheme(theme.id)}
            >
              <View style={[styles.themePreviewElement, { backgroundColor: theme.primaryColor }]} />
              <View style={[styles.themePreviewElement, { backgroundColor: theme.secondaryColor }]} />
              <Text 
                style={[
                  styles.themeName, 
                  { color: theme.textColor }
                ]}
                numberOfLines={1}
              >
                {theme.name}
              </Text>
            </TouchableOpacity>
          ))}
          
          {/* Add New Theme Button */}
          <TouchableOpacity
            style={styles.newThemeButton}
            onPress={createNewTheme}
          >
            <Feather name="plus" size={24} color="#000" />
            <Text style={styles.newThemeText}>New</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
      
      {/* Theme Editor Form */}
      <View style={styles.editorForm}>
        <Text style={styles.sectionTitle}>Edit Theme</Text>
        
        {/* Theme Name */}
        <View style={styles.formGroup}>
          <Text style={styles.formLabel}>Theme Name</Text>
          <TextInput 
            style={styles.textInput}
            value={editingTheme.name}
            onChangeText={(text) => handlePropertyChange('name', text)}
            placeholder="Theme Name"
          />
        </View>
        
        {/* Dark Mode Toggle */}
        <View style={styles.formGroup}>
          <Text style={styles.formLabel}>Dark Mode</Text>
          <Switch 
            value={editingTheme.isDark}
            onValueChange={(value) => handlePropertyChange('isDark', value)}
            trackColor={{ false: '#767577', true: '#81b0ff' }}
            thumbColor={editingTheme.isDark ? '#f5dd4b' : '#f4f3f4'}
          />
        </View>
        
        {/* Color Pickers */}
        <ColorPicker 
          color={editingTheme.backgroundColor}
          onColorChange={(color) => handlePropertyChange('backgroundColor', color)}
          label="Background Color"
        />
        
        <ColorPicker 
          color={editingTheme.primaryColor}
          onColorChange={(color) => handlePropertyChange('primaryColor', color)}
          label="Primary Color"
        />
        
        <ColorPicker 
          color={editingTheme.secondaryColor}
          onColorChange={(color) => handlePropertyChange('secondaryColor', color)}
          label="Secondary Color"
        />
        
        <ColorPicker 
          color={editingTheme.textColor}
          onColorChange={(color) => handlePropertyChange('textColor', color)}
          label="Text Color"
        />
        
        <ColorPicker 
          color={editingTheme.accentColor}
          onColorChange={(color) => handlePropertyChange('accentColor', color)}
          label="Accent Color"
        />
        
        <ColorPicker 
          color={editingTheme.cardColor}
          onColorChange={(color) => handlePropertyChange('cardColor', color)}
          label="Card Color"
        />
        
        <ColorPicker 
          color={editingTheme.shadowColor}
          onColorChange={(color) => handlePropertyChange('shadowColor', color)}
          label="Shadow Color"
        />
        
        {/* Icon Style Selector */}
        <View style={styles.formGroup}>
          <Text style={styles.formLabel}>Icon Style</Text>
          <View style={styles.iconStyleSelector}>
            {['flat', 'realistic', 'minimal', 'glowing'].map(style => (
              <TouchableOpacity
                key={style}
                style={[
                  styles.iconStyleOption,
                  editingTheme.iconStyle === style && styles.selectedIconStyleOption
                ]}
                onPress={() => handlePropertyChange('iconStyle', style)}
              >
                <Text 
                  style={[
                    styles.iconStyleText,
                    editingTheme.iconStyle === style && styles.selectedIconStyleText
                  ]}
                >
                  {style.charAt(0).toUpperCase() + style.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        
        {/* Border Radius Slider */}
        <View style={styles.formGroup}>
          <Text style={styles.formLabel}>Border Radius: {editingTheme.borderRadius}px</Text>
          <View style={styles.sliderContainer}>
            <Text>0</Text>
            <TouchableOpacity 
              style={[styles.sliderTrack, { backgroundColor: editingTheme.primaryColor }]}
              onLayout={(event) => {
                const { width } = event.nativeEvent.layout;
                this.sliderWidth = width;
              }}
              onStartShouldSetResponder={() => true}
              onResponderGrant={(event) => {
                const { locationX } = event.nativeEvent;
                const percentage = Math.min(Math.max(locationX / this.sliderWidth, 0), 1);
                const value = Math.round(percentage * 20);
                handlePropertyChange('borderRadius', value);
              }}
              onResponderMove={(event) => {
                const { locationX } = event.nativeEvent;
                const percentage = Math.min(Math.max(locationX / this.sliderWidth, 0), 1);
                const value = Math.round(percentage * 20);
                handlePropertyChange('borderRadius', value);
              }}
            >
              <View 
                style={[
                  styles.sliderThumb, 
                  { 
                    left: `${(editingTheme.borderRadius / 20) * 100}%`,
                    backgroundColor: editingTheme.accentColor
                  }
                ]} 
              />
            </TouchableOpacity>
            <Text>20</Text>
          </View>
        </View>
        
        {/* Animation Style Selector */}
        <View style={styles.formGroup}>
          <Text style={styles.formLabel}>Animation Style</Text>
          <View style={styles.animationStyleSelector}>
            {['bounce', 'elastic', 'smooth', 'minimal'].map(style => (
              <TouchableOpacity
                key={style}
                style={[
                  styles.animationStyleOption,
                  editingTheme.animationStyle === style && styles.selectedAnimationStyleOption
                ]}
                onPress={() => handlePropertyChange('animationStyle', style)}
              >
                <Text 
                  style={[
                    styles.animationStyleText,
                    editingTheme.animationStyle === style && styles.selectedAnimationStyleText
                  ]}
                >
                  {style.charAt(0).toUpperCase() + style.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        
        {/* Preview of theme */}
        <View style={styles.themePreviewContainer}>
          <Text style={styles.sectionTitle}>Preview</Text>
          <View 
            style={[
              styles.themePreview,
              {
                backgroundColor: editingTheme.backgroundColor,
                borderRadius: editingTheme.borderRadius
              }
            ]}
          >
            <View style={styles.previewHeader}>
              <Text style={[styles.previewTitle, { color: editingTheme.textColor }]}>
                Theme Preview
              </Text>
            </View>
            
            <View style={styles.previewContent}>
              <View 
                style={[
                  styles.previewCard, 
                  { 
                    backgroundColor: editingTheme.cardColor,
                    borderRadius: editingTheme.borderRadius,
                    shadowColor: editingTheme.shadowColor
                  }
                ]}
              >
                <Text style={[styles.previewCardTitle, { color: editingTheme.textColor }]}>
                  Sample Card
                </Text>
                <View 
                  style={[
                    styles.previewButton,
                    {
                      backgroundColor: editingTheme.primaryColor,
                      borderRadius: editingTheme.borderRadius / 2
                    }
                  ]}
                >
                  <Text style={[styles.previewButtonText, { color: editingTheme.backgroundColor }]}>
                    Button
                  </Text>
                </View>
              </View>
              
              <View style={styles.previewElements}>
                <View 
                  style={[
                    styles.previewElement,
                    { backgroundColor: editingTheme.primaryColor }
                  ]}
                />
                <View 
                  style={[
                    styles.previewElement,
                    { backgroundColor: editingTheme.secondaryColor }
                  ]}
                />
                <View 
                  style={[
                    styles.previewElement,
                    { backgroundColor: editingTheme.accentColor }
                  ]}
                />
              </View>
            </View>
          </View>
        </View>
      </View>
      
      {/* Action Buttons */}
      <View style={styles.actionButtons}>
        {!availableThemes[editingTheme.id]?.isDefault && !isNewTheme && (
          <TouchableOpacity
            style={[styles.actionButton, styles.deleteButton]}
            onPress={deleteTheme}
          >
            <Text style={styles.actionButtonText}>Delete</Text>
          </TouchableOpacity>
        )}
        
        <TouchableOpacity
          style={[styles.actionButton, styles.saveButton]}
          onPress={saveTheme}
        >
          <Text style={styles.actionButtonText}>Save</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.actionButton, styles.applyButton]}
          onPress={applyTheme}
        >
          <Text style={styles.actionButtonText}>Apply</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    backgroundColor: '#FFFFFF',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  backButton: {
    padding: 8,
  },
  themeSelector: {
    marginVertical: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginHorizontal: 16,
    marginBottom: 8,
  },
  themeSelectorContent: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  themeThumbnail: {
    width: 100,
    height: 100,
    marginRight: 12,
    borderRadius: 8,
    padding: 8,
    borderWidth: 2,
    justifyContent: 'space-between',
  },
  themePreviewElement: {
    height: 12,
    borderRadius: 4,
    marginBottom: 4,
  },
  themeName: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  newThemeButton: {
    width: 100,
    height: 100,
    borderRadius: 8,
    backgroundColor: '#E0E0E0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  newThemeText: {
    marginTop: 4,
    fontSize: 14,
    fontWeight: 'bold',
  },
  editorForm: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    margin: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  formGroup: {
    marginBottom: 16,
  },
  formLabel: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: '500',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  colorPickerContainer: {
    marginBottom: 16,
  },
  colorPickerLabel: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: '500',
  },
  colorPreview: {
    width: '100%',
    height: 40,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  colorPalette: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 8,
    padding: 8,
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
  },
  colorOption: {
    width: 30,
    height: 30,
    borderRadius: 15,
    margin: 4,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  selectedColorOption: {
    borderWidth: 2,
    borderColor: '#000',
  },
  colorInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 8,
    marginTop: 8,
    width: '100%',
  },
  iconStyleSelector: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  iconStyleOption: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
    backgroundColor: '#F0F0F0',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  selectedIconStyleOption: {
    backgroundColor: '#2196F3',
    borderColor: '#2196F3',
  },
  iconStyleText: {
    color: '#000',
  },
  selectedIconStyleText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  sliderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  sliderTrack: {
    flex: 1,
    height: 8,
    borderRadius: 4,
    marginHorizontal: 8,
    position: 'relative',
  },
  sliderThumb: {
    width: 20,
    height: 20,
    borderRadius: 10,
    position: 'absolute',
    top: -6,
    marginLeft: -10,
  },
  animationStyleSelector: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  animationStyleOption: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
    backgroundColor: '#F0F0F0',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  selectedAnimationStyleOption: {
    backgroundColor: '#2196F3',
    borderColor: '#2196F3',
  },
  animationStyleText: {
    color: '#000',
  },
  selectedAnimationStyleText: {
    color: '#FFF',
    fontWeight: 'bold',
  },
  themePreviewContainer: {
    marginTop: 16,
  },
  themePreview: {
    padding: 16,
    marginTop: 8,
  },
  previewHeader: {
    marginBottom: 16,
  },
  previewTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  previewContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  previewCard: {
    width: '48%',
    padding: 16,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  previewCardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  previewButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    alignItems: 'center',
  },
  previewButtonText: {
    fontWeight: 'bold',
  },
  previewElements: {
    width: '48%',
    justifyContent: 'space-between',
  },
  previewElement: {
    height: 24,
    borderRadius: 4,
    marginBottom: 8,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    padding: 16,
  },
  actionButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    marginLeft: 8,
  },
  deleteButton: {
    backgroundColor: '#F44336',
  },
  saveButton: {
    backgroundColor: '#4CAF50',
  },
  applyButton: {
    backgroundColor: '#2196F3',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});

export default ThemeEditor;
