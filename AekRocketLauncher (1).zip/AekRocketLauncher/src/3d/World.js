import React, { useRef, useImperativeHandle, forwardRef, useEffect, useState } from 'react';
import { View, StyleSheet, PanResponder } from 'react-native';
import { GLView } from 'expo-gl';
import { Renderer, TextureLoader } from 'expo-three';
import { Asset } from 'expo-asset';
import * as THREE from 'three';

import { threeJsUtils } from '../utils/threeJsUtils';
import { performanceUtils } from '../utils/performanceUtils';
import Wallpaper from './Wallpaper';
import Effects from './Effects';

// Create a 3D world that serves as the launcher background
const World = forwardRef((props, ref) => {
  const { theme, performanceMode } = props;
  
  // Refs
  const glRef = useRef(null);
  const rendererRef = useRef(null);
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const animationFrameRef = useRef(null);
  const wallpaperRef = useRef(null);
  const effectsRef = useRef(null);
  
  // State
  const [isInitialized, setIsInitialized] = useState(false);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  
  // Performance settings
  const threeJsSettings = performanceUtils.getThreeJsSettings();
  
  // Setup camera perspective
  const setupCamera = (width, height) => {
    const aspect = width / height;
    const fov = threeJsUtils.calculateFov(75);
    const camera = new THREE.PerspectiveCamera(fov, aspect, 0.1, 1000);
    camera.position.z = 5;
    return camera;
  };
  
  // Create a scene with background matching theme
  const setupScene = () => {
    const scene = new THREE.Scene();
    
    // Set background color
    const bgColor = new THREE.Color(theme.backgroundColor || '#000000');
    scene.background = bgColor;
    
    return scene;
  };
  
  // Setup lighting based on theme and performance settings
  const setupLights = (scene) => {
    // Ambient light based on theme
    const ambientLight = new THREE.AmbientLight(
      theme.isDark ? 0x333333 : 0x666666
    );
    scene.add(ambientLight);
    
    // Main directional light
    const mainLight = new THREE.DirectionalLight(0xffffff, 0.8);
    mainLight.position.set(5, 5, 7);
    
    // Add shadows if enabled in performance settings
    if (threeJsSettings.shadows) {
      mainLight.castShadow = true;
      mainLight.shadow.mapSize.width = threeJsSettings.textureQuality === 'high' ? 1024 : 512;
      mainLight.shadow.mapSize.height = threeJsSettings.textureQuality === 'high' ? 1024 : 512;
    }
    
    scene.add(mainLight);
    
    // Add accent light based on theme.accentColor
    const accentColorHex = theme.accentColor || '#FF4081';
    const accentLight = new THREE.PointLight(
      new THREE.Color(accentColorHex).getHex(),
      0.8,
      15
    );
    accentLight.position.set(-5, -2, 3);
    scene.add(accentLight);
    
    // Only add extra lights in higher performance modes
    if (threeJsSettings.maxLights > 2) {
      const fillLight = new THREE.PointLight(0x3366ff, 0.5, 10);
      fillLight.position.set(-3, 2, -4);
      scene.add(fillLight);
    }
    
    return { ambientLight, mainLight, accentLight };
  };
  
  // Initialize WebGL
  const onContextCreate = async (gl) => {
    // Save GL context
    glRef.current = gl;
    
    // Get dimensions
    const { drawingBufferWidth: width, drawingBufferHeight: height } = gl;
    setDimensions({ width, height });
    
    // Create renderer
    const renderer = new Renderer({ gl });
    renderer.setSize(width, height);
    renderer.setClearColor(theme.backgroundColor || '#000000');
    
    // Configure renderer based on performance settings
    renderer.setPixelRatio(threeJsSettings.pixelRatio);
    if (threeJsSettings.shadows) {
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    }
    
    rendererRef.current = renderer;
    
    // Setup camera
    const camera = setupCamera(width, height);
    cameraRef.current = camera;
    
    // Create scene
    const scene = setupScene();
    sceneRef.current = scene;
    
    // Add lights
    setupLights(scene);
    
    // Add wallpaper
    wallpaperRef.current = new Wallpaper(
      scene, 
      camera, 
      { theme, performanceSettings: threeJsSettings }
    );
    
    // Initialize wallpaper
    await wallpaperRef.current.initialize();
    
    // Add post-processing effects
    effectsRef.current = new Effects(
      scene,
      camera,
      renderer,
      { theme, performanceSettings: threeJsSettings }
    );
    
    // Initialize effects
    effectsRef.current.initialize();
    
    // Start the render loop
    startRenderLoop();
    
    // Mark as initialized
    setIsInitialized(true);
  };
  
  // Render loop
  const startRenderLoop = () => {
    const render = () => {
      if (
        rendererRef.current && 
        sceneRef.current && 
        cameraRef.current && 
        wallpaperRef.current
      ) {
        // Update wallpaper animations
        wallpaperRef.current.update();
        
        // Render the scene
        if (effectsRef.current && effectsRef.current.isEnabled()) {
          // Render with post-processing effects
          effectsRef.current.render();
        } else {
          // Normal rendering
          rendererRef.current.render(sceneRef.current, cameraRef.current);
        }
        
        // Request next frame
        gl.endFrameEXP();
      }
      
      // Schedule next frame
      animationFrameRef.current = requestAnimationFrame(render);
    };
    
    // Start the loop
    render();
  };
  
  // Stop render loop
  const stopRenderLoop = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
  };
  
  // Clean up resources
  const cleanup = () => {
    stopRenderLoop();
    
    // Dispose resources
    if (rendererRef.current) {
      rendererRef.current.dispose();
    }
    
    if (wallpaperRef.current) {
      wallpaperRef.current.dispose();
    }
    
    if (effectsRef.current) {
      effectsRef.current.dispose();
    }
  };
  
  // Handle pan gestures for 3D rotation effect
  const handlePan = (dx, dy) => {
    if (!cameraRef.current || !isInitialized) return;
    
    // Calculate rotation amount based on drag distance
    const rotationSensitivity = 0.01;
    const maxRotation = 0.2;
    
    // Limit rotation amount
    const rotationX = Math.min(Math.max(dy * rotationSensitivity, -maxRotation), maxRotation);
    const rotationY = Math.min(Math.max(-dx * rotationSensitivity, -maxRotation), maxRotation);
    
    // Apply rotation
    cameraRef.current.rotation.x = rotationX;
    cameraRef.current.rotation.y = rotationY;
  };
  
  // Reset camera perspective
  const resetPerspective = () => {
    if (!cameraRef.current || !isInitialized) return;
    
    // Animate camera back to default position
    const duration = 300; // ms
    const startTime = Date.now();
    const startRotationX = cameraRef.current.rotation.x;
    const startRotationY = cameraRef.current.rotation.y;
    
    const animateReset = () => {
      const elapsedTime = Date.now() - startTime;
      const progress = Math.min(elapsedTime / duration, 1);
      
      // Smooth easing
      const easeOutProgress = 1 - Math.pow(1 - progress, 3);
      
      // Interpolate rotation
      cameraRef.current.rotation.x = startRotationX * (1 - easeOutProgress);
      cameraRef.current.rotation.y = startRotationY * (1 - easeOutProgress);
      
      if (progress < 1) {
        requestAnimationFrame(animateReset);
      }
    };
    
    animateReset();
  };
  
  // Change wallpaper
  const setWallpaper = async (wallpaperType, config) => {
    if (!wallpaperRef.current || !isInitialized) return;
    
    await wallpaperRef.current.changeWallpaper(wallpaperType, config);
  };
  
  // Update effects
  const updateEffects = (effectsConfig) => {
    if (!effectsRef.current || !isInitialized) return;
    
    effectsRef.current.updateConfig(effectsConfig);
  };
  
  // Expose methods to parent component
  useImperativeHandle(ref, () => ({
    handlePan,
    resetPerspective,
    setWallpaper,
    updateEffects
  }));
  
  // Cleanup on unmount
  useEffect(() => {
    return () => {
      cleanup();
    };
  }, []);
  
  // Update when theme changes
  useEffect(() => {
    if (!isInitialized) return;
    
    // Update scene background color
    if (sceneRef.current) {
      sceneRef.current.background = new THREE.Color(theme.backgroundColor || '#000000');
    }
    
    // Update wallpaper theme
    if (wallpaperRef.current) {
      wallpaperRef.current.updateTheme(theme);
    }
    
    // Update effects
    if (effectsRef.current) {
      effectsRef.current.updateTheme(theme);
    }
  }, [theme, isInitialized]);
  
  // Update when performance mode changes
  useEffect(() => {
    if (!isInitialized) return;
    
    // Update renderer settings
    if (rendererRef.current) {
      rendererRef.current.setPixelRatio(threeJsSettings.pixelRatio);
      rendererRef.current.shadowMap.enabled = threeJsSettings.shadows;
    }
    
    // Update effects
    if (effectsRef.current) {
      effectsRef.current.updatePerformanceSettings(threeJsSettings);
    }
    
    // Update wallpaper
    if (wallpaperRef.current) {
      wallpaperRef.current.updatePerformanceSettings(threeJsSettings);
    }
  }, [performanceMode, isInitialized]);
  
  return (
    <View style={styles.container}>
      <GLView
        style={styles.glView}
        onContextCreate={onContextCreate}
      />
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  glView: {
    flex: 1,
  },
});

export default World;
