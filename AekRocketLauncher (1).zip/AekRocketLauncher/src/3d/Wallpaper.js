import * as THREE from 'three';
import { threeJsUtils } from '../utils/threeJsUtils';

// Wallpaper types
const WALLPAPER_TYPES = {
  STATIC: 'static',
  PARTICLES: 'particles',
  WAVES: 'waves',
  GRADIENT: 'gradient',
  TERRAIN: 'terrain',
  CUSTOM: 'custom'
};

class Wallpaper {
  constructor(scene, camera, options = {}) {
    this.scene = scene;
    this.camera = camera;
    this.theme = options.theme || {};
    this.performanceSettings = options.performanceSettings || {};
    
    // Wallpaper properties
    this.type = WALLPAPER_TYPES.STATIC;
    this.objects = [];
    this.clock = new THREE.Clock();
    this.animationMixers = [];
    this.particles = null;
    this.customTexture = null;
    this.config = {};
    
    // Bind methods
    this.update = this.update.bind(this);
    this.dispose = this.dispose.bind(this);
    this.changeWallpaper = this.changeWallpaper.bind(this);
  }
  
  // Initialize the wallpaper
  async initialize() {
    // Load wallpaper preference
    this.type = WALLPAPER_TYPES.PARTICLES; // Default for now
    
    // Create initial wallpaper
    await this.createWallpaper(this.type);
    
    return true;
  }
  
  // Create a wallpaper based on type
  async createWallpaper(type, config = {}) {
    // Clear existing wallpaper
    this.clearWallpaper();
    
    // Save type and config
    this.type = type;
    this.config = config;
    
    switch (type) {
      case WALLPAPER_TYPES.PARTICLES:
        this.createParticlesWallpaper(config);
        break;
      case WALLPAPER_TYPES.WAVES:
        this.createWavesWallpaper(config);
        break;
      case WALLPAPER_TYPES.GRADIENT:
        this.createGradientWallpaper(config);
        break;
      case WALLPAPER_TYPES.TERRAIN:
        this.createTerrainWallpaper(config);
        break;
      case WALLPAPER_TYPES.CUSTOM:
        await this.createCustomWallpaper(config);
        break;
      case WALLPAPER_TYPES.STATIC:
      default:
        this.createStaticWallpaper(config);
        break;
    }
  }
  
  // Change the wallpaper
  async changeWallpaper(type, config = {}) {
    await this.createWallpaper(type, config);
  }
  
  // Clear the current wallpaper
  clearWallpaper() {
    // Remove all objects
    for (const object of this.objects) {
      if (object.geometry) object.geometry.dispose();
      if (object.material) {
        if (Array.isArray(object.material)) {
          object.material.forEach(material => material.dispose());
        } else {
          object.material.dispose();
        }
      }
      this.scene.remove(object);
    }
    
    // Clear particles
    if (this.particles) {
      this.scene.remove(this.particles);
      this.particles.geometry.dispose();
      this.particles.material.dispose();
      this.particles = null;
    }
    
    // Dispose textures
    if (this.customTexture) {
      this.customTexture.dispose();
      this.customTexture = null;
    }
    
    // Clear animation mixers
    this.animationMixers = [];
    
    // Reset objects array
    this.objects = [];
  }
  
  // Create a static color wallpaper
  createStaticWallpaper(config = {}) {
    // Create a simple background plane
    const color = config.color || this.theme.backgroundColor || '#000000';
    
    const geometry = new THREE.PlaneBufferGeometry(20, 20);
    const material = new THREE.MeshBasicMaterial({ 
      color: new THREE.Color(color),
      side: THREE.DoubleSide
    });
    
    const plane = new THREE.Mesh(geometry, material);
    plane.position.z = -10;
    
    this.scene.add(plane);
    this.objects.push(plane);
  }
  
  // Create a particle system wallpaper
  createParticlesWallpaper(config = {}) {
    // Calculate particle count based on performance settings
    const particleCount = this.performanceSettings.particleCount || 200;
    
    // Get colors from theme
    const primaryColor = new THREE.Color(this.theme.primaryColor || '#2196F3');
    const secondaryColor = new THREE.Color(this.theme.secondaryColor || '#FFC107');
    const accentColor = new THREE.Color(this.theme.accentColor || '#FF4081');
    
    // Create particles geometry
    const particlesGeometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const sizes = new Float32Array(particleCount);
    
    // Fill arrays with random positions, colors, and sizes
    for (let i = 0; i < particleCount; i++) {
      // Position (spread widely in a hemisphere facing the camera)
      const i3 = i * 3;
      positions[i3] = (Math.random() - 0.5) * 20;
      positions[i3 + 1] = (Math.random() - 0.5) * 20;
      positions[i3 + 2] = (Math.random() - 0.5) * 10 - 5;
      
      // Random color from theme colors
      const colorRand = Math.random();
      let color;
      if (colorRand < 0.33) {
        color = primaryColor;
      } else if (colorRand < 0.66) {
        color = secondaryColor;
      } else {
        color = accentColor;
      }
      
      colors[i3] = color.r;
      colors[i3 + 1] = color.g;
      colors[i3 + 2] = color.b;
      
      // Random size
      sizes[i] = Math.random() * 0.1 + 0.05;
    }
    
    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particlesGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    particlesGeometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));
    
    // Create shader material
    const particlesMaterial = new THREE.ShaderMaterial({
      uniforms: {
        time: { value: 0 }
      },
      vertexShader: `
        attribute float size;
        varying vec3 vColor;
        uniform float time;
        
        void main() {
          vColor = color;
          
          // Simple animation - subtle drift
          vec3 pos = position;
          pos.x += sin(time * 0.3 + position.z * 5.0) * 0.1;
          pos.y += cos(time * 0.2 + position.x * 5.0) * 0.1;
          
          vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
          gl_PointSize = size * (300.0 / -mvPosition.z);
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        varying vec3 vColor;
        
        void main() {
          // Create a circular particle
          vec2 uv = gl_PointCoord.xy - 0.5;
          float circle = 1.0 - smoothstep(0.45, 0.5, length(uv));
          
          if (circle < 0.1) discard;
          
          gl_FragColor = vec4(vColor, circle);
        }
      `,
      transparent: true,
      depthWrite: false,
      vertexColors: true
    });
    
    // Create particle system
    this.particles = new THREE.Points(particlesGeometry, particlesMaterial);
    this.scene.add(this.particles);
  }
  
  // Create a waves wallpaper
  createWavesWallpaper(config = {}) {
    // Get colors from theme
    const backgroundColor = new THREE.Color(this.theme.backgroundColor || '#000000');
    const primaryColor = new THREE.Color(this.theme.primaryColor || '#2196F3');
    
    // Create a plane geometry with high segment count for waves
    const segmentCount = this.performanceSettings.textureQuality === 'high' ? 128 : 
                         this.performanceSettings.textureQuality === 'medium' ? 64 : 32;
    
    const geometry = new THREE.PlaneBufferGeometry(20, 20, segmentCount, segmentCount);
    
    // Create shader material
    const material = new THREE.ShaderMaterial({
      uniforms: {
        time: { value: 0 },
        backgroundColor: { value: backgroundColor },
        waveColor: { value: primaryColor },
        amplitude: { value: config.amplitude || 0.2 },
        frequency: { value: config.frequency || 0.5 },
        speed: { value: config.speed || 0.5 }
      },
      vertexShader: `
        uniform float time;
        uniform float amplitude;
        uniform float frequency;
        uniform float speed;
        
        varying vec2 vUv;
        varying float vElevation;
        
        void main() {
          vUv = uv;
          
          // Calculate wave height
          float elevation = sin(position.x * frequency + time * speed) * 
                           cos(position.y * frequency + time * speed) * 
                           amplitude;
          
          vElevation = elevation;
          
          // Apply elevation to vertex
          vec3 pos = position;
          pos.z += elevation;
          
          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 backgroundColor;
        uniform vec3 waveColor;
        
        varying vec2 vUv;
        varying float vElevation;
        
        void main() {
          // Blend colors based on elevation
          float mixFactor = (vElevation + 0.2) * 2.5;
          vec3 color = mix(backgroundColor, waveColor, mixFactor);
          
          gl_FragColor = vec4(color, 1.0);
        }
      `,
      side: THREE.DoubleSide
    });
    
    const plane = new THREE.Mesh(geometry, material);
    plane.position.z = -10;
    plane.rotation.x = Math.PI / 4;
    
    this.scene.add(plane);
    this.objects.push(plane);
  }
  
  // Create a gradient wallpaper
  createGradientWallpaper(config = {}) {
    // Get colors from theme
    const topColor = new THREE.Color(config.topColor || this.theme.primaryColor || '#2196F3');
    const bottomColor = new THREE.Color(config.bottomColor || this.theme.backgroundColor || '#000000');
    
    // Create a simple plane
    const geometry = new THREE.PlaneBufferGeometry(20, 20);
    
    // Create shader material
    const material = new THREE.ShaderMaterial({
      uniforms: {
        topColor: { value: topColor },
        bottomColor: { value: bottomColor },
        time: { value: 0 },
        animated: { value: config.animated ? 1.0 : 0.0 }
      },
      vertexShader: `
        varying vec2 vUv;
        
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 topColor;
        uniform vec3 bottomColor;
        uniform float time;
        uniform float animated;
        
        varying vec2 vUv;
        
        void main() {
          // Animated offset for gradient
          float offset = animated * sin(time * 0.2) * 0.1;
          
          // Create gradient from top to bottom
          float mixFactor = smoothstep(0.0, 1.0, vUv.y + offset);
          vec3 color = mix(bottomColor, topColor, mixFactor);
          
          gl_FragColor = vec4(color, 1.0);
        }
      `,
      side: THREE.DoubleSide
    });
    
    const plane = new THREE.Mesh(geometry, material);
    plane.position.z = -10;
    
    this.scene.add(plane);
    this.objects.push(plane);
  }
  
  // Create a terrain wallpaper
  createTerrainWallpaper(config = {}) {
    // Create a heightmap for the terrain
    const resolution = this.performanceSettings.textureQuality === 'high' ? 128 : 
                      this.performanceSettings.textureQuality === 'medium' ? 64 : 32;
    
    // Create geometry
    const geometry = new THREE.PlaneBufferGeometry(20, 20, resolution - 1, resolution - 1);
    
    // Create heightmap
    const heightMap = this.generateHeightMap(resolution, resolution);
    
    // Apply height map to vertices
    const positions = geometry.attributes.position.array;
    for (let i = 0; i < positions.length; i += 3) {
      const x = Math.floor((i / 3) % resolution);
      const y = Math.floor((i / 3) / resolution);
      
      if (x < resolution && y < resolution) {
        positions[i + 2] = heightMap[y * resolution + x] * (config.height || 2.0);
      }
    }
    
    // Update geometry
    geometry.attributes.position.needsUpdate = true;
    geometry.computeVertexNormals();
    
    // Create material
    const material = new THREE.MeshStandardMaterial({
      color: new THREE.Color(config.color || this.theme.primaryColor || '#2196F3'),
      roughness: 0.8,
      metalness: 0.2,
      flatShading: true,
      side: THREE.DoubleSide
    });
    
    const terrain = new THREE.Mesh(geometry, material);
    terrain.position.z = -10;
    terrain.rotation.x = -Math.PI / 4;
    
    this.scene.add(terrain);
    this.objects.push(terrain);
    
    // Add fog if enabled
    if (config.fog) {
      this.scene.fog = new THREE.Fog(
        new THREE.Color(this.theme.backgroundColor || '#000000'),
        5,
        20
      );
    }
  }
  
  // Create a custom wallpaper from user image
  async createCustomWallpaper(config = {}) {
    // In a real app, this would load user's custom image
    // For now, create a simple colored plane
    const color = config.color || this.theme.primaryColor || '#2196F3';
    
    const geometry = new THREE.PlaneBufferGeometry(20, 20);
    const material = new THREE.MeshBasicMaterial({ 
      color: new THREE.Color(color),
      side: THREE.DoubleSide
    });
    
    const plane = new THREE.Mesh(geometry, material);
    plane.position.z = -10;
    
    this.scene.add(plane);
    this.objects.push(plane);
  }
  
  // Generate a heightmap using Perlin noise (simplified for this example)
  generateHeightMap(width, height) {
    const heightMap = new Float32Array(width * height);
    
    // Simple implementation using sine waves for demo
    // In a real app, this would use proper Perlin/Simplex noise
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = y * width + x;
        
        // Normalize coordinates to -1..1
        const nx = (x / width) * 2 - 1;
        const ny = (y / height) * 2 - 1;
        
        // Generate noise using sine waves
        const frequency = 5.0;
        const noise = Math.sin(nx * frequency) * Math.cos(ny * frequency) * 0.5;
        
        heightMap[i] = noise;
      }
    }
    
    return heightMap;
  }
  
  // Update the wallpaper animation
  update() {
    const delta = this.clock.getDelta();
    const elapsedTime = this.clock.getElapsedTime();
    
    // Update particle animation
    if (this.particles && this.particles.material.uniforms) {
      this.particles.material.uniforms.time.value = elapsedTime;
    }
    
    // Update waves animation
    if (this.objects.length > 0 && this.type === WALLPAPER_TYPES.WAVES) {
      const waveMaterial = this.objects[0].material;
      if (waveMaterial.uniforms) {
        waveMaterial.uniforms.time.value = elapsedTime;
      }
    }
    
    // Update gradient animation
    if (this.objects.length > 0 && this.type === WALLPAPER_TYPES.GRADIENT) {
      const gradientMaterial = this.objects[0].material;
      if (gradientMaterial.uniforms) {
        gradientMaterial.uniforms.time.value = elapsedTime;
      }
    }
    
    // Update animation mixers
    for (const mixer of this.animationMixers) {
      mixer.update(delta);
    }
  }
  
  // Update the theme
  updateTheme(theme) {
    this.theme = theme;
    
    // Recreate the wallpaper with the new theme
    this.createWallpaper(this.type, this.config);
  }
  
  // Update performance settings
  updatePerformanceSettings(settings) {
    this.performanceSettings = settings;
    
    // Recreate wallpaper with new settings
    this.createWallpaper(this.type, this.config);
  }
  
  // Dispose wallpaper resources
  dispose() {
    this.clearWallpaper();
    
    // Stop clock
    this.clock.stop();
  }
}

export default Wallpaper;
