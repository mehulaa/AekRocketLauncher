import React, { useEffect, useState, useRef } from 'react';
import { View, StyleSheet, Animated } from 'react-native';
import { GLView } from 'expo-gl';
import { Renderer } from 'expo-three';
import * as THREE from 'three';

import { threeJsUtils } from '../utils/threeJsUtils';
import { performanceUtils } from '../utils/performanceUtils';
import { PreferenceService } from '../services/PreferenceService';

// A 3D App Icon component for displaying app icons with 3D effects
const AppIcon = ({ packageName, size = 60, style = 'flat', theme, onPress }) => {
  // State for icon data
  const [iconData, setIconData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Refs for Three.js objects
  const glRef = useRef(null);
  const rendererRef = useRef(null);
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const meshRef = useRef(null);
  const animationFrameRef = useRef(null);
  
  // Animation values
  const rotationY = useRef(new Animated.Value(0)).current;
  const scaleValue = useRef(new Animated.Value(1)).current;
  
  // Performance settings
  const threeJsSettings = performanceUtils.getThreeJsSettings();
  
  // Load icon data for this app
  useEffect(() => {
    const loadIconData = async () => {
      try {
        setIsLoading(true);
        
        // In a real app, this would load the actual app icon from the device
        // For this prototype, we'll use placeholder data
        
        // Check if there's a custom icon in preferences
        const customIcons = await PreferenceService.getItem('customIcons', '{}');
        const parsedIcons = JSON.parse(customIcons);
        
        if (parsedIcons[packageName]) {
          // Use custom icon data
          setIconData(parsedIcons[packageName]);
        } else {
          // Use default icon data (just a color for now)
          // In a real app, this would be the actual app icon
          const defaultIcon = {
            color: generateColorFromPackageName(packageName),
            shape: 'rounded-square',
            texture: null,
            customizations: {}
          };
          
          setIconData(defaultIcon);
        }
        
        setIsLoading(false);
      } catch (error) {
        console.error('Failed to load icon data:', error);
        setIsLoading(false);
      }
    };
    
    loadIconData();
  }, [packageName]);
  
  // Generate a consistent color from package name
  const generateColorFromPackageName = (name) => {
    // Simple hash function to generate a color
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    // Convert to hex color
    let color = '#';
    for (let i = 0; i < 3; i++) {
      const value = (hash >> (i * 8)) & 0xFF;
      color += ('00' + value.toString(16)).substr(-2);
    }
    
    return color;
  };
  
  // Initialize WebGL context
  const onContextCreate = async (gl) => {
    glRef.current = gl;
    
    // Create renderer
    const renderer = new Renderer({ gl });
    renderer.setSize(size, size);
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(threeJsSettings.pixelRatio);
    rendererRef.current = renderer;
    
    // Create scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    
    // Create camera
    const aspect = size / size;
    const camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 100);
    camera.position.z = 2.5;
    cameraRef.current = camera;
    
    // Add lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(1, 1, 2);
    scene.add(directionalLight);
    
    // Create icon mesh based on style and icon data
    createIconMesh();
    
    // Start render loop
    startRenderLoop();
  };
  
  // Create the 3D mesh for the icon
  const createIconMesh = () => {
    if (!sceneRef.current || !iconData) return;
    
    // Remove existing mesh if any
    if (meshRef.current) {
      sceneRef.current.remove(meshRef.current);
      meshRef.current.geometry.dispose();
      meshRef.current.material.dispose();
    }
    
    // Create geometry based on shape
    let geometry;
    switch (iconData.shape || 'rounded-square') {
      case 'circle':
        geometry = new THREE.CircleBufferGeometry(0.8, 32);
        break;
      case 'square':
        geometry = new THREE.PlaneBufferGeometry(1.6, 1.6);
        break;
      case 'rounded-square':
      default:
        // Create a rounded rectangle
        geometry = createRoundedRectGeometry(1.6, 1.6, 0.2);
        break;
    }
    
    // Create material based on style
    let material;
    const iconColor = new THREE.Color(iconData.color || '#FFFFFF');
    
    switch (style) {
      case 'realistic':
        material = new THREE.MeshStandardMaterial({
          color: iconColor,
          roughness: 0.2,
          metalness: 0.8,
          flatShading: false,
        });
        break;
      case 'glowing':
        material = new THREE.MeshBasicMaterial({
          color: iconColor,
          transparent: true,
          opacity: 0.9,
        });
        // Add glow effect
        addGlowEffect(sceneRef.current, iconColor);
        break;
      case 'minimal':
        material = new THREE.MeshBasicMaterial({
          color: iconColor,
          transparent: true,
          opacity: 0.7,
          side: THREE.DoubleSide,
        });
        break;
      case 'flat':
      default:
        material = new THREE.MeshLambertMaterial({
          color: iconColor,
          flatShading: true,
        });
        break;
    }
    
    // Create mesh
    const mesh = new THREE.Mesh(geometry, material);
    sceneRef.current.add(mesh);
    meshRef.current = mesh;
    
    // Apply customizations
    if (iconData.customizations) {
      applyCustomizations(mesh, iconData.customizations);
    }
  };
  
  // Create a rounded rectangle geometry
  const createRoundedRectGeometry = (width, height, radius) => {
    const shape = new THREE.Shape();
    
    const x = -width / 2;
    const y = -height / 2;
    
    shape.moveTo(x + radius, y);
    shape.lineTo(x + width - radius, y);
    shape.quadraticCurveTo(x + width, y, x + width, y + radius);
    shape.lineTo(x + width, y + height - radius);
    shape.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    shape.lineTo(x + radius, y + height);
    shape.quadraticCurveTo(x, y + height, x, y + height - radius);
    shape.lineTo(x, y + radius);
    shape.quadraticCurveTo(x, y, x + radius, y);
    
    const geometry = new THREE.ShapeBufferGeometry(shape);
    return geometry;
  };
  
  // Add glow effect to the icon
  const addGlowEffect = (scene, color) => {
    // Only add glow if performance settings allow
    if (!threeJsSettings.enableBloom) return;
    
    // Create a larger, transparent version of the icon for the glow
    const glowGeometry = new THREE.CircleBufferGeometry(1.0, 32);
    const glowMaterial = new THREE.MeshBasicMaterial({
      color: color,
      transparent: true,
      opacity: 0.3,
      side: THREE.BackSide
    });
    
    const glowMesh = new THREE.Mesh(glowGeometry, glowMaterial);
    glowMesh.position.z = -0.1;
    scene.add(glowMesh);
  };
  
  // Apply customizations to the icon mesh
  const applyCustomizations = (mesh, customizations) => {
    // Apply position offset
    if (customizations.positionOffset) {
      mesh.position.x += customizations.positionOffset.x || 0;
      mesh.position.y += customizations.positionOffset.y || 0;
      mesh.position.z += customizations.positionOffset.z || 0;
    }
    
    // Apply rotation
    if (customizations.rotation) {
      mesh.rotation.x = threeJsUtils.degToRad(customizations.rotation.x || 0);
      mesh.rotation.y = threeJsUtils.degToRad(customizations.rotation.y || 0);
      mesh.rotation.z = threeJsUtils.degToRad(customizations.rotation.z || 0);
    }
    
    // Apply scale
    if (customizations.scale) {
      mesh.scale.x = customizations.scale;
      mesh.scale.y = customizations.scale;
      mesh.scale.z = customizations.scale;
    }
  };
  
  // Start the render loop
  const startRenderLoop = () => {
    const render = () => {
      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        // Update mesh rotation based on animated value
        if (meshRef.current) {
          meshRef.current.rotation.y = rotationY._value;
        }
        
        // Render the scene
        rendererRef.current.render(sceneRef.current, cameraRef.current);
        glRef.current.endFrameEXP();
      }
      
      // Request next frame
      animationFrameRef.current = requestAnimationFrame(render);
    };
    
    // Start the loop
    render();
  };
  
  // Stop render loop
  const stopRenderLoop = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
  };
  
  // Clean up resources
  const cleanup = () => {
    stopRenderLoop();
    
    // Dispose resources
    if (meshRef.current) {
      meshRef.current.geometry.dispose();
      meshRef.current.material.dispose();
    }
    
    if (rendererRef.current) {
      rendererRef.current.dispose();
    }
  };
  
  // Create a hover/press animation for the icon
  const animateHover = () => {
    Animated.sequence([
      Animated.timing(scaleValue, {
        toValue: 1.2,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(scaleValue, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();
    
    // Add a rotation animation for 3D icons
    if (style === 'realistic' || style === 'glowing') {
      Animated.sequence([
        Animated.timing(rotationY, {
          toValue: threeJsUtils.degToRad(180),
          duration: 400,
          useNativeDriver: true,
        }),
        Animated.timing(rotationY, {
          toValue: threeJsUtils.degToRad(360),
          duration: 400,
          useNativeDriver: true,
        }),
      ]).start(() => {
        rotationY.setValue(0);
      });
    }
  };
  
  // Cleanup on unmount
  useEffect(() => {
    return () => {
      cleanup();
    };
  }, []);
  
  // Update when icon data or style changes
  useEffect(() => {
    if (sceneRef.current && iconData) {
      createIconMesh();
    }
  }, [iconData, style]);
  
  const containerStyle = {
    width: size,
    height: size,
    transform: [
      { scale: scaleValue }
    ]
  };
  
  // Show a loading placeholder if icon data is not loaded yet
  if (isLoading || !iconData) {
    return (
      <View style={[styles.loadingContainer, { width: size, height: size }]} />
    );
  }
  
  return (
    <Animated.View style={[styles.container, containerStyle]}>
      <GLView
        style={styles.glView}
        onContextCreate={onContextCreate}
        onTouchStart={animateHover}
        onTouchEnd={onPress}
      />
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  glView: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  loadingContainer: {
    backgroundColor: '#CCCCCC',
    borderRadius: 8,
    opacity: 0.5,
  },
});

export default AppIcon;
