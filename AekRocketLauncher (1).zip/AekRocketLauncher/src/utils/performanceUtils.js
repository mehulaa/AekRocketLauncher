/**
 * Utilities for performance optimization and management
 */

// Performance mode presets
const PERFORMANCE_MODES = {
  PERFORMANCE: 'performance',
  BALANCED: 'balanced',
  QUALITY: 'quality'
};

// Default settings for each performance mode
const DEFAULT_SETTINGS = {
  [PERFORMANCE_MODES.PERFORMANCE]: {
    threejs: {
      antialias: false,
      shadows: false,
      particleCount: 50,
      maxLights: 2,
      pixelRatio: 0.7,
      textureQuality: 'low',
      enableBloom: false,
      reflectionQuality: 'low',
      maxFPS: 30
    },
    animations: {
      reduceMotion: true,
      skipAnimations: true,
      simplifyTransitions: true
    },
    rendering: {
      enableBlur: false,
      limitParallelAnimations: true,
      lowResolutionMode: true,
      throttleRepaints: true
    },
    list: {
      recycleViews: true,
      removeClippedSubviews: true,
      maxToRenderPerBatch: 5,
      windowSize: 5,
      initialNumToRender: 5,
      columnsCount: 3
    }
  },
  [PERFORMANCE_MODES.BALANCED]: {
    threejs: {
      antialias: true,
      shadows: true,
      particleCount: 150,
      maxLights: 4,
      pixelRatio: 1.0,
      textureQuality: 'medium',
      enableBloom: true,
      reflectionQuality: 'medium',
      maxFPS: 60
    },
    animations: {
      reduceMotion: false,
      skipAnimations: false,
      simplifyTransitions: false
    },
    rendering: {
      enableBlur: true,
      limitParallelAnimations: false,
      lowResolutionMode: false,
      throttleRepaints: false,
    },
    list: {
      recycleViews: true,
      removeClippedSubviews: true,
      maxToRenderPerBatch: 10,
      windowSize: 10,
      initialNumToRender: 10,
      columnsCount: 4
    }
  },
  [PERFORMANCE_MODES.QUALITY]: {
    threejs: {
      antialias: true,
      shadows: true,
      particleCount: 300,
      maxLights: 8,
      pixelRatio: 1.2,
      textureQuality: 'high',
      enableBloom: true,
      reflectionQuality: 'high',
      maxFPS: 0 // No limit
    },
    animations: {
      reduceMotion: false,
      skipAnimations: false,
      simplifyTransitions: false
    },
    rendering: {
      enableBlur: true,
      limitParallelAnimations: false,
      lowResolutionMode: false,
      throttleRepaints: false
    },
    list: {
      recycleViews: true,
      removeClippedSubviews: false,
      maxToRenderPerBatch: 15,
      windowSize: 15,
      initialNumToRender: 15,
      columnsCount: 5
    }
  }
};

// Current performance mode
let currentMode = PERFORMANCE_MODES.BALANCED;
// Custom settings (user-defined)
let customSettings = {};

/**
 * Set the performance mode
 * @param {string} mode - The performance mode to set
 */
const setPerformanceMode = (mode) => {
  if (PERFORMANCE_MODES[mode.toUpperCase()]) {
    currentMode = mode;
  } else {
    // Default to balanced if an invalid mode is provided
    currentMode = PERFORMANCE_MODES.BALANCED;
    console.warn(`Invalid performance mode: ${mode}. Falling back to balanced mode.`);
  }
};

/**
 * Get the current performance settings
 * @returns {Object} The current performance settings
 */
const getCurrentSettings = () => {
  const baseSettings = DEFAULT_SETTINGS[currentMode];
  // Apply any custom settings
  return { ...baseSettings, ...customSettings };
};

/**
 * Update custom performance settings
 * @param {Object} settings - Custom settings to apply
 */
const updateCustomSettings = (settings) => {
  customSettings = { ...customSettings, ...settings };
};

/**
 * Reset custom settings
 */
const resetCustomSettings = () => {
  customSettings = {};
};

/**
 * Get Three.js performance settings
 * @returns {Object} Three.js settings based on current performance mode
 */
const getThreeJsSettings = () => {
  return getCurrentSettings().threejs;
};

/**
 * Get animation performance settings
 * @returns {Object} Animation settings based on current performance mode
 */
const getAnimationSettings = () => {
  return getCurrentSettings().animations;
};

/**
 * Get rendering performance settings
 * @returns {Object} Rendering settings based on current performance mode
 */
const getRenderingSettings = () => {
  return getCurrentSettings().rendering;
};

/**
 * Get list/drawer performance settings
 * @returns {Object} List/drawer settings based on current performance mode
 */
const getDrawerPerformanceSettings = () => {
  return getCurrentSettings().list;
};

/**
 * Calculate optimal particle count based on device performance
 * @returns {number} Optimal particle count
 */
const calculateOptimalParticleCount = () => {
  // In a real app, this would perform a benchmark
  // For now, we'll just use the preset value
  return getCurrentSettings().threejs.particleCount;
};

/**
 * Measure component rendering performance
 * @param {string} componentName - Name of the component to measure
 * @param {Function} callback - Function to measure
 * @returns {any} Return value from the callback
 */
const measurePerformance = (componentName, callback) => {
  const startTime = performance.now();
  const result = callback();
  const endTime = performance.now();
  
  console.log(`${componentName} render time: ${endTime - startTime}ms`);
  return result;
};

/**
 * Check if device meets minimum requirements for a feature
 * @param {string} featureName - Name of the feature to check
 * @returns {boolean} Whether the device meets minimum requirements
 */
const meetsMinimumRequirements = (featureName) => {
  // In a real app, this would check device capabilities
  switch (featureName) {
    case 'bloom':
    case 'reflections':
      return currentMode !== PERFORMANCE_MODES.PERFORMANCE;
    case 'particleEffects':
      return true; // All modes support particles (just different counts)
    default:
      return true;
  }
};

export const performanceUtils = {
  setPerformanceMode,
  getCurrentSettings,
  updateCustomSettings,
  resetCustomSettings,
  getThreeJsSettings,
  getAnimationSettings,
  getRenderingSettings,
  getDrawerPerformanceSettings,
  calculateOptimalParticleCount,
  measurePerformance,
  meetsMinimumRequirements,
  PERFORMANCE_MODES
};
