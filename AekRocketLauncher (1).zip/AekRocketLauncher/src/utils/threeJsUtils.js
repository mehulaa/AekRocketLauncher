/**
 * Utilities for Three.js integration with React Native
 */
import { Dimensions } from 'react-native';
import { performanceUtils } from './performanceUtils';

// Convert degrees to radians
const degToRad = (degrees) => {
  return degrees * (Math.PI / 180);
};

// Convert radians to degrees
const radToDeg = (radians) => {
  return radians * (180 / Math.PI);
};

// Get screen dimensions
const getScreenDimensions = () => {
  return Dimensions.get('window');
};

// Calculate field of view based on screen aspect ratio
const calculateFov = (defaultFov = 75) => {
  const { width, height } = getScreenDimensions();
  const aspectRatio = width / height;
  
  // Adjust FOV based on aspect ratio to maintain consistent view
  if (aspectRatio > 1.5) {
    return defaultFov - 5; // Reduce FOV for wider screens
  } else if (aspectRatio < 1.2) {
    return defaultFov + 5; // Increase FOV for taller screens
  }
  
  return defaultFov;
};

// Create a simple depth texture gradient
const createDepthTexture = (width, height, near = 0, far = 1) => {
  const size = width * height;
  const data = new Float32Array(size);
  
  for (let i = 0; i < height; i++) {
    for (let j = 0; j < width; j++) {
      const index = i * width + j;
      // Create gradient from near to far
      const depth = near + (far - near) * (i / height);
      data[index] = depth;
    }
  }
  
  return { data, width, height };
};

// Calculate pixel ratio based on performance settings
const getOptimalPixelRatio = () => {
  const settings = performanceUtils.getThreeJsSettings();
  return settings.pixelRatio;
};

// Create optimized material based on performance mode
const createOptimizedMaterial = (materialType, properties = {}) => {
  const settings = performanceUtils.getThreeJsSettings();
  const optimizedProperties = { ...properties };
  
  // Apply performance optimizations
  if (materialType === 'standard' || materialType === 'physical') {
    if (settings.reflectionQuality === 'low') {
      optimizedProperties.roughness = Math.max(0.5, properties.roughness || 0.5);
      optimizedProperties.metalness = Math.min(0.5, properties.metalness || 0.5);
    }
    
    // Reduce shadow and light calculations for performance mode
    if (!settings.shadows) {
      optimizedProperties.receiveShadow = false;
      optimizedProperties.castShadow = false;
    }
  }
  
  return optimizedProperties;
};

// Configure renderer based on performance settings
const configureRenderer = (renderer) => {
  const settings = performanceUtils.getThreeJsSettings();
  
  if (renderer) {
    renderer.setPixelRatio(getOptimalPixelRatio());
    renderer.shadowMap.enabled = settings.shadows;
    renderer.antialias = settings.antialias;
    
    // Set max frame rate if specified
    if (settings.maxFPS > 0) {
      renderer.setFrameRate(settings.maxFPS);
    }
  }
  
  return renderer;
};

// Create optimized camera
const createOptimizedCamera = (width, height, fov = 75, near = 0.1, far = 1000) => {
  const aspectRatio = width / height;
  const optimizedFov = calculateFov(fov);
  
  return {
    fov: optimizedFov,
    aspect: aspectRatio,
    near,
    far
  };
};

// Create a texture loader that respects performance settings
const createTextureLoader = () => {
  const settings = performanceUtils.getThreeJsSettings();
  
  return {
    loadTexture: (url) => {
      // In a real implementation, this would use THREE.TextureLoader
      // and apply mipmapping/anisotropy settings based on quality
      
      // Mock implementation
      return {
        texture: url,
        anisotropy: settings.textureQuality === 'high' ? 16 : 
                   settings.textureQuality === 'medium' ? 8 : 4
      };
    }
  };
};

// Calculate optimal light settings
const getOptimalLightSettings = () => {
  const settings = performanceUtils.getThreeJsSettings();
  
  return {
    maxLights: settings.maxLights,
    shadowMapSize: settings.textureQuality === 'high' ? 1024 : 
                  settings.textureQuality === 'medium' ? 512 : 256,
    enableShadows: settings.shadows
  };
};

// Create presets for various 3D effects
const createEffectPresets = () => {
  const settings = performanceUtils.getThreeJsSettings();
  
  return {
    glow: {
      enabled: settings.enableBloom,
      intensity: settings.textureQuality === 'high' ? 0.8 : 0.5,
      threshold: 0.7,
      radius: settings.textureQuality === 'high' ? 1 : 0.5
    },
    reflection: {
      enabled: settings.reflectionQuality !== 'low',
      resolution: settings.reflectionQuality === 'high' ? 512 : 256,
      bounces: settings.reflectionQuality === 'high' ? 3 : 1
    },
    particles: {
      count: settings.particleCount,
      size: settings.textureQuality === 'high' ? 3 : 
            settings.textureQuality === 'medium' ? 2 : 1
    }
  };
};

// Animation helpers for 3D objects
const animationHelpers = {
  // Smoothly interpolate between values
  lerp: (start, end, t) => {
    return start * (1 - t) + end * t;
  },
  
  // Create a spring animation curve
  spring: (t, damping = 0.5, frequency = 0.5) => {
    return 1 - Math.exp(-t * damping) * Math.cos(frequency * Math.PI * t);
  }
};

export const threeJsUtils = {
  degToRad,
  radToDeg,
  getScreenDimensions,
  calculateFov,
  createDepthTexture,
  getOptimalPixelRatio,
  createOptimizedMaterial,
  configureRenderer,
  createOptimizedCamera,
  createTextureLoader,
  getOptimalLightSettings,
  createEffectPresets,
  animationHelpers
};
