/**
 * Utilities for gesture detection and handling
 */

// Direction constants
export const Direction = {
  UP: 'up',
  DOWN: 'down',
  LEFT: 'left',
  RIGHT: 'right',
  NONE: 'none'
};

// Detect swipe direction from gesture state
const getSwipeDirection = (gestureState) => {
  const { dx, dy } = gestureState;
  const absX = Math.abs(dx);
  const absY = Math.abs(dy);
  
  // Calculate distance for threshold check
  const distance = Math.max(absX, absY);
  
  // Minimum distance to be considered a swipe
  if (distance < 10) {
    return { direction: Direction.NONE, distance: 0 };
  }
  
  // Determine if this is a horizontal or vertical swipe
  if (absX > absY) {
    // Horizontal swipe
    return {
      direction: dx > 0 ? Direction.RIGHT : Direction.LEFT,
      distance: absX
    };
  } else {
    // Vertical swipe
    return {
      direction: dy > 0 ? Direction.DOWN : Direction.UP,
      distance: absY
    };
  }
};

// Calculate velocity for animations
const getGestureVelocity = (gestureState) => {
  const { vx, vy } = gestureState;
  return Math.sqrt(vx * vx + vy * vy);
};

// Detect if gesture is a tap
const isTap = (gestureState) => {
  const { dx, dy, moveX, moveY } = gestureState;
  return Math.abs(dx) < 5 && Math.abs(dy) < 5 && moveX !== 0 && moveY !== 0;
};

// Detect if gesture is a long press
const isLongPress = (gestureState, duration = 500) => {
  const { dx, dy, moveX, moveY } = gestureState;
  return Math.abs(dx) < 5 && Math.abs(dy) < 5 && moveX !== 0 && moveY !== 0;
};

// Convert gesture to 3D rotation values
const getRotationFromGesture = (gestureState, sensitivity = 0.1) => {
  const { dx, dy } = gestureState;
  
  // Convert gesture movement to rotation angles
  // Limit rotation to reasonable values
  const maxRotation = 20;
  const rotationX = Math.min(Math.max(-dy * sensitivity, -maxRotation), maxRotation);
  const rotationY = Math.min(Math.max(dx * sensitivity, -maxRotation), maxRotation);
  
  return { rotationX, rotationY };
};

// Normalize gesture values for animation
const normalizeGestureValue = (value, rangeMin, rangeMax, outputMin = 0, outputMax = 1) => {
  // Ensure value is within the specified range
  const clampedValue = Math.min(Math.max(value, rangeMin), rangeMax);
  
  // Normalize to 0-1 range first
  const normalizedValue = (clampedValue - rangeMin) / (rangeMax - rangeMin);
  
  // Scale to output range
  return normalizedValue * (outputMax - outputMin) + outputMin;
};

// Convert coordinate to grid position
const snapToGrid = (x, y, gridSize, cellWidth, cellHeight) => {
  const gridX = Math.floor(x / cellWidth);
  const gridY = Math.floor(y / cellHeight);
  
  return {
    x: Math.min(Math.max(gridX, 0), gridSize.columns - 1),
    y: Math.min(Math.max(gridY, 0), gridSize.rows - 1)
  };
};

export const gestureUtils = {
  getSwipeDirection,
  getGestureVelocity,
  isTap,
  isLongPress,
  getRotationFromGesture,
  normalizeGestureValue,
  snapToGrid,
  Direction
};
