/**
 * Animation utilities for UI animations and transitions
 */
import { Animated, Easing } from 'react-native';
import { performanceUtils } from './performanceUtils';

// Animation timing presets
const DURATIONS = {
  VERY_FAST: 150,
  FAST: 250,
  NORMAL: 350,
  SLOW: 500,
  VERY_SLOW: 700
};

// Animation easing presets
const EASINGS = {
  // Standard curves
  LINEAR: Easing.linear,
  EASE_IN: Easing.ease,
  EASE_OUT: Easing.out(Easing.ease),
  EASE_IN_OUT: Easing.inOut(Easing.ease),
  
  // More specialized curves
  ELASTIC: Easing.elastic(1),
  BOUNCE: Easing.bounce,
  BACK: Easing.back(1.5),
  
  // Custom ease curves
  ACCELERATE: Easing.bezier(0.4, 0.0, 1, 1),
  DECELERATE: Easing.bezier(0, 0, 0.2, 1),
};

/**
 * Get animation duration adjusted for user preference
 * @param {string} type - The duration type (VERY_FAST, FAST, etc.)
 * @returns {number} The adjusted duration in milliseconds
 */
const getAdjustedDuration = (type = 'NORMAL') => {
  // Get user's animation speed preference
  const animationSettings = performanceUtils.getAnimationSettings();
  const speedFactor = animationSettings.reduceMotion ? 0.7 : 1.0;
  
  // Apply the speed factor to the base duration
  return DURATIONS[type] * speedFactor;
};

/**
 * Get animation easing adjusted for user preference
 * @param {string} type - The easing type 
 * @param {string} animationStyle - User's animation style preference
 * @returns {function} The easing function
 */
const getAdjustedEasing = (type = 'EASE_OUT', animationStyle = 'smooth') => {
  // Map animation style to appropriate easing
  switch (animationStyle) {
    case 'bounce':
      if (type === 'EASE_OUT') return EASINGS.BOUNCE;
      if (type === 'EASE_IN_OUT') return EASINGS.BOUNCE;
      break;
    case 'elastic':
      if (type === 'EASE_OUT') return EASINGS.ELASTIC;
      if (type === 'EASE_IN_OUT') return EASINGS.ELASTIC;
      break;
    case 'minimal':
      // Always use simple easings for minimal style
      return type === 'EASE_IN' ? EASINGS.ACCELERATE : EASINGS.DECELERATE;
  }
  
  // Default to requested easing
  return EASINGS[type] || EASINGS.EASE_OUT;
};

/**
 * Create a fade-in animation
 * @param {Animated.Value} value - The animated value
 * @param {object} options - Animation options
 * @returns {Animated.CompositeAnimation} The animation
 */
const fadeIn = (value, options = {}) => {
  const {
    duration = getAdjustedDuration('NORMAL'),
    easing = EASINGS.EASE_OUT,
    delay = 0,
    useNativeDriver = true,
  } = options;
  
  return Animated.timing(value, {
    toValue: 1,
    duration,
    easing,
    delay,
    useNativeDriver,
  });
};

/**
 * Create a fade-out animation
 * @param {Animated.Value} value - The animated value
 * @param {object} options - Animation options
 * @returns {Animated.CompositeAnimation} The animation
 */
const fadeOut = (value, options = {}) => {
  const {
    duration = getAdjustedDuration('NORMAL'),
    easing = EASINGS.EASE_IN,
    delay = 0,
    useNativeDriver = true,
  } = options;
  
  return Animated.timing(value, {
    toValue: 0,
    duration,
    easing,
    delay,
    useNativeDriver,
  });
};

/**
 * Create a slide animation
 * @param {Animated.Value} value - The animated value
 * @param {number} toValue - The target value
 * @param {object} options - Animation options
 * @returns {Animated.CompositeAnimation} The animation
 */
const slide = (value, toValue, options = {}) => {
  const {
    duration = getAdjustedDuration('NORMAL'),
    easing = EASINGS.EASE_OUT,
    delay = 0,
    useNativeDriver = true,
  } = options;
  
  return Animated.timing(value, {
    toValue,
    duration,
    easing,
    delay,
    useNativeDriver,
  });
};

/**
 * Create a scale animation
 * @param {Animated.Value} value - The animated value
 * @param {number} toValue - The target value
 * @param {object} options - Animation options
 * @returns {Animated.CompositeAnimation} The animation
 */
const scale = (value, toValue, options = {}) => {
  const {
    duration = getAdjustedDuration('NORMAL'),
    easing = EASINGS.BACK,
    delay = 0,
    useNativeDriver = true,
  } = options;
  
  return Animated.timing(value, {
    toValue,
    duration,
    easing,
    delay,
    useNativeDriver,
  });
};

/**
 * Create a spring animation
 * @param {Animated.Value} value - The animated value
 * @param {number} toValue - The target value
 * @param {object} options - Animation options
 * @returns {Animated.CompositeAnimation} The animation
 */
const spring = (value, toValue, options = {}) => {
  const {
    friction = 8,
    tension = 40,
    velocity = 0,
    delay = 0,
    useNativeDriver = true,
  } = options;
  
  return Animated.spring(value, {
    toValue,
    friction,
    tension,
    velocity,
    delay,
    useNativeDriver,
  });
};

/**
 * Create a decay animation (useful for gestures)
 * @param {Animated.Value} value - The animated value
 * @param {object} options - Animation options
 * @returns {Animated.CompositeAnimation} The animation
 */
const decay = (value, options = {}) => {
  const {
    velocity = 0,
    deceleration = 0.997,
    useNativeDriver = true,
  } = options;
  
  return Animated.decay(value, {
    velocity,
    deceleration,
    useNativeDriver,
  });
};

/**
 * Create a sequence of animations
 * @param {Array} animations - Array of animations
 * @returns {Animated.CompositeAnimation} The sequenced animation
 */
const sequence = (animations) => {
  return Animated.sequence(animations);
};

/**
 * Create parallel animations
 * @param {Array} animations - Array of animations
 * @returns {Animated.CompositeAnimation} The parallel animation
 */
const parallel = (animations) => {
  return Animated.parallel(animations);
};

/**
 * Create a staggered animation
 * @param {Array} animations - Array of animations
 * @param {number} staggerDelay - Delay between each animation
 * @returns {Animated.CompositeAnimation} The staggered animation
 */
const stagger = (animations, staggerDelay = 100) => {
  return Animated.stagger(staggerDelay, animations);
};

/**
 * Create a loop animation
 * @param {Animated.CompositeAnimation} animation - The animation to loop
 * @param {object} options - Loop options
 * @returns {Animated.CompositeAnimation} The looped animation
 */
const loop = (animation, options = {}) => {
  const { iterations = -1 } = options;
  return Animated.loop(animation, { iterations });
};

/**
 * Create interpolated values for an animation
 * @param {Animated.Value} value - The animated value
 * @param {object} config - Interpolation config
 * @returns {Animated.AnimatedInterpolation} The interpolated value
 */
const interpolate = (value, config) => {
  return value.interpolate(config);
};

/**
 * Create a timing function based on animation style
 * @param {string} animationStyle - The animation style (bounce, elastic, smooth, minimal)
 * @returns {function} The timing function
 */
const getTimingFunction = (animationStyle) => {
  switch (animationStyle) {
    case 'bounce':
      return (t) => {
        const a = 4.0 / 11.0;
        const b = 8.0 / 11.0;
        const c = 9.0 / 10.0;
        
        const ca = 4356.0 / 361.0;
        const cb = 35442.0 / 1805.0;
        const cc = 16061.0 / 1805.0;
        
        const t2 = t * t;
        
        return t < a
          ? 7.5625 * t2
          : t < b
          ? 9.075 * t2 - 9.9 * t + 3.4
          : t < c
          ? ca * t2 - cb * t + cc
          : 10.8 * t * t - 20.52 * t + 10.72;
      };
    case 'elastic':
      return (t) => {
        return t === 0
          ? 0
          : t === 1
          ? 1
          : -Math.pow(2, 10 * (t - 1)) * Math.sin((t - 1.1) * 5 * Math.PI);
      };
    case 'minimal':
      return (t) => t;
    case 'smooth':
    default:
      return (t) => t * t * (3 - 2 * t);
  }
};

/**
 * Create a 3D perspective animation based on tilt
 * @param {object} values - The animated values for x and y tilt
 * @param {object} options - Animation options
 * @returns {object} Transform styles for the animation
 */
const createPerspectiveAnimation = (values, options = {}) => {
  const {
    tiltFactor = 10,
    perspective = 800,
  } = options;
  
  // Create interpolated rotation values
  const rotateX = values.y.interpolate({
    inputRange: [-100, 100],
    outputRange: [`${tiltFactor}deg`, `-${tiltFactor}deg`],
    extrapolate: 'clamp',
  });
  
  const rotateY = values.x.interpolate({
    inputRange: [-100, 100],
    outputRange: [`-${tiltFactor}deg`, `${tiltFactor}deg`],
    extrapolate: 'clamp',
  });
  
  // Return transform array for use in style
  return {
    transform: [
      { perspective },
      { rotateX },
      { rotateY }
    ]
  };
};

export const animations = {
  DURATIONS,
  EASINGS,
  getAdjustedDuration,
  getAdjustedEasing,
  fadeIn,
  fadeOut,
  slide,
  scale,
  spring,
  decay,
  sequence,
  parallel,
  stagger,
  loop,
  interpolate,
  getTimingFunction,
  createPerspectiveAnimation
};
