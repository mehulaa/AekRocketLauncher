// Predefined themes for the launcher
const THEMES = {
  default: {
    id: 'default',
    name: 'Default Theme',
    isDark: false,
    backgroundColor: '#F5F5F5',
    primaryColor: '#2196F3',
    secondaryColor: '#FFC107',
    textColor: '#212121',
    accentColor: '#FF4081',
    cardColor: '#FFFFFF',
    shadowColor: 'rgba(0, 0, 0, 0.1)',
    iconStyle: 'flat',
    borderRadius: 8,
    fontFamily: 'System',
    animationStyle: 'bounce',
  },
  dark: {
    id: 'dark',
    name: 'Dark Theme',
    isDark: true,
    backgroundColor: '#121212',
    primaryColor: '#BB86FC',
    secondaryColor: '#03DAC6',
    textColor: '#E1E1E1',
    accentColor: '#CF6679',
    cardColor: '#1E1E1E',
    shadowColor: 'rgba(0, 0, 0, 0.2)',
    iconStyle: 'flat',
    borderRadius: 8,
    fontFamily: 'System',
    animationStyle: 'smooth',
  },
  neon: {
    id: 'neon',
    name: 'Neon Theme',
    isDark: true,
    backgroundColor: '#0A0A0A',
    primaryColor: '#FF00FF',
    secondaryColor: '#00FFFF',
    textColor: '#FFFFFF',
    accentColor: '#FFFF00',
    cardColor: '#1A1A1A',
    shadowColor: 'rgba(255, 0, 255, 0.5)',
    iconStyle: 'glowing',
    borderRadius: 12,
    fontFamily: 'System',
    animationStyle: 'elastic',
  },
  minimalist: {
    id: 'minimalist',
    name: 'Minimalist Theme',
    isDark: false,
    backgroundColor: '#FFFFFF',
    primaryColor: '#000000',
    secondaryColor: '#CCCCCC',
    textColor: '#333333',
    accentColor: '#666666',
    cardColor: '#F9F9F9',
    shadowColor: 'rgba(0, 0, 0, 0.05)',
    iconStyle: 'minimal',
    borderRadius: 4,
    fontFamily: 'System',
    animationStyle: 'minimal',
  },
  nature: {
    id: 'nature',
    name: 'Nature',
    isDark: false,
    backgroundColor: '#E8F5E9',
    primaryColor: '#4CAF50',
    secondaryColor: '#8BC34A',
    textColor: '#1B5E20',
    accentColor: '#FF9800',
    cardColor: '#FFFFFF',
    shadowColor: 'rgba(76, 175, 80, 0.2)',
    iconStyle: 'flat',
    borderRadius: 10,
    fontFamily: 'System',
    animationStyle: 'smooth',
  },
  ocean: {
    id: 'ocean',
    name: 'Ocean',
    isDark: true,
    backgroundColor: '#01579B',
    primaryColor: '#03A9F4',
    secondaryColor: '#00BCD4',
    textColor: '#E1F5FE',
    accentColor: '#FFEB3B',
    cardColor: '#0277BD',
    shadowColor: 'rgba(3, 169, 244, 0.3)',
    iconStyle: 'realistic',
    borderRadius: 8,
    fontFamily: 'System',
    animationStyle: 'bounce',
  },
  sunset: {
    id: 'sunset',
    name: 'Sunset',
    isDark: true,
    backgroundColor: '#3E2723',
    primaryColor: '#FF5722',
    secondaryColor: '#FF9800',
    textColor: '#FFCCBC',
    accentColor: '#FFEB3B',
    cardColor: '#5D4037',
    shadowColor: 'rgba(255, 87, 34, 0.3)',
    iconStyle: 'glowing',
    borderRadius: 6,
    fontFamily: 'System',
    animationStyle: 'elastic',
  },
  monochrome: {
    id: 'monochrome',
    name: 'Monochrome',
    isDark: false,
    backgroundColor: '#EEEEEE',
    primaryColor: '#212121',
    secondaryColor: '#757575',
    textColor: '#212121',
    accentColor: '#000000',
    cardColor: '#FFFFFF',
    shadowColor: 'rgba(0, 0, 0, 0.1)',
    iconStyle: 'minimal',
    borderRadius: 0,
    fontFamily: 'System',
    animationStyle: 'minimal',
  }
};

// Create a theme with iOS-like aesthetics
function createIOSTheme() {
  return {
    id: 'ios',
    name: 'iOS',
    isDark: false,
    backgroundColor: '#F2F2F7',
    primaryColor: '#007AFF',
    secondaryColor: '#5AC8FA',
    textColor: '#000000',
    accentColor: '#FF2D55',
    cardColor: '#FFFFFF',
    shadowColor: 'rgba(0, 0, 0, 0.1)',
    iconStyle: 'flat',
    borderRadius: 12,
    fontFamily: 'System',
    animationStyle: 'smooth',
  };
}

// Create a theme with material design aesthetics
function createMaterialTheme(isDark = false) {
  return {
    id: isDark ? 'material_dark' : 'material',
    name: isDark ? 'Material Dark' : 'Material',
    isDark: isDark,
    backgroundColor: isDark ? '#121212' : '#FAFAFA',
    primaryColor: '#6200EE',
    secondaryColor: '#03DAC6',
    textColor: isDark ? '#FFFFFF' : '#000000',
    accentColor: isDark ? '#BB86FC' : '#6200EE',
    cardColor: isDark ? '#1D1D1D' : '#FFFFFF',
    shadowColor: 'rgba(0, 0, 0, ' + (isDark ? '0.24' : '0.14') + ')',
    iconStyle: 'flat',
    borderRadius: 4,
    fontFamily: 'Roboto',
    animationStyle: 'smooth',
  };
}

// Generate a random theme
function generateRandomTheme() {
  const randomColor = () => {
    return '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
  };
  
  const isDark = Math.random() > 0.5;
  
  return {
    id: 'random_' + Date.now(),
    name: 'Random Theme',
    isDark: isDark,
    backgroundColor: isDark ? '#121212' : '#F5F5F5',
    primaryColor: randomColor(),
    secondaryColor: randomColor(),
    textColor: isDark ? '#FFFFFF' : '#000000',
    accentColor: randomColor(),
    cardColor: isDark ? '#1D1D1D' : '#FFFFFF',
    shadowColor: `rgba(0, 0, 0, ${isDark ? 0.2 : 0.1})`,
    iconStyle: ['flat', 'realistic', 'minimal', 'glowing'][Math.floor(Math.random() * 4)],
    borderRadius: Math.floor(Math.random() * 20),
    fontFamily: 'System',
    animationStyle: ['bounce', 'elastic', 'smooth', 'minimal'][Math.floor(Math.random() * 4)],
  };
}

// Generate a theme from a color
function generateThemeFromColor(color) {
  // Convert hex to RGB
  const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  };
  
  // Calculate luminance
  const getLuminance = (rgb) => {
    return (0.299 * rgb.r + 0.587 * rgb.g + 0.114 * rgb.b) / 255;
  };
  
  const rgb = hexToRgb(color);
  if (!rgb) return THEMES.default;
  
  const luminance = getLuminance(rgb);
  const isDark = luminance < 0.5;
  
  // Calculate complementary color
  const complementary = `#${(0xFFFFFF ^ parseInt(color.slice(1), 16)).toString(16).padStart(6, '0')}`;
  
  // Adjust color for text based on luminance
  const textColor = isDark ? '#FFFFFF' : '#000000';
  
  return {
    id: 'custom_' + Date.now(),
    name: 'Custom Theme',
    isDark: isDark,
    backgroundColor: isDark ? '#121212' : '#F5F5F5',
    primaryColor: color,
    secondaryColor: complementary,
    textColor: textColor,
    accentColor: isDark ? '#FF4081' : '#E91E63',
    cardColor: isDark ? '#1D1D1D' : '#FFFFFF',
    shadowColor: `rgba(0, 0, 0, ${isDark ? 0.2 : 0.1})`,
    iconStyle: 'flat',
    borderRadius: 8,
    fontFamily: 'System',
    animationStyle: 'smooth',
  };
}

export const themes = {
  THEMES,
  createIOSTheme,
  createMaterialTheme,
  generateRandomTheme,
  generateThemeFromColor
};
