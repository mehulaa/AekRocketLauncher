import { Animated, Easing } from 'react-native';

// Animation styles
const ANIMATION_STYLES = {
  BOUNCE: 'bounce',
  ELASTIC: 'elastic',
  SMOOTH: 'smooth',
  MINIMAL: 'minimal'
};

// Animation durations
const DURATIONS = {
  VERY_FAST: 150,
  FAST: 250,
  NORMAL: 350,
  SLOW: 500,
  VERY_SLOW: 700
};

// Easing presets
const EASING = {
  // Standard curves
  LINEAR: Easing.linear,
  EASE_IN: Easing.ease,
  EASE_OUT: Easing.out(Easing.ease),
  EASE_IN_OUT: Easing.inOut(Easing.ease),
  
  // More specialized curves
  ELASTIC: Easing.elastic(1),
  BOUNCE: Easing.bounce,
  BACK: Easing.back(1.5),
  
  // Custom ease curves
  ACCELERATE: Easing.bezier(0.4, 0.0, 1, 1),
  DECELERATE: Easing.bezier(0, 0, 0.2, 1),
};

/**
 * Get animation properties based on style
 * @param {string} style - Animation style
 * @returns {Object} Animation properties
 */
const getAnimationPropertiesForStyle = (style = ANIMATION_STYLES.SMOOTH) => {
  switch(style) {
    case ANIMATION_STYLES.BOUNCE:
      return {
        duration: DURATIONS.NORMAL,
        easing: EASING.BOUNCE
      };
    case ANIMATION_STYLES.ELASTIC:
      return {
        duration: DURATIONS.SLOW,
        easing: EASING.ELASTIC
      };
    case ANIMATION_STYLES.MINIMAL:
      return {
        duration: DURATIONS.FAST,
        easing: EASING.DECELERATE
      };
    case ANIMATION_STYLES.SMOOTH:
    default:
      return {
        duration: DURATIONS.NORMAL,
        easing: EASING.EASE_IN_OUT
      };
  }
};

/**
 * Create a fade-in animation
 * @param {Animated.Value} value - Animation value
 * @param {string} style - Animation style
 * @returns {Animated.CompositeAnimation} Animation
 */
const fadeIn = (value, style = ANIMATION_STYLES.SMOOTH) => {
  const { duration, easing } = getAnimationPropertiesForStyle(style);
  
  return Animated.timing(value, {
    toValue: 1,
    duration,
    easing,
    useNativeDriver: true
  });
};

/**
 * Create a fade-out animation
 * @param {Animated.Value} value - Animation value
 * @param {string} style - Animation style
 * @returns {Animated.CompositeAnimation} Animation
 */
const fadeOut = (value, style = ANIMATION_STYLES.SMOOTH) => {
  const { duration, easing } = getAnimationPropertiesForStyle(style);
  
  return Animated.timing(value, {
    toValue: 0,
    duration,
    easing,
    useNativeDriver: true
  });
};

/**
 * Create a slide animation
 * @param {Animated.Value} value - Animation value
 * @param {number} toValue - Target value
 * @param {string} style - Animation style
 * @returns {Animated.CompositeAnimation} Animation
 */
const slide = (value, toValue, style = ANIMATION_STYLES.SMOOTH) => {
  const { duration, easing } = getAnimationPropertiesForStyle(style);
  
  return Animated.timing(value, {
    toValue,
    duration,
    easing,
    useNativeDriver: true
  });
};

/**
 * Create a scale animation
 * @param {Animated.Value} value - Animation value
 * @param {number} toValue - Target value
 * @param {string} style - Animation style
 * @returns {Animated.CompositeAnimation} Animation
 */
const scale = (value, toValue, style = ANIMATION_STYLES.SMOOTH) => {
  const { duration, easing } = getAnimationPropertiesForStyle(style);
  
  return Animated.timing(value, {
    toValue,
    duration,
    easing: style === ANIMATION_STYLES.BOUNCE ? EASING.BOUNCE : easing,
    useNativeDriver: true
  });
};

/**
 * Create a rotation animation
 * @param {Animated.Value} value - Animation value
 * @param {number} toValue - Target value in degrees
 * @param {string} style - Animation style
 * @returns {Animated.CompositeAnimation} Animation
 */
const rotate = (value, toValue, style = ANIMATION_STYLES.SMOOTH) => {
  const { duration, easing } = getAnimationPropertiesForStyle(style);
  
  return Animated.timing(value, {
    toValue,
    duration,
    easing,
    useNativeDriver: true
  });
};

/**
 * Create a spring animation
 * @param {Animated.Value} value - Animation value
 * @param {number} toValue - Target value
 * @param {Object} config - Spring configuration
 * @returns {Animated.CompositeAnimation} Animation
 */
const spring = (value, toValue, config = {}) => {
  return Animated.spring(value, {
    toValue,
    friction: config.friction || 7,
    tension: config.tension || 40,
    useNativeDriver: true
  });
};

/**
 * Create a sequence of animations
 * @param {Array} animations - Array of animations
 * @returns {Animated.CompositeAnimation} Sequence animation
 */
const sequence = (animations) => {
  return Animated.sequence(animations);
};

/**
 * Create parallel animations
 * @param {Array} animations - Array of animations
 * @returns {Animated.CompositeAnimation} Parallel animation
 */
const parallel = (animations) => {
  return Animated.parallel(animations);
};

/**
 * Create staggered animations
 * @param {Array} animations - Array of animations
 * @param {number} staggerDelay - Delay between animations
 * @returns {Animated.CompositeAnimation} Staggered animation
 */
const stagger = (animations, staggerDelay = 100) => {
  return Animated.stagger(staggerDelay, animations);
};

/**
 * Create a loop animation
 * @param {Animated.CompositeAnimation} animation - Animation to loop
 * @param {Object} config - Loop configuration
 * @returns {Animated.CompositeAnimation} Loop animation
 */
const loop = (animation, config = {}) => {
  return Animated.loop(animation, {
    iterations: config.iterations || -1
  });
};

/**
 * Create a 3D animation preset
 * @param {string} type - Animation type
 * @returns {Object} Animation configuration
 */
const create3DAnimationPreset = (type) => {
  switch(type) {
    case '3d-flip':
      return {
        transform: [
          { perspective: 1000 },
          { rotateY: '180deg' }
        ],
        duration: DURATIONS.NORMAL,
        easing: EASING.EASE_IN_OUT
      };
    case '3d-rotate':
      return {
        transform: [
          { perspective: 1000 },
          { rotateY: '360deg' }
        ],
        duration: DURATIONS.SLOW,
        easing: EASING.EASE_IN_OUT
      };
    case '3d-tilt':
      return {
        transform: [
          { perspective: 1000 },
          { rotateX: '20deg' },
          { rotateY: '10deg' }
        ],
        duration: DURATIONS.NORMAL,
        easing: EASING.EASE_OUT
      };
    case '3d-hover':
    default:
      return {
        transform: [
          { perspective: 1000 },
          { translateZ: 50 },
          { scale: 1.1 }
        ],
        duration: DURATIONS.NORMAL,
        easing: EASING.EASE_OUT
      };
  }
};

/**
 * Create a 3D animation
 * @param {Object} values - Animation values
 * @param {string} type - Animation type
 * @returns {Animated.CompositeAnimation} Animation
 */
const animate3D = (values, type = '3d-hover') => {
  const preset = create3DAnimationPreset(type);
  
  // Create animation based on preset
  const animations = [];
  
  if (values.perspective && preset.transform.find(t => t.perspective)) {
    animations.push(
      Animated.timing(values.perspective, {
        toValue: preset.transform.find(t => t.perspective).perspective,
        duration: preset.duration,
        easing: preset.easing,
        useNativeDriver: true
      })
    );
  }
  
  if (values.rotateX && preset.transform.find(t => t.rotateX)) {
    const degrees = parseFloat(preset.transform.find(t => t.rotateX).rotateX);
    animations.push(
      Animated.timing(values.rotateX, {
        toValue: degrees * Math.PI / 180, // Convert to radians
        duration: preset.duration,
        easing: preset.easing,
        useNativeDriver: true
      })
    );
  }
  
  if (values.rotateY && preset.transform.find(t => t.rotateY)) {
    const degrees = parseFloat(preset.transform.find(t => t.rotateY).rotateY);
    animations.push(
      Animated.timing(values.rotateY, {
        toValue: degrees * Math.PI / 180, // Convert to radians
        duration: preset.duration,
        easing: preset.easing,
        useNativeDriver: true
      })
    );
  }
  
  if (values.translateZ && preset.transform.find(t => t.translateZ)) {
    animations.push(
      Animated.timing(values.translateZ, {
        toValue: preset.transform.find(t => t.translateZ).translateZ,
        duration: preset.duration,
        easing: preset.easing,
        useNativeDriver: true
      })
    );
  }
  
  if (values.scale && preset.transform.find(t => t.scale)) {
    animations.push(
      Animated.timing(values.scale, {
        toValue: preset.transform.find(t => t.scale).scale,
        duration: preset.duration,
        easing: preset.easing,
        useNativeDriver: true
      })
    );
  }
  
  return Animated.parallel(animations);
};

export const animationStyles = {
  ANIMATION_STYLES,
  DURATIONS,
  EASING,
  getAnimationPropertiesForStyle,
  fadeIn,
  fadeOut,
  slide,
  scale,
  rotate,
  spring,
  sequence,
  parallel,
  stagger,
  loop,
  create3DAnimationPreset,
  animate3D
};
