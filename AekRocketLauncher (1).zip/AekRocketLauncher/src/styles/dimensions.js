import { Dimensions, Platform, StatusBar } from 'react-native';

// Get screen dimensions
const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

// Calculate safe area on different devices
const IS_IPHONE_X = Platform.OS === 'ios' && 
                    (SCREEN_HEIGHT === 812 || SCREEN_WIDTH === 812 || 
                     SCREEN_HEIGHT === 896 || SCREEN_WIDTH === 896);

// Status bar height
const STATUS_BAR_HEIGHT = Platform.OS === 'ios' 
                         ? IS_IPHONE_X ? 44 : 20 
                         : StatusBar.currentHeight || 0;

// Bottom tab height
const BOTTOM_TAB_HEIGHT = IS_IPHONE_X ? 84 : 60;

// Grid dimensions
const GRID_DEFAULT = {
  columns: 5,
  rows: 6,
  padding: 16,
  spacing: 8
};

// Icon dimensions
const ICON_SIZES = {
  SMALL: 40,
  MEDIUM: 60,
  LARGE: 80
};

// Calculate cell dimensions based on grid
const calculateCellDimensions = (grid = GRID_DEFAULT) => {
  const { columns, rows, padding, spacing } = grid;
  
  // Available width/height after padding
  const availableWidth = SCREEN_WIDTH - (padding * 2);
  const availableHeight = SCREEN_HEIGHT - (padding * 2) - STATUS_BAR_HEIGHT - 100; // 100px for bottom area
  
  // Calculate cell width and height
  const cellWidth = (availableWidth - (spacing * (columns - 1))) / columns;
  const cellHeight = (availableHeight - (spacing * (rows - 1))) / rows;
  
  return {
    width: cellWidth,
    height: cellHeight
  };
};

// Calculate icon size based on preference
const getIconSize = (preference = 'MEDIUM', grid = GRID_DEFAULT) => {
  const { width } = calculateCellDimensions(grid);
  
  // Size based on preference, but limit by cell width
  const baseSize = ICON_SIZES[preference] || ICON_SIZES.MEDIUM;
  return Math.min(baseSize, width * 0.8);
};

// Calculate widget dimensions based on size and grid
const getWidgetDimensions = (widgetSize, grid = GRID_DEFAULT) => {
  const { width: cellWidth, height: cellHeight } = calculateCellDimensions(grid);
  const { spacing } = grid;
  
  return {
    width: cellWidth * widgetSize.width + (spacing * (widgetSize.width - 1)),
    height: cellHeight * widgetSize.height + (spacing * (widgetSize.height - 1))
  };
};

// Calculate grid positions
const getGridPosition = (col, row, grid = GRID_DEFAULT) => {
  const { width: cellWidth, height: cellHeight } = calculateCellDimensions(grid);
  const { padding, spacing } = grid;
  
  const x = padding + (col * (cellWidth + spacing));
  const y = padding + STATUS_BAR_HEIGHT + (row * (cellHeight + spacing));
  
  return { x, y };
};

// Responsive spacing units
const createSpacing = (baseSize = 8) => {
  return {
    xs: baseSize * 0.5,
    sm: baseSize,
    md: baseSize * 2,
    lg: baseSize * 3,
    xl: baseSize * 4
  };
};

// Font sizes
const FONT_SIZES = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 18,
  xl: 20,
  xxl: 24,
  xxxl: 30
};

// Responsive font sizing
const calculateResponsiveFontSize = (size) => {
  const standardScreenWidth = 375; // iPhone 8 width
  const scaleFactor = SCREEN_WIDTH / standardScreenWidth;
  
  // Scale the font size, but not too much
  const maxScale = 1.3;
  const minScale = 0.8;
  const limitedScale = Math.min(Math.max(scaleFactor, minScale), maxScale);
  
  return Math.round(size * limitedScale);
};

// Screen ratio type (wide, standard, tall)
const getScreenRatioType = () => {
  const ratio = SCREEN_HEIGHT / SCREEN_WIDTH;
  
  if (ratio < 1.6) return 'wide';
  if (ratio > 2.1) return 'tall';
  return 'standard';
};

// Adjust layout for screen ratio
const adjustLayoutForScreenRatio = (layout) => {
  const ratioType = getScreenRatioType();
  
  switch(ratioType) {
    case 'wide':
      return {
        ...layout,
        rows: layout.rows - 1,
        columns: layout.columns + 1
      };
    case 'tall':
      return {
        ...layout,
        rows: layout.rows + 1,
        columns: Math.max(layout.columns - 1, 3)
      };
    default:
      return layout;
  }
};

export const dimensions = {
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  STATUS_BAR_HEIGHT,
  BOTTOM_TAB_HEIGHT,
  GRID_DEFAULT,
  ICON_SIZES,
  FONT_SIZES,
  calculateCellDimensions,
  getIconSize,
  getWidgetDimensions,
  getGridPosition,
  createSpacing,
  calculateResponsiveFontSize,
  getScreenRatioType,
  adjustLayoutForScreenRatio,
  spacing: createSpacing()
};
