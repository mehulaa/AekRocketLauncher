import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Import screens
import HomeScreen from '../components/HomeScreen';
import Settings from '../components/Settings';
import ThemeEditor from '../components/ThemeEditor';
import IconCustomizer from '../components/IconCustomizer';
import GestureEditor from '../components/GestureEditor';
import WallpaperEditor from '../components/WallpaperEditor';
import LayoutEditor from '../components/LayoutEditor';
import WidgetEditor from '../components/WidgetEditor';
import AppSearch from '../components/AppSearch';

const Stack = createStackNavigator();

const AppNavigator = ({ theme }) => {
  // Common screen options
  const screenOptions = {
    headerStyle: {
      backgroundColor: theme.cardColor || '#FFFFFF',
      shadowColor: theme.shadowColor || 'rgba(0, 0, 0, 0.1)',
      elevation: 2,
    },
    headerTintColor: theme.textColor || '#000000',
    headerTitleStyle: {
      fontWeight: 'bold',
    },
    cardStyle: {
      backgroundColor: theme.backgroundColor || '#F5F5F5',
    },
    // Animated transitions
    cardStyleInterpolator: ({ current, layouts }) => {
      return {
        cardStyle: {
          transform: [
            {
              translateY: current.progress.interpolate({
                inputRange: [0, 1],
                outputRange: [layouts.screen.height, 0],
              }),
            },
          ],
        },
        overlayStyle: {
          opacity: current.progress.interpolate({
            inputRange: [0, 1],
            outputRange: [0, 0.5],
          }),
        },
      };
    },
  };

  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={screenOptions}
      >
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Settings"
          component={Settings}
          options={{
            title: "Settings",
            headerTransparent: true,
          }}
        />
        <Stack.Screen
          name="ThemeEditor"
          component={ThemeEditor}
          options={{
            title: "Theme Editor",
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="IconCustomizer"
          component={IconCustomizer}
          options={{
            title: "Customize Icon",
          }}
        />
        <Stack.Screen
          name="GestureEditor"
          component={GestureEditor}
          options={{
            title: "Gesture Controls",
          }}
        />
        <Stack.Screen
          name="WallpaperEditor"
          component={WallpaperEditor}
          options={{
            title: "3D Wallpapers",
            headerTransparent: true,
          }}
        />
        <Stack.Screen
          name="LayoutEditor"
          component={LayoutEditor}
          options={{
            title: "Edit Layout",
          }}
        />
        <Stack.Screen
          name="WidgetEditor"
          component={WidgetEditor}
          options={{
            title: "Widget Editor",
          }}
        />
        <Stack.Screen
          name="AppSearch"
          component={AppSearch}
          options={{
            title: "Search Apps",
            headerShown: false,
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;
